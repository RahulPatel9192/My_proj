#include"header.h"
main(int argc,char **argv)
{

if(argc!=2)
{
printf("usage ./a.out msgid...\n");
return;
}

msgctl(atoi(argv[1]),IPC_RMID,0);
perror("msgctl");





}
