//reciver
#include"header.h"
struct msgbuf
{
long mtype;
char data[20];
};

main(int argc,char **argv)
{
int id;
struct msgbuf v;

if(argc!=2)
{
printf("usage ./snd type\n");
return;
}

id=msgget(4,IPC_CREAT|0666);
if(id<0)
{
perror("msgget");
return;
}
printf("id=%d\n");
///////////////////////////////////////////////////


msgrcv(id,&v,sizeof(v),atoi(argv[1]),MSG_EXCEPT);
perror("msgrcv");
printf("data=%s\n",v.data);





}

