//receive

#include"header.h"

struct msgbuf
{
long mtype;
char data[50];
};

main()
{
char ch[50];
struct msgbuf v;
int id;

id=msgget(1,IPC_CREAT|0666);
if(id<0)
{
perror("msgget");
return;
}

if(fork())
{
while(1)
{
printf("enter the msg...\n");
scanf("%s",ch);

v.mtype=6;
strcpy(v.data,ch);
msgsnd(id,&v,strlen(v.data)+1,0);
perror("msgsnd");
}
}

else
{
while(1)
{
msgrcv(id,&v,sizeof(v),5,0);
printf("data=%s\n",v.data);



}





}


}
