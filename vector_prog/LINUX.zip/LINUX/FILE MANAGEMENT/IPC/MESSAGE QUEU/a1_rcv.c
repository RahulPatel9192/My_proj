//reciver a1

#include"header.h"
struct msgbuf
{
	long mtype;
	struct st
	{
		int i;
		char data[10];
		char d[50];
		int sum;
	}s1;
};

main(int argc,char **argv)
{
	int id,c=0;
	struct msgbuf v;
	struct dirent *p;
	struct stat s;
	DIR *dp;
	v.s1.sum=0;
	if(argc!=2)
	{
		printf("usage ./a.out msgtype...\n");
		return;
	}

	id=msgget(4,IPC_CREAT|0666);

	if(id<0)
	{
		perror("msgget");
		return;
	}

	msgrcv(id,&v,sizeof(v),atoi(argv[1]),0);
	printf("data=%s\n",v.s1.data);

	dp=opendir(v.s1.data);
	if(dp==0)
	{
		perror("opendir");
		return;
	}

	while(p=readdir(dp))
	{
		c++;
		strcpy(v.s1.data,"/");
		strcpy(v.s1.d,v.s1.data);
		stat(v.s1.d,&s);
		v.s1.sum=v.s1.sum+s.st_nlink;
	}
	v.mtype=5;
	v.s1.i=c;

	msgsnd(id,&v,sizeof(v.s1),0);
	perror("msgsnd");
printf("data=%d link=%d\n",v.s1.i,v.s1.sum);


//	msgsnd(id,&v,sizeof(v.s1),0);
//	perror("msgsnd");
}
