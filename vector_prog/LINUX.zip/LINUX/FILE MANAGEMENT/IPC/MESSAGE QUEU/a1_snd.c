//sender a1

#include"header.h"
struct msgbuf
{
	long mtype;
	struct st
	{
	int i;
	char data[10];
	char d[50];
	int sum;
	}s1;
};

main(int argc,char **argv)
{
	int id;
	struct msgbuf v;
	if(argc!=3)
	{
		printf("usage ./a.out number dirname...\n");
		return;
	}

	id=msgget(4,IPC_CREAT|0666);

	if(id<0)
	{
		perror("msgget");
		return;
	}

	v.mtype=atoi(argv[1]);
	strcpy(v.s1.data,argv[2]);
	msgsnd(id,&v,sizeof(v.s1),0);
	perror("msgsnd");

//////////////////////////////////////////////////////////////
sleep(1);
msgrcv(id,&v,sizeof(v),5,0);
printf("data=%d\n",v.s1.i);
printf("link=%d\n",v.s1.sum);
}
