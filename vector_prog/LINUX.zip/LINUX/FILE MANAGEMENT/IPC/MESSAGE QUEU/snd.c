#include"header.h"
struct msgbuf
{
long mtype;
char data[20];
};

main(int argc,char **argv)
{
int id;
struct msgbuf v;

if(argc!=3)
{
printf("usage ./snd type data..\n");
return;
}

id=msgget(4,IPC_CREAT|0666);
if(id<0)
{
perror("msgget");
return;
}
printf("id=%d\n");
///////////////////////////////////////////////////

v.mtype=atoi(argv[1]);
strcpy(v.data,argv[2]);
msgsnd(id,&v,strlen(v.data)+1,0);
perror("msgsnd");





}

