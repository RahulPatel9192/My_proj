#include"header.h"
main()
{
struct sembuf v;
int id,fd,ret,i;


fd=open("data",O_RDWR|O_APPEND|O_CREAT,0666);

id=semget(5,5,IPC_CREAT|0644);
if(id<0)
{
perror("semget");
return;
}

for(i='a';i<='z';i++)
{
v.sem_num=1;
v.sem_op=0;
v.sem_flg=0;


semop(id,&v,1);
semctl(id,2,SETVAL,1);

write(fd,&i,1);

semctl(id,1,SETVAL,1);
semctl(id,2,SETVAL,0);
}
printf("done..\n");
}
