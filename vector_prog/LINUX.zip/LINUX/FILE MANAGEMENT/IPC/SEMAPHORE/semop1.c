#include"header.h"
main()
{
struct sembuf v;
int id,fd,ret,i;
char a[]="abcdefghij";

fd=open("data",O_RDWR|O_APPEND|O_CREAT,0666);

id=semget(5,5,IPC_CREAT|0644);
if(id<0)
{
perror("semget");
return;
}

v.sem_num=2;
v.sem_op=0;
v.sem_flg=0;

printf("before...\n");
semop(id,&v,1);
semctl(id,2,SETVAL,1);
printf("After...\n");

for(i=0;a[i];i++)
{
write(fd,&a[i],1);
sleep(1);
}
semctl(id,2,SETVAL,0);
printf("Done\n");

}
