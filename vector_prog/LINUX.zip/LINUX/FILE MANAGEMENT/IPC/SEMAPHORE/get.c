#include"header.h"
main(int argc,char **argv)
{
int id,ret;
if(argc!=2)
{
printf("usage ./a.out semnum..\n");
return;
}

id=semget(5,5,IPC_CREAT|0644);
if(id<0)
{
perror("semget");
return;
}
printf("%d\n",id);

ret=semctl(id,atoi(argv[1]),GETVAL);
if(ret<0)
{
perror("semctl");
return;
}
printf("ret=%d\n",ret);
}
