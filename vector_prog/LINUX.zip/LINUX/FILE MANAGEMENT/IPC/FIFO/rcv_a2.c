//a2 reciver
#include"header.h"
main()
{
	char a[50],c[50],tc,i[50];
	int fd,j,c1=0,i1=0,k,l,ti,fd1;
	mkfifo("f1",0666);
	mkfifo("f2",0666);
	perror("mkfifo");

	fd=open("f1",O_RDONLY);
	fd1=open("f2",O_WRONLY);


	read(fd,a,sizeof(a));
	printf("data=%s\n",a);

	for(j=0;a[j];j++)
	{
		if((a[j]>='a'||a[j]>='A') && (a[j]<='z'||a[j]<='Z'))
			c[c1++]=a[j];
		//else if(a[j]>=48 && a[j]<=57)
		else
			i[i1++]=a[j];
	}
	c[c1]='\0';
	i[i1]='\0';
	printf("char array=%s\n",c);
	printf("%s\n",i);
	for(j=0;c[j];j++)
	{
		for(k=j+1;c[k];k++)
		{
			if(c[j]< c[k])
			{
				tc=c[j];
				c[j]=c[k];
				c[k]=tc;
			}
		}
	}
	printf("%s\n ",c);
	write(fd1,c,strlen(c)+1);
	sleep(1);

	for(j=0;i[j];j++)
	{
		for(k=j+1;i[k];k++)
		{
			if(i[j] < i[k])
			{
				tc=i[j];
				i[j]=i[k];
				i[k]=tc;
			}
		}
	}
	printf("%s\n",i);
	write(fd1,i,strlen(i)+1);




}
