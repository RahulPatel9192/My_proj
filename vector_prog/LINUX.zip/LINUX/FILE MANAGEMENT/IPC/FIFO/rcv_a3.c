//a3 recive
#include"header.h"
main()
{
char p1[50];
int fd,c=0;
struct dirent *p;
DIR *dp;
bzero(p1,sizeof(p1));
mkfifo("f1",0666);
fd=open("f1",O_RDONLY);
read(fd,p1,sizeof(p1));

dp=opendir(p1);
if(dp==0)
{
perror("opendir");
return;
}

while(p=readdir(dp))
{
//printf("%s \n",p->d_name);
c++;
}

fd=open("f1",O_WRONLY);
sleep(1);
write(fd,&c,sizeof(c));
}
