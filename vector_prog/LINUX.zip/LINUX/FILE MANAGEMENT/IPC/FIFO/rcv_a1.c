//a1 recever
#include"header.h"
main()
{
char a[50],c[50];
int fd,j,c1=0,i1=0,i[50];
mkfifo("f1",0666);
perror("mkfifo");

fd=open("f1",O_RDONLY);


read(fd,a,sizeof(a));
printf("data=%s\n",a);

for(j=0;a[j];j++)
{
if((a[j]>='a'||a[j]>='A') && (a[j]<='z'||a[j]<='Z'))
c[c1++]=a[j];
else
i[i1++]=a[j];
}

c[c1]='\0';
printf("char array=%s\n",c);
for(j=0;j<i1;j++)
printf("%c ",i[j]);
printf("\n");






}
