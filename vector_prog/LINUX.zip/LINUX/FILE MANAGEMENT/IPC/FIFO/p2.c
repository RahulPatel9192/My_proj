#include"header.h"
main()
{
char a[20];
int fd;
mkfifo("f1",0666);
perror("mkfifo");

printf("before ....pid=%d\n",getpid());
fd=open("f1",O_RDONLY);
printf("After...\n");
while(1)
{
read(fd,a,sizeof(a));
printf("Data:%s\n",a);
}
}
