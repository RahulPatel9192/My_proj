//a2 sender
#include"header.h"
main()
{
char a[50],j[50];
int i;
int fd,fd1;
bzero(a,sizeof(a));
bzero(j,sizeof(j));
mkfifo("f1",0666);
mkfifo("f2",0666);
perror("mkfifo");

fd=open("f1",O_WRONLY);
fd1=open("f2",O_RDONLY);

printf("Enter the data...\n");
scanf("%s",a);
write(fd,a,strlen(a)+1);


read(fd1,a,sizeof(a));
printf("%s \n",a);
sleep(1);
read(fd1,j,sizeof(j));

printf("%s \n",j);

printf("\n");






}
