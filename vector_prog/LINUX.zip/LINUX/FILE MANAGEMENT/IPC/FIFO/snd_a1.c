//a1 sender
#include"header.h"
main()
{
char a[50];
int fd;
mkfifo("f1",0666);
perror("mkfifo");

fd=open("f1",O_WRONLY);

printf("Enter the data...\n");
scanf("%s",a);
write(fd,a,strlen(a)+1);







}
