//a3 sender
#include"header.h"
main(int argc ,char **argv)
{
if(argc!=2)
{
printf("usage ./a.out dirname...\n");
return;
}

int fd,c;
mkfifo("f1",0666);

fd=open("f1",O_WRONLY);

write(fd,argv[1],strlen(argv[1])+1);
sleep(1);

fd=open("f1",O_RDONLY);
read(fd,&c,sizeof(c));
printf("c=%d\n",c);


}
