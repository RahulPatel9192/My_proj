//half duplex
#include"header.h"
main()
{
char a[20];
int fd,fd1;
mkfifo("f1",0666);
mkfifo("f2",0666);
perror("mkfifo");

fd=open("f1",O_WRONLY);
fd1=open("f2",O_RDONLY);

while(1)
{
printf("Enter the data....\n");
scanf("%s",a);
write(fd,a,strlen(a)+1);

read(fd1,a,sizeof(a));
printf("%s\n",a);
}

}
