#include"header.h"
main()
{
char a[20];
int fd;
mkfifo("f1",0666);
perror("mkfifo");

printf("before ....pid=%d\n",getpid());
fd=open("f1",O_WRONLY);
printf("After...\n");
while(1)
{
printf("Enter the data...\n");
scanf("%s",a);
write(fd,a,strlen(a)+1);
}
}
