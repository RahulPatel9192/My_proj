//full duplex

#include"header.h"
main()
{
char a[20];
int fd,fd1;
mkfifo("f1",0666);
mkfifo("f2",0666);

fd=open("f1",O_RDONLY);
fd1=open("f2",O_WRONLY);

if(fork())
{
while(1)
{
read(fd,a,sizeof(a));
printf("Data:%s\n",a);
}
}
else
{
while(1)
{
printf("Enter the data...\n");
scanf("%s",a);
write(fd1,a,strlen(a)+1);
}
}
}
