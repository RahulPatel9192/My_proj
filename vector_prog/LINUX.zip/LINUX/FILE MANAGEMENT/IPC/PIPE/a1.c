#include"header.h"
main()
{
int p[2];
pipe(p);

if(fork())
{//parent
int a;
//char ch[50];
printf("Enter the data...\n");
scanf("%d",&a);
write(p[1],&a,4);

}
else
{//child
int b;
//char ch1[50];
printf("before read...\n");
read(p[0],&b,sizeof(b));
printf("data=%d\n",b);


}





}
