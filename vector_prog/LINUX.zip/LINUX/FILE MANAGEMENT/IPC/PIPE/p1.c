#include"header.h"
main()
{
int p[2];
pipe(p);

printf("read p[0]=%d  write p[1]=%d\n",p[0],p[1]);

if(fork())
{//parent

char a[10];
printf("Enter the data...\n");
scanf("%s",a);
write(p[1],a,strlen(a)+1);
}
else
{//child
char b[20];
printf("Before read...\n");
read(p[0],b,sizeof(b));
printf("Data=%s\n",b);




}



}
