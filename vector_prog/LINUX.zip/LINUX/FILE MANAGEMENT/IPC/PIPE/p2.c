//convert upper case using pipe
#include"header.h"
main()
{
int p[2],i;
pipe(p);

printf("read p[0]=%d  write p[1]=%d\n",p[0],p[1]);

if(fork())
{//parent

char a[10];
printf("Enter the data...\n");
scanf("%s",a);
write(p[1],a,strlen(a)+1);
sleep(1);
read(p[0],a,sizeof(a));
printf("data=%s\n",a);
}
else
{//child
char b[20];
printf("Before read...\n");
read(p[0],b,sizeof(b));
for(i=0;b[i];i++)
if(b[i]>='a' && b[i]<='z')
b[i]=b[i]-32;

write(p[1],b,strlen(b)+1);




}



}
