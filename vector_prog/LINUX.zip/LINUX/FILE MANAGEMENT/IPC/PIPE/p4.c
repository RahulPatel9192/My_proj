#include"header.h"
typedef struct st
{
	int i;
	int j;
	char ch;
}ST;

main()
{
	int p[2];
	ST st;
	pipe(p);
	perror("pipe");

	if(fork())
	{//parent
		int n;
		printf("enter 1st nu...\n");
		scanf("%d",&st.i);

		printf("enter 2nd nu...\n");
		scanf("%d",&st.j);

		printf("Enter sign..\n");
		scanf(" %c",&st.ch);

		write(p[1],&st,sizeof(st));
		sleep(1);
		read(p[0],&n,sizeof(n));
		printf("ans=%d\n",n);
	}
	else
	{//child
		int k;
		printf("in child...\n");
		read(p[0],&st,sizeof(st));

		switch(st.ch)
		{
			case '+':
				{
					k=st.i+st.j;
				}
				break;

			case '-':
				{
					k=st.i-st.j;
				}
				break;

			case '*':
				{
					k=st.i*st.j;
				}
				break;

			case '/':
				{
					k=st.i/st.j;
				}
				break;

			default:
				printf("nothing\n");
		}
		write(p[1],&k,sizeof(k));



	}

}

