//find size of file
#include"header.h"
main()
{
int p[2];
char ch='a';
int c=0;

//pipe(p);
pipe2(p,O_NONBLOCK);
while(write(p[1],&ch,1)!=-1)
{
c++;
}
printf("c=%d\n",c);



}
