//sender

#include"header.h"

main()
{
int *p;
int id,sd;
struct sembuf v;
sd=semget(5,2,IPC_CREAT|0666);
id=shmget(5,50,IPC_CREAT|0666);
if(id<0)
{
perror("shmget");
return;
}
v.sem_num=0;
v.sem_op=0;
v.sem_flg=0;

semop(sd,&v,1);
semctl(sd,1,SETVAL,1);
p=shmat(id,0,0);
printf("enter the data...\n");
scanf("%d",p);
semctl(sd,0,SETVAL,1);
semctl(sd,1,SETVAL,0);

semop(sd,&v,1);
printf("%d \n",*p);

}
