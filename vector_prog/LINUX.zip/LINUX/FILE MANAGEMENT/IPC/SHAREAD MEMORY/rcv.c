//sender

#include"header.h"

main()
{
int *p;
int id,sd,num,s=0;
struct sembuf v;
sd=semget(5,2,IPC_CREAT|0666);
id=shmget(5,50,IPC_CREAT|0666);
if(id<0)
{
perror("shmget");
return;
}
v.sem_num=1;
v.sem_op=0;
v.sem_flg=0;

semop(sd,&v,1);
semctl(sd,0,SETVAL,1);
p=shmat(id,0,0);
printf("%d",*p);

num=*p;
for(;num;s=s*10+(num%10),num=num/10);
*p=s;





semctl(sd,0,SETVAL,0);
semctl(sd,1,SETVAL,1);



}
