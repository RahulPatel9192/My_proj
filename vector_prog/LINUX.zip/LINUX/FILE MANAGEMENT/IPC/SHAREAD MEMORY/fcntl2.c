#include"header.h"
main()
{
struct flock v;
char a[]="abcdefg";
int fd,i;
fd=open("data",O_RDWR|O_CREAT|O_APPEND,0644);

v.l_type=F_WRLCK;
v.l_whence=SEEK_SET;
v.l_start=0;
v.l_len=0;

printf("Before...\n");
fcntl(fd,F_SETLKW,&v);		//seting lock
printf("After...\n");

for(i=0;a[i];i++)
{
write(fd,&a[i],1);
sleep(1);
}

v.l_type=F_UNLCK;
fcntl(fd,F_SETLK,&v);		//unlock
printf("Done...\n");


}
