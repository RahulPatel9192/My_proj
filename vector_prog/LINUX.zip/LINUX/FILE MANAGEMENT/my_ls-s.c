//ls -s
#include"header.h"
main(int argc,char **argv)
{
	struct dirent *p;
	DIR *dp;
	struct stat v;
	if(argc!=2)
	{
		printf("usage ./a.out filename\n");
		return;
	}

	dp=opendir(argv[1]);
	if(dp==0)
	{
		perror("opendir");
		return;
	}

	while(p=readdir(dp))
		if(p->d_name[0]!='.')
		{ 	//not showing hidden file
			lstat(p->d_name,&v);
			printf("%d %s  \n",v.st_blocks/2,p->d_name);
		}
	printf("\n");
}
