#include"header.h"
main(int argc,char **argv)
{
struct dirent *p;
DIR *dp;
if(argc!=1)
{
printf("usage ./a.out filename\n");
return;
}

dp=opendir(".");
if(dp==0)
{
perror("opendir");
return;
}
while(p=readdir(dp))
if(p->d_name[0]!='.') 	//not showing hidden file
printf("%s ",p->d_name);
printf("\n");
}
