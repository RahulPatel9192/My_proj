//tee cmd
#include"header.h"
main(int argc,char **argv)
{
int fd,fd1;
char a[50]={'\0'};
if(argc!=2)
{
printf("usage ./a.out filename..\n");
return;
}


fd=open(argv[1],O_WRONLY|O_APPEND|O_CREAT,0644);
perror("open");

fd1=dup(0);
while(1)
{
//scanf("%s",a);
read(fd1,a,sizeof(a));
printf("%s\n",a);
write(fd,a,strlen(a)+1);
bzero(a,sizeof(a));
}


}
