//compare the size of 2 the file
#include"header.h"
main(int argc ,char **argv)
{
struct stat v,v1;


if(argc!=3)
{
printf("usage ./a.out filename filename\n");
return;
}

stat(argv[1],&v);
stat(argv[2],&v1);

printf("size1=%d\n",v.st_size);
printf("size2=%d\n",v1.st_size);

if(v.st_size > v1.st_size)
printf("%s is big...\n",argv[1]);
else if(v.st_size < v1.st_size)
printf("%s is big..\n",argv[2]);
else
printf("both file size is same...\n");

}

