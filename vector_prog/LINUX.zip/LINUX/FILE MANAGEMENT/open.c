#include"header.h"
main()
{
int fd;
char a[20];
char b[20]="hello\n";
//fd=open("data",O_RDONLY);
fd=open("data",O_WRONLY);
//fd=open("data",O_WRONLY|O_TRUNC|O_CREAT,0644);
if(fd<0)
{
perror("open:");
return;
}
//bzero(a,sizeof(a));       //clear array
//read(fd,a,5);
write(fd,b,5);
//printf("data=%s\n",a);
printf("fd=%d\n",fd);

}
