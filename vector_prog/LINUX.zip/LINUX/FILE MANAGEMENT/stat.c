#include"header.h"
main(int argc,char **argv)
{
struct stat v;

if(argc!=2)
{
printf("usage ./a.out filename\n");
return;
}

if(stat(argv[1],&v)<0)   //if stat fails it return -1
{
perror("stat");
return;
}

printf("size=%u\n",v.st_size);
printf("ino=%u\n",v.st_ino);



printf("%o\n",v.st_mode);
if(S_ISREG(v.st_mode))
printf("Regular\n");
else if(S_ISDIR(v.st_mode))
printf("Directive\n");
}

