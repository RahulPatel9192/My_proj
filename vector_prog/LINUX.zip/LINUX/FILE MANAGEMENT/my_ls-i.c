//ls -i
#include"header.h"
main(int argc,char **argv)
{
	struct dirent *p;
	DIR *dp;
	struct stat v;
	if(argc!=2)
	{
		printf("usage ./a.out filename\n");
		return;
	}

	dp=opendir(argv[1]);
	if(dp==0)
	{
		perror("opendir");
		return;
	}

	while(p=readdir(dp))
		if(p->d_name[0]!='.')
		{ 	//not showing hidden file
			stat(argv[1],&v);
			printf("%u %s  ",v.st_ino,p->d_name);
		}
	printf("\n");
}
