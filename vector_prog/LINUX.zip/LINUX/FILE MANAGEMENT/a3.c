#include"header.h"
main(int argc,char **argv)
{
struct stat v;
if(argc!=2)
{
printf("usage ./a.out filename...\n");
return;
}

lstat(argv[1],&v);

if(S_ISREG(v.st_mode))
printf("Regular file...\n");
else if(S_ISDIR(v.st_mode))
printf("Directive file...\n");
else if(S_ISCHR(v.st_mode))
printf("Char file...\n");
else if(S_ISBLK(v.st_mode))
printf("Block file...\n");
else if(S_ISLNK(v.st_mode))
printf("Link file...\n");
else if(S_ISFIFO(v.st_mode))
printf("FIFO file...\n");
else
printf("SOCKET file...\n");


}
