//find the size of the file
#include"header.h"
main(int argc ,char **argv)
{
struct stat v;
int r;

stat(argv[1],&v);
printf("r=%d/n",v.st_size);



}

