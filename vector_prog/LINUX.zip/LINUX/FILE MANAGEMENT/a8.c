//copy cmnd
#include"header.h"
main(int argc,char **argv)
{
	int fd,fd1;
	char ch;
	if(argc!=3)
	{
		printf("usage ./a.out sourcefile destinaionfile..\n");
		return;
	}

	fd=open(argv[1],O_RDONLY);
	if(fd<0)
	{
		perror("open");
		return;
	}

	fd1=open(argv[2],O_WRONLY|O_CREAT,0644);
	if(fd<0)
	{
		perror("open1");
		return;
	}

	while(read(fd,&ch,1))
	{
		write(fd1,&ch,1);

	}
	printf("done");
}
