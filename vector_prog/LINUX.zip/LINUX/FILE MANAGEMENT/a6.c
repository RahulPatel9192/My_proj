#include"header.h"

main(int argc,char **argv)
{
struct stat v,v1;
struct utimbuf u;

if(argc!=3)
{
printf("usage ./a.out filename filename\n");
return;

}


stat(argv[1],&v);
stat(argv[2],&v1);
u.actime=v.st_atime;
u.modtime=v.st_mtime;


printf("atime=%u  mtime=%u\n",u.actime,u.modtime);

printf("%s\n",argv[1]);
printf("atime=%u  mtime=%u\n",v1.st_atime,v1.st_mtime);

printf("before %s\n",argv[2]);
printf("atime=%u  mtime=%u\n",v1.st_atime,v1.st_mtime);

utime(argv[2],&u);

stat(argv[2],&v1);

printf("after%s\n",argv[2]);
printf("atime=%u  mtime=%u\n",v1.st_atime,v1.st_mtime);




}
