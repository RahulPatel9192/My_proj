#include "header.h"

main(int argc,char **argv)
{
	char s[50];
	if(argc==3)
	{
		switch(argv[1][1])
		{
			case 'l':
				{
					//printf("-l\n");

					struct dirent *p;
					//struct password *pw;
					//struct group *g;
					DIR *dp;
					struct stat v,v1;
					time_t t1;
					if(argc!=3)
					{
						printf("usage ./a.out path\n");
						return;
					}

					dp=opendir(argv[2]);
					if(dp==0)
					{
						perror("opendir");
						return;
					}
					
					while(p=readdir(dp))
					{
						strcpy(s,argv[2]);
						strcat(s,p->d_name);

						if(p->d_name[0]!='.')		
						{
							lstat(s,&v1);
							if(S_ISLNK(v1.st_mode))
								printf("l   %1d   %5d   %5d   %5d   %20s  %20s",v1.st_nlink,v1.st_uid,v1.st_gid,v1.st_size,p->d_name,ctime(&v1.st_mtime));
							else
							{
								stat(s,&v);
								//pw=getpwid(v.st_uid);
								//g=getgrgid(v.st_gid);
								if(S_ISREG(v.st_mode))
									printf("r   %1d   %5d   %5d   %5d   %20s  %20s",v.st_nlink,/*pw.pw_name,g.gr_name*/v.st_uid,v.st_gid,v.st_size,p->d_name,ctime(&v.st_mtime));
								else if(S_ISDIR(v.st_mode))
									printf("d   %1d   %5d   %5d   %5d   %20s  %20s",v.st_nlink,v.st_uid,v.st_gid,v.st_size,p->d_name,ctime(&v.st_mtime));
							}
						}
						else
							;
					}

					//printf("\n");

				}
				break;

			case 'i':
				{
					//printf("-i\n");

					struct dirent *p;
					DIR *dp;
					struct stat v;
					if(argc!=3)
					{
						printf("usage ./a.out filename\n");
						return;
					}

					dp=opendir(argv[2]);
					if(dp==0)
					{
						perror("opendir");
						return;
					}

					while(p=readdir(dp))
						if(p->d_name[0]!='.')
						{ 	
							//	perror("readdir:");
							stat(argv[2],&v);
							printf("%u %s  ",v.st_ino,p->d_name);
						}
					printf("\n");
				}
				break;

			case 's':
				{
					//printf("-s\n");

					struct dirent *p;
					DIR *dp;
					struct stat v;
					if(argc!=3)
					{
						printf("usage ./a.out filename\n");
						return;
					}

					dp=opendir(argv[2]);
					if(dp==0)
					{
						perror("opendir");
						return;
					}

					while(p=readdir(dp))
						if(p->d_name[0]!='.')
						{ 	
							lstat(p->d_name,&v);
							printf("%d %s  \n",v.st_blocks/2,p->d_name);
						}
					printf("\n");
				}
				break;
		}
	}

	else if(argc == 2)
	{
		switch(argv[1][1])
		{
			case 'l':
				{


					struct dirent *p;
					DIR *dp;
					struct stat v,v1;
					time_t t1;
					if(argc!=2)
					{
						printf("usage ./a.out filename\n");
						return;
					}

					dp=opendir(".");
					if(dp==0)
					{
						perror("opendir");
						return;
					}
					while(p=readdir(dp))
					{


						if(p->d_name[0]!='.')		
						{
							lstat(p->d_name,&v1);
							if(S_ISLNK(v1.st_mode))
								printf("l   %d   %d   %d   %d   %u  %s\n",v1.st_nlink,v1.st_uid,v1.st_gid,v1.st_size,v1.st_mtime,p->d_name);
							else
							{
								stat(p->d_name,&v);
								if(S_ISREG(v.st_mode))
									printf("r   %d   %d   %d   %d   %u  %s\n",v.st_nlink,v.st_uid,v.st_gid,v.st_size,v.st_mtime,p->d_name);
								else if(S_ISDIR(v.st_mode))
									printf("d   %d   %d   %d   %d   %u  %s\n",v.st_nlink,v.st_uid,v.st_gid,v.st_size,v.st_mtime,p->d_name);
							}
						}
						else
							;
					}

					//printf("\n");



					break;


					case 'i':
					{
						//printf("-i\n");

						struct dirent *p;
						DIR *dp;
						struct stat v;
						if(argc!=2)
						{
							printf("usage ./a.out -i\n");
							return;
						}

						dp=opendir(".");
						if(dp==0)
						{
							perror("opendir");
							return;
						}

						while(p=readdir(dp))
							if(p->d_name[0]!='.')
							{ 	
								//	perror("readdir:");
								stat(p->d_name,&v);
								printf("%u %s  ",v.st_ino,p->d_name);
							}
						printf("\n");
					}
					break;

					case 's':
					{
						//printf("-s\n");

						struct dirent *p;
						DIR *dp;
						struct stat v;
						if(argc!=2)
						{
							printf("usage ./a.out -s\n");
							return;
						}

						dp=opendir(".");
						if(dp==0)
						{
							perror("opendir");
							return;
						}

						while(p=readdir(dp))
							if(p->d_name[0]!='.')
							{ 	
								lstat(p->d_name,&v);
								printf("%d %s  \n",v.st_blocks/2,p->d_name);
							}
						printf("\n");
					}
					break;
					default :
					{
						printf("no\n");

					}
				}
		}
	}

}





