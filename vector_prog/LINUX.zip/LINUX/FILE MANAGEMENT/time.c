#include"header.h"
main()
{
time_t t1;


printf("t1=%d\n",time(&t1));

printf("%s\n",ctime(&t1));

}
