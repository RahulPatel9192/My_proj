//write a programe to serch file in given directory

#include"header.h"
main(int argc,char **argv)
{

	struct dirent *p;
	DIR *dp;

	if(argc!=3)
	{
		printf("usage ./a.out filename path..\n");
		return;
	}

	dp=opendir(argv[2]);
	if(dp==0)
	{
		perror("opendir");
		return;
	}

	while(p=readdir(dp))
	{
		if(strcmp(p->d_name,argv[1])==0)
		{	
			printf("file %s is present\n",p->d_name);
			return;
		}
		}
	printf("file is not present...\n");

}
