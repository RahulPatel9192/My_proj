//ls-l
#include"header.h"
main(int argc,char **argv)
{
	struct dirent *p;
	DIR *dp;
	struct stat v,v1;
	time_t t1;
	if(argc!=1)
	{
		printf("usage ./a.out \n");
		return;
	}

	dp=opendir(".");
	if(dp==0)
	{
		perror("opendir");
		return;
	}
	printf("mode  nlink  uid  gid  size  mtime filename\n");
	while(p=readdir(dp))
	{
		if(p->d_name[0]!='.')		
		{
			lstat(p->d_name,&v1);
			if(S_ISLNK(v1.st_mode))
				printf("l   %d   %u   %u   %d   %u  %s\n",v1.st_nlink,v1.st_uid,v1.st_gid,v1.st_size,v1.st_mtime,p->d_name);
			else
			{
				stat(p->d_name,&v);
				if(S_ISREG(v.st_mode))
					printf("r   %d   %u   %u   %d   %u  %s\n",v.st_nlink,v.st_uid,v.st_gid,v.st_size,v.st_mtime,p->d_name);
				else if(S_ISDIR(v.st_mode))
					printf("d   %d   %u   %u   %d   %u  %s\n",v.st_nlink,v.st_uid,v.st_gid,v.st_size,v.st_mtime,p->d_name);
			}
		}
		else
			;
	}

	//printf("\n");

}
