#include<stdio.h>
#include<signal.h>
void my_isr(int n)
{
static i,j;
printf("in isr...\n");
if(n==2)
{
i++;
if(i>=3)
{
signal(SIGINT,SIG_DFL);
}
}

if(n==3)
{
j++;
if(j>=5)
signal(SIGQUIT,SIG_DFL);
}

}


main()
{

signal(2,my_isr);
signal(3,my_isr);

while(1);


}
