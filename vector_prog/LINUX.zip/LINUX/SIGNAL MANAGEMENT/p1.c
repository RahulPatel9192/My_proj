#include<stdio.h>
#include<signal.h>
int r,i;
void my_isr(int n)
{
	printf("in isr...i=%d\n",i);
	if(i>0)
	{
		i--;
		alarm(i);
	}
}
main()
{
	i=10;
	printf("before alarm...\n");
	signal(SIGALRM,my_isr);
	alarm(i);
	printf("\n");
	while(1);

}
