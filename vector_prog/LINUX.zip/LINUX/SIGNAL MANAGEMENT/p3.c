#include<stdio.h>
#include<signal.h>
void (*p)(int);
void find_isr(int n)
{
printf("in find_isr...\n");

if(p==SIG_DFL)
printf("Default...\n");
else if(p==SIG_IGN)
printf("Ignore...\n");
else
printf("isr...\n");

signal(n,p);
}
main()
{
int n;
printf("enter the signal nu...\n");
scanf("%d",&n);
//signal(n,find_isr);
p=signal(n,find_isr);
while(1);
}
