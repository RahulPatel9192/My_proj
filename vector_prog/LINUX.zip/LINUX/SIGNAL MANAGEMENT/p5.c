#include<stdio.h>
#include<signal.h>
main()
{
printf("helloo....pid=%d\n",getpid());
signal(SIGHUP,SIG_IGN);
while(1);


}
