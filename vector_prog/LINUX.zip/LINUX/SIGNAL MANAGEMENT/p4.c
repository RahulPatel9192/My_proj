#include<stdio.h>
#include<signal.h>
void my_isr(int n)
{
printf("in isr...\n");
wait(0);
printf("quit isr...\n");
}
main()
{
if(fork()==0)
{
printf("in child...\n");
sleep(10);
printf("after sleep zombie...\n");
}
else
{
printf("in parent...\n");
signal(SIGCHLD,my_isr);

while(1);
}
}
