#include"header.h"
main()
{
struct rlimit v;
//getrlimit(RLIMIT_STACK,&v);
getrlimit(RLIMIT_CORE,&v);
printf("softlimit=%u     hardlimit=%u\n",v.rlim_cur,v.rlim_max);

v.rlim_cur=1000;
//setrlimit(RLIMIT_STACK,&v);
setrlimit(RLIMIT_CORE,&v);
//getrlimit(RLIMIT_STACK,&v);
getrlimit(RLIMIT_CORE,&v);
printf("softlimit=%u     hardlimit=%u\n",v.rlim_cur,v.rlim_max);
while(1);
}
