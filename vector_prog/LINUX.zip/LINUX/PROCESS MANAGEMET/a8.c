#include<stdio.h>
main()
{
	if(fork()==0)
	{
		printf("1) pid=%d  ppid=%d\n",getpid(),getppid());
		system("pwd");

		if(fork()==0)
		{
			printf("2) pid=%d  ppid=%d\n",getpid(),getppid());
		        system("cal");


			if(fork()==0)
			{
				printf("3) pid=%d  ppid=%d\n",getpid(),getppid());
		                system("date");
			}
			else
			while(1);
		}
		else
			while(1);
			
	}
	else
	{
		printf("in parent..\n");
		system("ls");
		while(1);
	}
}
	
