#include<stdio.h>
main()
{
	if(fork()==0)
	{
		printf("1) pid=%d  ppid=%d\n",getpid(),getppid());

		if(fork()==0)
		{
			printf("2) pid=%d  ppid=%d\n",getpid(),getppid());


			if(fork()==0)
			{
				printf("3) pid=%d  ppid=%d\n",getpid(),getppid());
			}
			else
			while(1);
		}
		else
			while(1);
			
	}
	else
		while(1);

}

