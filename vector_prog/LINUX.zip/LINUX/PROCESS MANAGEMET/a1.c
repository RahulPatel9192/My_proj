#include<stdio.h>
main()
{
	if(fork()==0)
	{
		system("ls");
		printf("\n");
	}
	else
	{
		if(fork()==0)
		{
			system("pwd");
			printf("\n");
		}
		else
		{
			if(fork()==0)
			{
				system("cal");
				printf("\n");
			}
			else
			{
				while(1);
			}

		}
	}


}
