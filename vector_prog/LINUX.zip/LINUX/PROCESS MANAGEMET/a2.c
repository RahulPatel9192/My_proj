#include<stdio.h>
#include<unistd.h>
main(int argc,char **argv)
{

if(argc!=3)
{
printf("usage. /a.out cmd op..\n");
return;
}

execlp(argv[1],argv[1],argv[2],NULL);


}
