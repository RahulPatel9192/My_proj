#include<stdio.h>
#include<stdlib.h>
main()
{
	if(fork()==0)
	{//c1
		int r;
		srand(getpid());
		r=rand()%10+1;
		printf("in c1 r=%d\n",r);
		sleep(r);
		printf("c1...\n");
		exit(1);
	}
	else
	{//p

		if(fork()==0)
		{//c2
			int r;
			srand(getpid());
			r=rand()%10+1;
			printf("in c2 r=%d\n",r);
			sleep(r);
			printf("c2...\n");
			exit(2);
		}
		else
		{

			if(fork()==0)
			{//c3
				int r;
				srand(getpid());
				r=rand()%10+1;
				printf("in c3 r=%d\n",r);
				sleep(r);
				printf("c3...\n");
				exit(3);
			}
			else
			{//p
				int s;
				while(wait(0)!=-1);
				printf("Done...\n");

				while(wait(&s)!=-1);
				{
					s=s>>8;
					if(s==1)
						printf("c1...\n");
					else if(s==2)
						printf("c2...\n");
					else if(s==3)
						printf("c3...\n");
				}


			}
		}
	}
}
