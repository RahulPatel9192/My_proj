//randam nu generation
#include<stdio.h>
#include<stdlib.h>
main()
{
int s,i;
srand(getpid());
for(i=0;i<5;i++)
{
s=rand();		//generate any nu
//s=rand()%10;		//genertae  any nu bet 0-9
//s=rand()%100;		//generate  any nu bet 0-99
printf("%d ",s);
}
printf("\n");
}
