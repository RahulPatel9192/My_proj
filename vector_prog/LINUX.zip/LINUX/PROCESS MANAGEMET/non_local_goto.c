//non local goto
#include<stdio.h>
#include<setjmp.h>
jmp_buf v;
void print(void);
main()
{
setjmp(v);
printf("hello...\n");
print();
printf("hai...\n");
}
void print(void)
{
printf("in print...\n");
longjmp(v,1);

}

