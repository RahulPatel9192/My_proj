#include<stdio.h>
#include<unistd.h>
main()
{
int ret;
printf("hello..\n");
ret=fork();

if(ret==0)
{//child

printf("in child...\n");
}

else
{//parent
printf("in parent...\n");

}
while(1);
}
