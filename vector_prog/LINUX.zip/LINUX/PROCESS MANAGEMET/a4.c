#include<stdio.h>
main(int argc,char **argv)
{
char a[10];
int i,j=0;
if(argc!=2)
{
printf("usage ./a.out cmd");

}

for(i=0;argv[1][i];i++)
{
if(argv[1][i]!=',')
{
a[j]=argv[1][i];
j++;
}
 if(argv[1][i]==',' || argv[1][i+1]=='\0')
{

a[j]='\0';

j=0;
system(a);

}
}
}

