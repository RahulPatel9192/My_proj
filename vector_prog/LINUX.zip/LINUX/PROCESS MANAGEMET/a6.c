#include<stdio.h>
main()
{
	if(fork()==0)
	{
		printf("1)pid=%d ppid=%d\n",getpid(),getppid());
	}

	else
	{
		if(fork()==0)
		{
			printf("2)pid=%d ppid=%d\n",getpid(),getppid());

		}
		else
		{
			if(fork()==0)
				printf("3)pid=%d ppid=%d\n",getpid(),getppid());
			else
			while(1);
		}



	}

}
