//fork function
#include<stdio.h>
#include<unistd.h>
main()
{
printf("hello...\n");
fork();
fork();
fork();
printf("Hai...\n");
while(1);


}
