//system() fun.

#include<stdio.h>
main()
{
printf("Hello...\n");
system("ls -l");
printf("hai...\n");


}
