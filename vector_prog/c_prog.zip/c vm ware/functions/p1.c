//print binary

#include<stdio.h>
void print_binary(int);    //fun prototype

main()
{
int num;
printf("Enter nu....");
scanf("%d",&num);
print_binary(num);   //fun call
printf("\n");

}

void print_binary(int n)   //fun defination
{
int i;
for(i=31;i>=0;i--)
printf("%d",n>>i&1);






}

