#include<stdio.h>
void my_strcat(char *,char *);
main()
{
char f[20],s[20];

printf("Enter 1st string...");
scanf("%s",f);
printf("Enter 2nd string...");
scanf(" %s",s);

my_strcat(f,s);
}
void my_strcat (char *p,char *q)
{
int i,j;
for(i=0;p[i];i++);

for(j=0;q[j];j++,i++)
p[i]=q[j];
p[i]='\0';
printf("%s\n",p);



}
