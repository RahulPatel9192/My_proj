#include<stdio.h>
void print_array(const int *,int);
main()
{
int s[]={10,20,30,40,50},ele;

ele=sizeof(s)/sizeof(s[0]);
print_array(s,ele);
printf("\n");

}
void print_array(const int *s,int ele)
{
int i;

for (i=0;i<ele;i++)
printf("%d ",s[i]);

}
