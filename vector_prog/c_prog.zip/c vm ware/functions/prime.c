#include<stdio.h>
int prime(int);
main()
{
int num;
printf("Enter the number=");
scanf("%d",&num);

if(prime(num))
printf("not prime\n");
else
printf("prime\n");
printf("\n");
}
int prime(int num)
{
int i,c=0;
for(i=1;i<=num;i++)
if(num%i==0)
c++;
 
if(c==2)
return 0;
else
return 1;

}
