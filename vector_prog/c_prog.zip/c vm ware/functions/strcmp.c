#include<stdio.h>
int my_strcmp(const char *,const char *);
main()
{
char p[10],q[10];
int r;
printf("Enter p string...");
scanf("%s",p);
printf("Enter q string....");
scanf("%s",q);

r=my_strcmp(p,q);
printf("%d",r);
printf("\n");
}

int my_strcmp(const char *p,const char *q)
{
int i,j;
for (i=0;p[i] && q[i];i++)
{
if (p[i]!=q[i])
break;

}

if(p[i]==q[i])
return 0;
else if(p[i]>q[i])
return 1;
else
return -1;
}
