//count how many zero or one in binary

#include<stdio.h>
int count(int);
main()
{
int num,r;
printf("Enter value...");
scanf("%d",&num);

r=count(num);
printf("r=%d\n",r);
}

int count(int n)
{
int i,c=0;

for(i=31;i>=0;i--)
if(n&1<<i)
{
printf("1");
c++;

}
else
printf("0");
printf("\n");
return c;
}
