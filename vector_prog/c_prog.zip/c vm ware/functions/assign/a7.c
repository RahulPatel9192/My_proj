#include<stdio.h>
f1(int a,int b)
{
return(f2(20));
}
f2(int a)
{
return (a*a);
}
main()
{
int a,b;
scanf("%d %d",&a,&b);
c=f1(a,b);
}
