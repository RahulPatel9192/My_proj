#include<stdio.h>
main()
{
int i;
printf("\nall the best");
for(i=0;i<5;i++)
main();


}
