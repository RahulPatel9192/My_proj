#include<stdio.h>
int zap(int n)
{
if(n<=1)
return(1);
else
return(zap(n-3)+zap(n-1));
}
main()
{
int n,n1;
printf("n=");
scanf("%d",n);
n1=zap(n);
printf("n1=%d\n",n1);
}
