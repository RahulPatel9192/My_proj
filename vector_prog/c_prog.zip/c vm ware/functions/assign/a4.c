#include<stdio.h>
F(int a,int b)
{
int c;
c=20;
return c;

}
main()
{
int a,b,s;
scanf("%d %d",a,b);
s=F(a,b);



}
