#include<stdio.h>
main()
{
int b;
b=f(20);
printf("%d",b);

}
int f(int a)
{
(a>20)?return(10):return(20);



}
