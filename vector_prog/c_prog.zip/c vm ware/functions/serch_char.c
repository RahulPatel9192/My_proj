#include<stdio.h>
int serch(const char *,char);
main()
{
char s[20],ch;
int c;
printf("Enter string...");
scanf("%s",s);
printf("Enter the char...");
scanf(" %c",&ch);

c=serch(s,ch);
printf("%c is present %d times\n",ch, c);
printf("\n");
}

int serch(const char *s,char ch)
{
int i,c=0;

for(i=0;s[i];i++)
{
if(s[i]==ch)
c++;

}
return c;


}
