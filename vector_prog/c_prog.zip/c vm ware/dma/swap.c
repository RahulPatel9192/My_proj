//swapng string...

#include<stdio.h>
#include<string.h>
main()
{
	char **p,*temp;
	int n,i,r,j;

	printf("Enter the nu....\n");
	scanf("%d",&n);


	p=malloc(sizeof(char*)*n);

	for(i=0;i<n;i++)
		p[i]=malloc(10);

	printf("Enter data...\n");

	for(i=0;i<n;i++)
		scanf("%s",p[i]);
	printf("--------------------------------\n");

	for(i=0;i<n;i++)
		printf("%s\n",p[i]);

	printf("\n");

	printf("--------------------------------\n");

	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{		
			r=strcmp(p[i],p[j]);

			//printf("i=%d j=%d\n",i,j);
			if(r==1)
			{
				temp=p[i];
				p[i]=p[j];
				p[j]=temp;
			}
		}		
	}
	for(i=0;i<n;i++)
		printf("%s\n",p[i]);

}
