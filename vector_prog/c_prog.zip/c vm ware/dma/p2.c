//malloc/calloc...allocaring memory for n int

#include<stdio.h>
#include<stdlib.h>
main()
{
int *p,n,i;

printf("Enter the number\n");
scanf("%d",&n);
//p=malloc(sizeof(int)*n);
p=calloc(n,sizeof(int));

printf("enter the element..\n");
for(i=0;i<n;i++)
scanf("%d",&p[i]);

for(i=0;i<n;i++)
printf("%d ",p[i]);
printf("\n");

}
