//malloc/calloc..allocating memory for 1 string

#include<stdio.h>
#include<stdlib.h>
main()
{
char *p;

//p=malloc(10);
p=calloc(10,sizeof(char));
printf("Enter the string...");
scanf("%s",p);
printf("%s\n",p);



}
