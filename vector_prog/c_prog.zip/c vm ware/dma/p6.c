// malloc/calloc...allocating a memory for int 2D array...

#include<stdio.h>
#include<stdlib.h>
main()
{
	int **p,r,c,i,j;

	printf("Enter row...");
	scanf("%d",&r);

	printf("Enter coloum...");
	scanf("%d",&c);

	///////////////////////////////// 2D array memory allocated
	p=malloc(sizeof(int*)*r);
	//p=calloc(r,sizeof(int*));

	for(i=0;i<r;i++)
		p[i]=malloc(sizeof(int)*c);

	//////////////////////////////////////// scan
	printf("Enter the element...\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
			scanf("%d",p[i][j]);
	}
	///////////////////////////////////  print

	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
			printf("%d",p[i][j]);



	}
}
