//calloc/malloc...allocating memory for n string

#include<stdio.h>
#include<stdlib.h>
main()
{

char **p;
int i,n;

printf("Enter number...");
scanf("%d",&n);

p=malloc(sizeof(char*)*n);


for(i=0;i<n;i++)
//p[i]=malloc(10);
p[i]=calloc(10,sizeof(char));
printf("Enter the data...\n");

for(i=0;i<n;i++)
scanf("%s",p[i]);
printf("-------------------------------------------\n");
for(i=0;i<n;i++)
printf("%s\n",p[i]);



}
