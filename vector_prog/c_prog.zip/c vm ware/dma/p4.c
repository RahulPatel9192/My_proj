//calloc/malloc...allocating memory for 5 string

#include<stdio.h>
#include<stdlib.h>
main()
{

char *p[5];
int i;
for(i=0;i<5;i++)
//p[i]=malloc(10);
p[i]=calloc(10,sizeof(char));
printf("Enter the data...\n");
for(i=0;i<5;i++)
scanf("%s",p[i]);
printf("-------------------------------------------\n");
for(i=0;i<5;i++)
printf("%s\n",p[i]);



}
