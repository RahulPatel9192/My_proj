//malloc/calloc.....allocating memory for 1 int..

#include<stdio.h>
#include<stdlib.h>
main()
{
int *p;
p=calloc(1,sizeof(int));
//p=malloc(sizeof(int));
printf("Enter number...\n");
scanf("%d",p);
printf("%d\n",*p);


}
