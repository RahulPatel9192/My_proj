#include <stdio.h>
main()
{
unsigned int x=500;
int y=-5;
if(x>y)
printf("hello\n");
else
printf("hiee\n");



}

