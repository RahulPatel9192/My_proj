#include<stdio.h>
main()
{
int i=6,j=55,k;
printf("before swap i=%d j=%d k=%d\n",i,j,k);
/*k=i;
i=j;
j=k;*/
//j=i+j-(i=j);
j=i^j^(i=j);
printf("after swap i=%d j=%d k=%d\n",i,j,k);




}
