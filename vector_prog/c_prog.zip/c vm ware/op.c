#include<stdio.h>
main()
{
int i,j;
printf("enter the value..\n");
scanf("%d %d",&i,&j);
i=i^j;
j=i^j;
i=i^j;
printf("i=%d  j=%d",i,j);





}
