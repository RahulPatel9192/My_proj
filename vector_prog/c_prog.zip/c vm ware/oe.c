#include<stdio.h>
main()
{
int i,j;
printf("enter the nu=\n");
printf("%d",i);
scanf("%d",&i);
j=(i%2);
printf("j=%d\n",j);
if(j==0)
{
printf("the nu is even\n");
}
else
printf("the nu is odd\n");




}
