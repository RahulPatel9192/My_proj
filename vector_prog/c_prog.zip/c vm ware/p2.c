#include <stdio.h>
main()
{
int i;
printf("enter the number=\n");
scanf("%d",&i);
printf("i=%d\n",i);




}
