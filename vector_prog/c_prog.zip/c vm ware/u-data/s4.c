//allocat a memory for array of pointer

#include<stdio.h>
#include<stdlib.h>

struct st
{
int i;
char ch;
float f;
};
main()
{
int i;
struct st *p[2];
for(i=0;i<2;i++)
p[i]=malloc(sizeof (struct st));

printf("Enter int char float\n");
for(i=0;i<2;i++)
{
//scanf("%d %c %f",&p[i]->i,&p[i]->ch,&p[i]->f);
scanf(" %d",&p[i]->i);
scanf(" %c", &p[i]->ch);
scanf(" %f", &p[i]->f);
}

for(i=0;i<2;i++)
{
printf("%d %c %f\n", p[i]->i,p[i]->ch,p[i]->f);
//printf("%c ", p[i]->ch);
//printf("%f ", p[i]->f);
}

printf("\n");


}

