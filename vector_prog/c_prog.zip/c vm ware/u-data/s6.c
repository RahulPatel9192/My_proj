//passing structure to function...

#include<stdio.h>
struct a
{
int i;
char ch;
float f;
};

void print(int,char,float);
void print1(struct a);
void print2(struct a*);
main()
{
struct a a1={10,'a',22.5};

print(a1.i,a1.ch,a1.f);               //call by value
print1(a1);			   //call by value
print2(&a1);			//call by refrence
printf("main %d %c %f\n",a1.i,a1.ch,a1.f);
}

void print(int i,char ch,float f)
{
printf("%d %c %f\n",i,ch ,f);
}

void print1(struct a s)
{
printf("%d %c %f\n",s.i,s.ch,s.f);
}
void print2(struct a *p)
{
printf("%d %c %f\n",p->i,p->ch,p->f);
p->i=100;
p->ch='z';
p->f=34.5;

}

