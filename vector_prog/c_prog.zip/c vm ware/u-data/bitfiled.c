#include<stdio.h>
struct a
{
unsigned int i:3;   
};

main()
{
struct a a1;
a1.i=3;
printf("%d\n",a1.i);



}
