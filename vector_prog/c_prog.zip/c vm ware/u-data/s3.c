// how to allocate a memory in struct

#include<stdio.h>
struct st
{
int i;
char ch;
float f;
};
main()
{
struct st *p;
/*
struct st s1={10,'a',22.5};

p=&s1;
printf("%d %c %f\n",p->i,p->ch,p->f);
*/

p=malloc(sizeof(struct st));
scanf("%d %c %f",&p->i,&p->ch,&p->f);
printf("\n");
printf("%d %c %f\n",p->i,p->ch,p->f);



}
