//nested struct

#include<stdio.h>
struct date
{
int date;
int month;
int year;
};


struct st
{
int i;
char ch;
float f;
struct date dob;
struct date doj;
};
main()
{
struct st s1;

s1.dob.date=1;
s1.dob.month=1;
s1.dob.year=2000;

s1.doj.date=1;
s1.doj.month=1;
s1.doj.year=2010;

printf("%d %d %d\n",s1.dob.date,s1.dob.month,s1.dob.year);
printf("%d %d %d\n",s1.doj.date,s1.doj.month,s1.doj.year);


}


