//typedef in struct

#include<stdio.h>
typedef struct st
{
int rollno;
char names[10];
float marks;
}ST;
main()
{
ST s1={10,'a',22.5};
s1.rollno=10;
//s1.name="abc"      //invalid   coz s1.name is base address of array so we cant write it
strcpy(s1.name,"abc");
s1.marks=22.5;

}

