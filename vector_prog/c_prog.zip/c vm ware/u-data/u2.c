//print binary format of float using union

#include<stdio.h>
union u
{
int i;
float f;
};
main()
{
union u u1;
int i;
u1.f=3.5;
for(i=31;i>=0;i--)
printf("%d",u1.i>>i&1);
printf("\n");
}
