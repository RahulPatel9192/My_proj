//wap to  prove we are working on littile endine or big...

#include<stdio.h>
union u
{
int i;
char ch;
};
main() 
{
union u u1;
u1.i=01;
u1.ch?printf("little\n"):printf("big\n");


}
