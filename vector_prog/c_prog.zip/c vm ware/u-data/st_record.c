#include<stdio.h>
#include<string.h>
struct st
{
char name[10];
int rollno;
float marks;
}
main()
{
struct st s1[5];
int c,i,j,v,tempr;
float tempm;
char temp[10];
for(i=0;i<5;i++)
{
printf("Enter name...");
scanf("%s",s1[i].name);
printf("Enter rollno...");
scanf("%d",&s1[i].rollno);
printf("Enter marks...");
scanf("%f",&s1[i].marks);
}
printf("\n");

printf("sorting\n1)sorting by name\n2)sorting by rollno\n3)sorting by marks\n");
scanf("%d",&c);


	switch(c)
	{
		case 1:

			for(i=0;i<5;i++)
			{
				for(j=i+1;j<5;j++)
				{
					v=strcmp(s1[i].name,s1[j].name);

					if(v==1)
					{
						strcpy(temp,s1[i].name);
						strcpy(s1[i].name,s1[j].name);
						strcpy(s1[j].name,temp);

						tempm=s1[i].marks;
						s1[i].marks=s1[j].marks;
						s1[j].marks=tempm;

						tempr=s1[i].rollno;
						s1[i].rollno=s1[j].rollno;
						s1[j].rollno=tempr;

					}

				}		
			}
			break;

		case 2:

			for(i=0;i<5;i++)
			{
				for(j=i+1;j<5;j++)
				{
					

					if(s1[i].rollno>s1[j].rollno)
					{
						strcpy(temp,s1[i].name);
						strcpy(s1[i].name,s1[j].name);
						strcpy(s1[j].name,temp);

						tempm=s1[i].marks;
						s1[i].marks=s1[j].marks;
						s1[j].marks=tempm;

						tempr=s1[i].rollno;
						s1[i].rollno=s1[j].rollno;
						s1[j].rollno=tempr;

					}

				}		
			}
			break;

		case 3:

			for(i=0;i<5;i++)
			{
				for(j=i+1;j<5;j++)
				{
			

					if(s1[i].marks>s1[i].marks)
					{
						strcpy(temp,s1[i].name);
						strcpy(s1[i].name,s1[j].name);
						strcpy(s1[j].name,temp);

						tempm=s1[i].marks;
						s1[i].marks=s1[j].marks;
						s1[j].marks=tempm;

						tempr=s1[i].rollno;
						s1[i].rollno=s1[j].rollno;
						s1[j].rollno=tempr;

					}

				}		
			}
			break;
default :
printf("Enter proper option...\n");
}

printf("name	 rollno		marks\n");

for(i=0;i<5;i++)
printf("%s	 %d	 %f\n",s1[i].name,s1[i].rollno,s1[i].marks);
printf("\n");
}
