#include<stdio.h>
union u
{
int i;
char ch;
char ch1;
};
main()
{
union u u1;
u1.i=258;
printf("%u %u %u\n",&u1.i,&u1.ch,&u1.ch1);
u1.ch='a';
printf("%u %u %u\n",&u1.i,&u1.ch,&u1.ch1);
}
