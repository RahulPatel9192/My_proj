//typedef for pointer...

#include<stdio.h>
typedef int *IPTR;
main()
{
int i=10,j=20;
IPTR p;
p=&i;
printf("%d\n",*p);


}
