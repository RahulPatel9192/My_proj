//function pointer...

#include<stdio.h>
typedef int(*fptr)(int,int);

int sum(int,int);
main()
{
fptr p1;
p1=sum;
printf("%d\n",p1(10,20));

}

int sum(int i,int j)
{
return i+j;

}
