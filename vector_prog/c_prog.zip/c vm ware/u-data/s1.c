#include<stsio.h>
struct A
{
int i;
char ch;
float f;

}
main()
{
struct A a1;		//a1 is a variable of struct a type

// assignment value of a1
a1.i=10;
a1.ch='a';
a1.f=3.5;

/*
struct A a1={10,'a',23.5}
*/
}
