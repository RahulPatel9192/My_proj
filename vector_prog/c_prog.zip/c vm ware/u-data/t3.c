//typedef for array...
#include<stdio.h>
typedef int array[5];
main()
{
int i;
array a1;
//array a2[3];					//it works as 2D array
printf("%d\n",sizeof(a1));

for(i=0;i<5;i++)
scanf("%d",&a1[i]);

for(i=0;i<5;i++)
printf("%d ",a1[i]);

}
