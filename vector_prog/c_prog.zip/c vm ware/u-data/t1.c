#include<stdio.h>
typedef unsigned char UCHAR;
main()
{
UCHAR c1;
printf("%d\n",sizeof(c1));



}
