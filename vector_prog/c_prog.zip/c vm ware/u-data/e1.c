#include<stdio.h>
//enum{black,white,red,blue};
//enum{black=-1,white,red,blue};
enum{black=-1,white,red=10,blue};
main()
{
printf("%d\n",black);
printf("%d\n",white);
printf("%d\n",red);
printf("%d\n",blue);


}
