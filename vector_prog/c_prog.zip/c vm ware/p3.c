#include<stdio.h>
main()
{
	int i,j,n=0,k,m;
        printf("enter the rows-\n");
        scanf("%d",&m);	
	for(i=1;i<=m;i++)
	{   n=i;
		for(j=1,n=0;j<=i;j++)
		{                            
			k=i+n;
			printf("%d ",k);
			n=n+m-j;
                        
                      

                    
                        
                      
			//n--;

			//	printf("%d",k);
			// k=i+n;
			// n--;
			//	printf("%d",k);

                     

		}
		printf("\n");
	}
}
