//count how many char
#include<stdio.h>
main(int argc,char **argv)
{
FILE *fp,*fp1;
char ch;
int c=0;
if(argc!=3)
{
printf("usage:,/a.out char char\n");
return;
}
fp=fopen(argv[1],"r");
if(fp==0)
{
printf("file not present...\n");
return;
}

while((ch=fgetc(fp))!=EOF)

if(ch==argv[2][0])
c++;

printf("nu of times char repeted=%d\n",c);


}
