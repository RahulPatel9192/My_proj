#include<stdio.h>
main(int argc,char **argv)
{
FILE *fp,*fp1;
char ch,ch1;
int i,c=0;
if(argc!=2)
{
printf("usage ./a.out filename\n");
return;
}

fp=fopen(argv[1],"r");
if(fp==0)
{
printf("file is not present\n");
return;
}
fp1=fopen("data1","w");

while((ch=fgetc(fp))!=EOF)
{
c++;
}



i=0;
//while((ch=fgetc(fp))=='\0')

fseek(fp,-1,SEEK_END);
while(i<=c)
{
ch=fgetc(fp);
fseek(fp,-2,SEEK_CUR);
fputc(ch,fp1);

i++;
}


}
