// Write a Program to merges the lines from two files and store the result into another file.


#include<stdio.h>
#include<string.h>
main(int argc,char **argv)
{
FILE *fp,*fp1,*fp2;
char a[100],b[100];
if(argc!=4)
{
printf("usage ./a.out filename filename filename\n");
return;
}


fp1=fopen(argv[1],"r");
fp2=fopen(argv[2],"r");
fp=fopen(argv[3],"w");
if(fp1==0 && fp2==0)
{
printf("file is not present\n");
return;
}
//////////////////////////////////////////////////////////

while((fgets(a,100,fp1)) && (fgets(b,100,fp2)))
{
fputs(a,fp);
fputs(b,fp);
}
if(a!=0)
fputs(a,fp);

while(fgets(a,100,fp1))
fputs(a,fp);

while(fgets(b,100,fp2))
fputs(b,fp);


}
