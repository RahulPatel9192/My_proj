#include<stdio.h>
main(int argc,char **argv)
{
	FILE *fp,*fp1;
	char ch,a[100];
	int c=0,l;

	printf("line=");
	scanf("%d",&l);

	if(argc!=2)
	{
		printf("usage. ./a.out filename\n");
		return;
	}

	fp1=fopen("data1","w");
	fp=fopen(argv[1],"r");
	if(fp==0)
	{
		printf("file is not present\n");
		return;
	}

	while(fgets(a,100,fp))
	{
		c++;
		if(c!=l)
		{
			fputs(a,fp1);
		}
	}
	rewind(fp);
	rewind(fp1);
	fp1=fopen("data1","r");
	fp=fopen(argv[1],"w");


	while(fgets(a,100,fp1))
	{

		fputs(a,fp);

	}

}
