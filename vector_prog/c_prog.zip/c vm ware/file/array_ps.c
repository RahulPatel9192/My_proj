#include<stdio.h>
main()
{
FILE *fp;
/*int a[5]={10,20,30,40,50},i;
fp=fopen("data","w");
for(i=0;i<5;i++)	//printf using print the data in monitor 
fprintf(fp,"%d ",a[i]); 	//fprintf using print the data in file
*/
////////////////////////////////////////////	fscanf

int a[5],i;
fp=fopen("data","r");
for(i=0;i<5;i++)
fscanf(fp,"%d",&a[i]);	//fscanf using to scan data in file
for(i=0;i<5;i++)
printf("%d\n",a[i]);

}
