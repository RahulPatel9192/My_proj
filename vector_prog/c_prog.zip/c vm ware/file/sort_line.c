#include<stdio.h>
#include<string.h>
#include<stdlib.h>
main(int argc,char **argv)
{
FILE *fp;
int c=0,c1=0,c2=0,i,j;
char ch,**p,*temp;
if(argc!=2)
{
printf("usage ./a.out filename\n");
return;
}

fp=fopen(argv[1],"r");
if(fp==0)
{
printf("file is not present\n");
return;
}
/////////////////////////////////////////////line  char
while((ch=fgetc(fp))!=EOF)
{
c++;
if(ch=='\n')
{
c2++;		//c2=line
if(c>c1)
c1=c;		//c1=max char
c=0;
}
}
///////////////////////////////////////		allocte memory
rewind(fp);
//printf("c1=%d c2=%d\n",c1,c2);
p=malloc(sizeof(char*)*c2);

for(i=0;i<=c2;i++)
p[i]=malloc(sizeof(char)*c1);
///////////////////////////////////////////
for(i=0;i<=c2;i++)
{
fgets(p[i],c1,fp);
}
for(i=0;i<=c2;i++)
printf("%s",p[i]);
//printf("\n");
/////////////////////////////////////////////	sorting

rewind(fp);

for(i=0;i<=c2;i++)
{
for(j=i+1;j<=c2;j++)
{
if(strlen(p[i])>strlen(p[j]))
{
temp=p[i];
p[i]=p[j];
p[j]=temp;
}
}
}
/////////////////////////////////////
fp=fopen(argv[1],"w");
for(i=0;i<=c2;i++)
//printf("%s",p[i]);
fputs(p[i],fp);


}
