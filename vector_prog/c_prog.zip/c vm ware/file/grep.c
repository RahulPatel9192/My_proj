#include<stdio.h>
#include<string.h>
#include<stdlib.h>
main(int argc,char **argv)
{
FILE *fp;
char *p;
int c=0,c1=0;
if(argc!=3)
{
printf("usage:./a.out char file\n");
return;
}

fp=fopen(argv[2],"r");
if(fp==0)
{
printf("file is not present\n");
return;
}
///////////////////////////////////////////////////
while(fgetc(fp)!=EOF)
c++;

////////////////////////////////////////////////
rewind(fp);

p=malloc(sizeof(int)*c);


while(fgets(p,c,fp))
{
c1++;
if(strstr(p,argv[1]))
printf("%d  %s",c1,p);
//printf("\n");
}



}
