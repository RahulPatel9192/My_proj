//replace char
#include<stdio.h>
#include<stdlib.h>
main(int argc,char **argv)
{
FILE *fp;
char ch,*p;
int c=0,i;
if(argc!=4)
{
printf("usage:,/a.out filename char char\n");
return;
}
fp=fopen(argv[1],"r+");
if(fp==0)
{
printf("file not present...\n");
return;
}
////////////////////////////////// size of file
while(fgetc(fp)!=EOF)
c++;
///////////////////////////////allocate memory
p=malloc(c+1);

////////////////////////////
rewind(fp);
////////////////////////////////////
i=0;
while ((ch=fgetc(fp))!=EOF)
p[i++]=ch;
p[i]='\0';

/////////////////////////////////  changes store in arry
for(i=0;p[i];i++)
if(p[i]==argv[2][0])
p[i]=argv[3][0];
printf("%s\n",p);
///////////////////////////////
rewind(fp);
for(i=0;p[i];i++)
fputc(p[i],fp);
//fputs(p,fp);

}
