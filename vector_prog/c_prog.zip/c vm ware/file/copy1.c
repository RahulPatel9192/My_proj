//multiple files are cpy

#include<stdio.h>
main(int argc,char **argv)
{
FILE *fp,*fp1;
int i;
char ch;
if(argc<=3)
{
printf("usage:../a.out sf df\n");
return;
}



fp=fopen(argv[1],"r");
if(fp==0)
{
printf("file not present\n");
return;
}

for(i=1;i<argc-1;i++)
{
fp=fopen(argv[1],"r");
fp1=fopen(argv[i+1],"w");
while((ch=fgetc(fp))!=EOF)
fputc(ch,fp1);
}
printf("\n");
}
