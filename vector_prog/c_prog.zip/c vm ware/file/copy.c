#include<stdio.h>
main(int argc,char **argv)
{
FILE *fp,*fp1;
char ch;

if(argc!=3)
{
printf("usage:,/a.out sf df\n");
return;
}
fp=fopen(argv[1],"r");
if(fp==0)
{
printf("file not present...\n");
return;
}

fp1=fopen(argv[2],"w");
while((ch=getc(fp))!=EOF)
fputc(ch,fp1);


}
