#include<stdio.h>
#include<string.h>
main(int argc,char **argv)
{
	FILE *fp;
	int c=0,c1=0;
	char ch;
	if(argc!=2)
	{
		printf("usage./a.out filename\n");
		return;
	}

	fp=fopen(argv[1],"r");
	if(fp==0)
	{
		printf("File is not preent...\n");
		return;
	}
	/////////////////////////////////////////////////
	while((ch=fgetc(fp))!=EOF)
	{
		c++;
		if(ch=='\n')
		{
			if(c>c1)
				c1=c;
			c=0;

		}





	}
	printf("max length=%d\n",c1);
}
