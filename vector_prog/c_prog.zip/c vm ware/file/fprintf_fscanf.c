#include<stdio.h>
main()
{
FILE *fp;
/*int i=100;
fp=fopen("data","w");
printf("%d\n",i);	//printf using print the data in monitor 
fprintf(fp,"%d",i); 	//fprintf using print the data in file
*/
////////////////////////////////////////////	fscanf

int i;
fp=fopen("data","r");
fscanf(fp,"%d",&i);	//fscanf using to scan data in file
printf("%d\n",i);
}
