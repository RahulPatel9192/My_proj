//cpy file if usr want

#include<stdio.h>
main(int argc,char **argv)
{
FILE *fp,*fp1;
char ch,op;

if(argc!=3)
{
printf("usage:,/a.out sf df\n");
return;
}

fp=fopen(argv[1],"r");
if(fp==0)
{
printf(" source file is not present...\n");
return;
}


fp1=fopen(argv[2],"r");
if(fp1)
{
printf("destintion file is present\ncontinue y or n\n");
scanf("%c",&op);

fp1=fopen(argv[2],"w");
while((ch=getc(fp))!=EOF)
fputc(ch,fp1);
switch(op)
{
case 'y':
fp1=fopen(argv[2],"w");
while((ch=getc(fp))!=EOF)
fputc(ch,fp1);
break;
case 'n':
return;
default:
printf("choose valid option\n");

}
}
fp1=fopen(argv[2],"w");
while((ch=getc(fp))!=EOF)
fputc(ch,fp1);

}
