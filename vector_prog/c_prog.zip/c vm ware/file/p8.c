#include<stdio.h>
#include<string.h>
main(int argc,char **argv)
{
	FILE *fp,*fp1;
	char a[50],b[50];
	int d,i,j;

	if(argc!=4)
	{
		printf("usage ./a.out filename char char\n");
		return;
	}


	fp=fopen(argv[1],"r");
	if(fp==0)
	{
		printf("file is not present\n");
		return;
	}

//	i=strlen(argv[2]);
//	j=strlen(argv[3]);
	fp1=fopen("data1","w");
	while(fscanf(fp,"%s",a)!=EOF)
	{
		if(strcmp(a,argv[2])==0)
		{
			fprintf(fp1,"%s",argv[3]);
			fputc(' ',fp1);
			printf("%s",a);
		}
		else
		{
			fprintf(fp1,"%s",a);
			fputc(' ',fp1);
		}
	}
}
