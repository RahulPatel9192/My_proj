#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main(int argc,char **argv)
{
	FILE *fp,*fp1;
	char ch,a[100],b[100];
	int c=0,l=0,b1,op;

	printf("Enter line...");
	scanf("%s",b);
	b1=strlen(b);
	printf("line=");
	scanf(" %d",&op);

	if(argc!=2)
	{
		printf("usage. ./a.out filename\n");
		return;
	}

	fp1=fopen("data1","w");
	fp=fopen(argv[1],"r");
	if(fp==0)
	{
		printf("file is not present\n");
		return;
	}
/*
	while(fgets(a,100,fp))
	{
		c++;
		if(c!=l)
		fputs(a,fp1);
		else
	{
		fputs(b,fp1);
		fputc('\n',fp1);
	}	
	}
	rewind(fp);
	rewind(fp1);
	fp1=fopen("data1","r");
	fp=fopen(argv[1],"w");


	while(fgets(a,100,fp1))
		fputs(a,fp);

//	remove("data1");
*/

//////////////////// with using malloc
	char **p;
	int i;
	while((ch=fgetc(fp))!=EOF)
	{
		c++;
		if(ch=='\n')
			l++;
	}

rewind(fp);
	p=malloc(sizeof(char *)*l);


	for(i=0;i<l;i++)
	{
		p[i]=malloc(c+1);
	}

	for(i=0;i<l;i++)
	{
		fgets(p[i],c,fp);
	}

	for(i=0;i<l;i++)
	{
		printf("%s",p[i]);
	}
	fp=fopen(argv[1],"w");

	for(i=0;i<l;i++)
	{
		if(op!=i+1)
			fputs(p[i],fp);
		else
			{
			fputs(b,fp);
			fputc('\n',fp);
			}
	}
}
