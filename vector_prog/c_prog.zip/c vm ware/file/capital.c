#include<stdio.h>
main(int argc,char **argv)
{
FILE *fp;
char ch;

if(argc!=2)
{
printf("usage ./a.out filename\n");
return;
}

fp=fopen(argv[1],"r+");
if(fp==0)
{
printf("file is not present..\n");
return;
}

printf("%u\n", ftell(fp));
if(ftell(fp)==0)
{
ch=fgetc(fp);
if(ch>='a'&& ch<='z')
ch=ch-32;
}
fseek(fp,-1,SEEK_CUR);
fputc(ch,fp);
rewind(fp);


while((ch=fgetc(fp))!=EOF)
{
if(ch==' ' || ch=='\n')
{
ch=fgetc(fp);
if(ch>='a' && ch<='z')
ch=ch-32;
}
fseek(fp,-1,SEEK_CUR);
fputc(ch,fp);
}


}



