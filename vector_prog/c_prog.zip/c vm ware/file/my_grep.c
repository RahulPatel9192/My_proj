#include<stdio.h>
#include<string.h>
main(int argc,char **argv)
{
FILE *fp;
char a[100];

if(argc!=3)
{
printf("usage:./a.out char file\n");
return;
}

fp=fopen(argv[2],"r");
if(fp==0)
{
printf("file is not present\n");
return;
}

while(fgets(a,100,fp))
{
if(strstr(a,argv[1]))
printf("%s",a);
//printf("\n");
}



}
