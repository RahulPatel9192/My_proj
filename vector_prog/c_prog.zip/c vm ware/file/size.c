//size of file
#include<stdio.h>
main(int argc,char **argv)
{
FILE *fp,*fp1;
char ch;
int c=0;
if(argc!=2)
{
printf("usage:,/a.out char char\n");
return;
}
fp=fopen(argv[1],"r");
if(fp==0)
{
printf("file not present...\n");
return;
}

while((ch=fgetc(fp))!=EOF)
c++;

printf("size of file=%d\n",c);


}
