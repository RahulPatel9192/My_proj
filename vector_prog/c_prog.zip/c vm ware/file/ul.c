#include<stdio.h>
main(int argc,char **argv)
{
	FILE *fp;
	char ch;

	if(argc!=2)
	{
		printf("usage. ./a.out filename\n");
		return;
	}

	fp=fopen(argv[1],"r+");
	if(fp==0)
	{
		printf("file is not present\n");
		return;
	}

	while((ch=fgetc(fp))!=EOF)
	{
		if(ch>='a' && ch<='z')
		{
			ch=ch-32;
			fseek(fp,-1,SEEK_CUR);
			fputc(ch,fp);
		}

		else if(ch>='A' && ch<='Z')
		{
			ch=ch+32;
			fseek(fp,-1,SEEK_CUR);
			fputc(ch,fp);
		}
	}




}
