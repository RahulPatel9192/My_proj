#include<stdio.h>
main()
{
int num,pos,c=0,i;
printf("enter the num=\n");
scanf("%d",&num);
abc:
printf("enter the pos=\n");
scanf("%d",&pos);

if (pos>=0 && pos<=31)
ABC:
{
printf("choose the option\n1)set bit\n2)clear bit\n3)compliment bit\n");
scanf("%d",&i);
 if(i==1)
{
num=num|(1<<pos);
printf("num=%d\n",num);
}
else if(i==2)
{
num =num&~(1<<pos);
printf("num=%d",num);
}
else if(i==3)
{
num=num^(1<<pos);
printf("num=%d",num);

}
else
{
printf("enter valid option\n\n");
goto ABC;
}
}
else
{
c++; 
printf("enter valid bit position\n\n");

if(c<3)
{
if(c==2)
{
printf("this is ur last turn\n\n");
goto abc;
}
else
{
//printf("%d",c);
goto abc;
}
}
else
printf("max 3 times\n\n");
}
}





