#include<stdio.h>
main()
{
int p,l,cp,sp;

printf("enter the sp=");
scanf("%d",&sp);

printf("enter the cp=");
scanf("%d",&cp);

if(cp>sp)
{
printf("loss\n");
printf("loss=%d",cp-sp);
}
else
{
printf("profit\n");
printf("profit=%d",sp-cp);
}

}
