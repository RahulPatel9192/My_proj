#include<stdio.h>
main( )
{
int code, flag ;
if ( code == 1 & flag == 0 )
printf ( "\nThe eagle has landed" ) ;

}


