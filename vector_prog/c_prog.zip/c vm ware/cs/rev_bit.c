#include<stdio.h>
main()
{
int num,i,j,m,n;
printf("enter the nu...\n");
scanf("%d",&num);
printf("befor...%d\n",num);
for(i=31;i>=0;i--)
printf("%d",num>>i&1);
printf("\n");
////////////////////////////////////////////////////
for(i=0,j=31;i<j;i++,j--)
{
//ith bit is set or clear
//jth bit is set or clear
m=num>>i&1;
n=num>>j&1;
if(m!=n)
{
num=num^1<<i;
num=num^1<<j;
}



}








///////////////////////////////////////////////////
printf("befor...%d\n",num);
for(i=31;i>=0;i--)
printf("%d",num>>i&1);
printf("\n");

}
