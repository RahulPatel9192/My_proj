#include<stdio.h>
main()
{
int num,r,i,s=0,num1;
/*printf("Enter the nu..\n");
scanf("%d",&num);
*/
for(i=1;i<=100000;i++)
{
num=i;
for(s=0 ;num;num=num/10)
{
r=num%10;
r=r*r*r;
s=s+r;
}
if(s==i)
printf("%d\t",s);
else
;

}
}
