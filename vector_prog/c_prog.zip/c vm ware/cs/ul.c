#include<stdio.h>
main()
{
char ch,k;
printf("enter the char=");
scanf("%c",&ch);
k=ch&~(1<<5);
printf("%c",k);


}
