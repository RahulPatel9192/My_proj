// ip 4 digit nu and sum 1st and last digit

#include<stdio.h>
main()
{
int i,num,j,k=0,r,one,last;
printf("enter 4 digit nu=");
scanf("%d",&num);

for(i=1;i<=4;i++,num=num/10)
{
r=num%10;
r=r+k;
if(i==1)
one=r;
else if(i==4)
last=r;
else
;


}
printf("sum=%d\n",one+last);

}
