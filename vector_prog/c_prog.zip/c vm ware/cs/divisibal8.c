#include<stdio.h>
main()
{
int num,k;
printf("enter value=");
scanf("%d",&num);

k=num&(num-1);

k==0?printf("divisibal by 8\n"):printf("not divisibal by 8\n");







}
