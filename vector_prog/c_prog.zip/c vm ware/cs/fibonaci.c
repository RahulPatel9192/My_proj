#include<stdio.h>
main()
{
int num,first=0,second=1,c,next;
printf("nu of values\n");
scanf("%d",&num);
 for (c=0;c<num;c++)

{
if (c<=1)
   next=c;
else
   next=first+second;
   first=second;
   second=next;
printf("%d\t",next);
}



printf("\n");
}

