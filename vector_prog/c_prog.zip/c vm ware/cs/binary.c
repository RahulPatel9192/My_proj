#include<stdio.h>
main()
{
int num,i=31,j,c=0;
printf("Enter the value\n");
scanf("%d",&num);
/*abc:
j=(num>>i)&1;

if (i>=0)
{
i--;
printf("%d",j);
 goto abc;
}
*/
for(i=31;i>=0;i--) //binary conversion
{
j=(num>>i)&1;
printf("%d",j);
if(j==1)
c++;
}
printf("\nc=%d\n",c);


/*
for(i=0;i<=31;i++) //reverse binary print
{
j=(num>>i)&1;
printf("%d",j);
}*/
}
