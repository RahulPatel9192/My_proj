#include<stdio.h>
main()
{
int num,i=1,j,f=1;
printf("Enter nu=\n");
scanf("%d",&num);
/*
j=num*(num-i);
i++;
abc:
j=j*(num-i);
i++;
if(i<num)
{

goto abc;

}
else
printf("%d\n\n",j);
*/
for (i=1;i<=num;i++)
f=f*i;

printf("%d\n",f);




}

