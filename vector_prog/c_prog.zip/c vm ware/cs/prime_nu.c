//given number is prime or not
#include<stdio.h>
main()
{
int num,i,r,c=0;
printf("Enter the nu....\n");
scanf("%d",&num);
//////////////////////////////1st method
/*
for(i=1;num>=i;i++)
{
r=num%i;
if (r==0)
c++;
}
if(c==2)
printf("Given nu is prime\n");
else
printf("Given nu is not prime\n");
*/
////////////////////////2nd method

for(i=2;i<num;i++)
if(num%i==0)
break;
if(i==num)
printf("prime\n");
else
printf("not prime\n");
}
