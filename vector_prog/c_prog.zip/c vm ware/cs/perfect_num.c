#include<stdio.h>
main()
{
int num,i,r,j,s=0,num1,c=0;
 printf("enter the nu=");
scanf("%d",&num1);
for(j=1;j<=num1;j++)
{
num=j;
for(i=1,c=0;i<num;i++)
{

if(num%i==0)
c=c+i;

}
if(c==num)
printf("%d ",num);
//else
//printf("not\n");


}
}
