#include<stdio.h>
main()
{
int i,num;
printf("Enter the nu..\n");
scanf("%d",&num);

if(num & (num-1)==0)
 printf("nu is power of 2\n");
else
 printf("not power of 2\n");




}
