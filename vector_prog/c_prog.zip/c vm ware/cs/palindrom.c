//pelindrom
#include<stdio.h>
main()
{
int num,i,r,s=0i,c=0;
/*printf("enter the nu...\n");
scanf("%d",&num);
*/
for(i=1;i<=200;i++)
{
num=i;
 
for(s=0 ;num;num=num/10)
{
r=num%10;
s=s*10+r;

}

if(i==s)
{
//printf("nu is palindrom\n");
printf("%d\t",i);
c++;
}
else
//printf("nu is not palindrom\n");
;

}
}
