#include<stdio.h>
main()
{
	int num,i,j;
	printf("1.addition\n2.subtraction\n3.multiplication\n4.division\n5.modulo\n");
	scanf("%d",&num);
	printf("enter two nu=");
	scanf("%d %d",&i,&j);
	switch(num)
	{
		case 1:
			printf("%d\n",i+j);
			break;
		case 2:
			printf("%d\n",i-j);
			break;
		case 3:
			printf("%d\n",i*j);
			break;
		case 4:
			printf("%d\n",i/j);
			break;
		case 5:
			printf("%d\n",i%j);
			break;
			default:
				printf("choose correct \n");


	}



}
