#include<stdio.h>
main()
{
int y;

printf("enter year=");
scanf("%d",&y);

if(y%100==0)
{
if(y%400==0)
printf("the year is leap year\n");
else
printf("not a leap year\n");
;
}
else
{
if(y%4==0)
printf("The year is leap year\n");
else
printf("not a leap year\n");


}
}
