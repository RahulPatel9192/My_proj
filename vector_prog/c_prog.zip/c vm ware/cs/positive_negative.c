#include<stdio.h>
main()
{
int i,k;

printf("enter the nu=");
scanf("%d",&i);

k=i&1;
if(k==0)
printf("even\n");
else
printf("odd\n");





}
