#include<stdio.h>
main()
{
	int num,num1;

	printf("enter the nu=");
	scanf("%d",&num);
	printf("enter the value\n");
	scanf("%d",&num1);
	while(num%num1==0)

		num=num/num1;

	if(num==1)
		printf("perfect\n");
	else
		printf("not perfect\n");




}
