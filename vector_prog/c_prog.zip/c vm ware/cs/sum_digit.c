//sum of the digit
#include<stdio.h>
main()
{
int num,r,s=0;
printf("enter the nu...\n");
scanf("%d",&num);

for( ;num;num=num/10) 
//for(;num;s=s+r,num=num/10)
{
r=num%10;
//s=s*10+r;
s=s+r;
}
printf("%d\n",s);


}
