#include<stdio.h>
main()
{
FILE *fp;
char ch;
fp=fopen("data","r");
while((ch=getc(fp))!=EOF)
printf("%c",ch);
printf("\n");

} 
