#include<stdio.h>
#include<string.h>
main()
{
int marks;
char name[50];
printf("marks...");
scanf("%d",&marks);
printf("name...");
gets(name);
puts(name);

}
