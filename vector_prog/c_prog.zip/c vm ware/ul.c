#include<stdio.h>
main()
{
char ch;
printf("enter the char=\n");
scanf("%c",&ch);
//ch=ch|(1<<5);//for set the bit we get lowercase
//ch=ch-32;
ch=ch&~(1<<5);//for clear the bit we get uppercase
printf("uppercase=%c\n",ch);




}
