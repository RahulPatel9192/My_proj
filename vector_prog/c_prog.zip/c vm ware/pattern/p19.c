/*

    1
   232 
  34543
 4567654
567898765
*/
#include<stdio.h>
main()
{
int i,j,n,p;
//char p='D';
printf("enter the value");
scanf("%d",&n);

 for(i=1;i<=n;i++) //loop for 1st part
{
for(j=1;j<=n-i;j++) //loop for space
printf(" ");

p=i;
for(j=1;j<=i;j++)  //loop for second part
printf("%d",p++);

p=p-2;
for(j=1;j<=i-1;j++)  //loop for 3rd part
printf("%d",p--);

printf("\n");
}






}
