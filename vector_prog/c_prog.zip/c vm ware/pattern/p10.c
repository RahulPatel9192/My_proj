#include<stdio.h>
main()
{
int i,j,e=0,o=0,num;

printf("enter thr nu=");
scanf("%d",&num);

for(i=1;i<=num;i++)
{
for(j=1,e=0,o=0;j<=i;o++,j++)
{
if(i%2==0)
printf("%d ",e+=2);
else
printf("%d ",o+=1);

}
printf("\n");

}





}
