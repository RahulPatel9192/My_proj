#include<stdio.h>
main()
{
int i,j,k,l;

for(i=1;i<=5;i++)
{
for(j=1;j<=i;j++)
printf("%d",j);

for(k=1;k<2*(5-i)+1;k++)
printf(" ");

for(l=1,j--;l<=i;l++,j--)
printf("%d",j);




printf("\n");
}




}
