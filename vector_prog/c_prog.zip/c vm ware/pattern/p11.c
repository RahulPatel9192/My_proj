#include<stdio.h>
main()
{
int i,j,k,num;
printf("Enter the nu=");
scanf("%d",&num);

for(i=1;i<=num;i++)
{
for(j=5;j>=i;j--)
printf(" ");
{
for(k=1;k<=2*i-1;k++)
printf("%d",k);

}
printf("\n");
}

num--;

for(i=1;i<=num;i++)
{
for(j=1;j<=i+1;j++)
printf(" ");
{
for(k=1;k<=2*(num-i)+1;k++)
printf("%d",k);

}
printf("\n");
}
}
