#include<stdio.h>
main()

{
int i,j,k,l,num;

printf("enter the valu=");
scanf("%d",&num);

for(i=1;i<=num;i++)
{
for(j=1,l=i,k=num-1;j<=i;j++,k--)
{
printf("%d ",l);
l=l+k;

}
printf("\n");
}



}
