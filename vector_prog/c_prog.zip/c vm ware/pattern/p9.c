#include<stdio.h>
main()
{
	int i,j,k,num;
	printf("enter the nu=");
	scanf("%d",&num);

	for(i=1;i<=num;i++)
	{
		for(j=1;j<=i;j++)
		{
			printf("%d",i);
			if(j!=i)

				printf("*");
		}
		printf("\n");

	}

	num--;
	for(i=num;i>=1;i--)
	{
		for(j=1;j<=i;j++)
		{
			printf("%d",i);
			if(j!=i)
				printf("*");
		}
		printf("\n");
	}
}
