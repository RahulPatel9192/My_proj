#include<stdio.h>
main()
{
int i,j,k,num;

printf("Enter the nu...\n");
scanf("%d",&num);
 for(i=1;i<=num;i++)
{
for(j=1;j<=num-i;j++)
printf(" ");
for(k=1;k<=i;k++)
printf("* ");
printf("\n");

}
num--;

 for(i=1;i<=num;i++)
{
for(j=1;j<=i;j++)
printf(" ");
for(k=4;k>=i;k--)
printf("* ");
printf("\n");



}

}
