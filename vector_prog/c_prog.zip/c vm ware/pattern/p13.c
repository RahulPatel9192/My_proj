#include<stdio.h>
main()
{
int i,j,k,num,l,p=0;

for(i=1;i<=5;i++)
{
for(j=1;j<=i;j++)
{
printf("%d",j);
p=j;
}
{
for(k=1;k<=2*(5-i);k++)
printf(" ");
{
for(l=1;l<=i;l++,p--)

printf("%d",p);

}
printf("\n");
}

}
}
