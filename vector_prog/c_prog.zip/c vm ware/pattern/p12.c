#include<stdio.h>
main()
{
int num,i,j,k,n;

printf("enter the nu=");
scanf("%d",&num);

for(i=1;i<=num;i++)
{
for(j=1,n=1;j<=i;j++,n++)
printf("%d ",i*j);


printf("\n");
}
}
