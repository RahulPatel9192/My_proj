#include<stdio.h>
main()
{
int i,k,num=5,j=5;
//printf("enter the line of nu..\n");
//scanf("%d",&num);

for(i=1;i<=num;i++)
{


for(k=num;k>=i;k--)
{
printf("%d ",j);

}
j--;
printf("\n");
}
}
