/*
   D
  DCD 
 DCBCD
DCBABCD
*/

#include<stdio.h>
main()
{
int i,j,k,n;
char ch='D';

printf("enter the value=");
scanf("%d",&n);

for(i=1;i<=n;i++)
{
for(j=4;j>=i;j--)
printf(" ");

for(j=1;j<=i;j++,ch--)
printf("%c",ch);

ch=ch+2;

for(j=1;j<=i-1;j++,ch++)
printf("%c",ch);
ch--;
printf("\n");




}





}
