//merge...
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	char n[20];
	float m;
	struct st *next;
}ST;
void add_ending (ST **);
void print (ST *);
void merge(ST *,ST *);
main()
{
	ST *headptr1=0;
	ST *headptr2=0;
	char ch;

	printf("1st ll\n");
	do
	{
		add_ending(&headptr1);
		printf("Do u want add another data.(Y/y)..\n");
		scanf(" %c",&ch);
	}while ((ch=='y')||(ch=='Y'));

	print(headptr1);
	printf(".............................................\n");

	printf("2nd ll\n");
	do
	{
		add_ending(&headptr2);
		printf("Do u want add another data.(Y/y)..\n");
		scanf(" %c",&ch);
	}while ((ch=='y')||(ch=='Y'));

	print(headptr2);
	printf("..........................................\n");

	merge(headptr1,headptr2);
	print(headptr1);
}

void add_ending (ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));		//allocate memory

	printf("enter data.\n");			//scaning data
	scanf("%d %s %f",&temp->r,temp->n,&temp->m);

	if(*ptr==0)				//established a link
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1->next)
			temp1=temp1->next;

		temp->next=temp1->next;
		temp1->next=temp;

	}



}


void print (ST *p) 
{
	while(p)
	{
		printf("%d %s %f\n",p->r,p->n,p->m);
		p=p->next;

	}

}
void merge(ST *h1,ST *h2)
	{
		ST *temp,*temp1,*temp2,*temp3,*temp4;
		temp=h1;
		temp1=h2;
		while(temp && temp1)
		{
temp2=temp->next;
temp3=temp1->next;
temp1->next=temp->next;
temp->next=temp1;
temp4=temp->next;
temp=temp2;
temp1=temp3;
if(temp==0)
{
temp2=temp4;
temp2->next=temp1;
}


}






	




