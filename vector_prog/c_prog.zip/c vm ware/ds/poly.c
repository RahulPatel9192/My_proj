#include<stdio.h>
#include<stdlib.h>

typedef struct poly
{
	int n;
	int e;
	struct poly *next;
}POLY;

void creat_poly(POLY **);
void print_poly(POLY *);
void add_poly(POLY *,POLY *,POLY **);

main()
{
	POLY *h1=0,*h2=0,*h3=0;
	char ch;
	printf("enter 1st poly...\n");
	do
	{
		creat_poly(&h1);
		printf("continue?\n");
		scanf(" %c",&ch);
	}while(ch=='y');
	print_poly(h1);
	printf("\n");
	printf("......................................\n");

	printf("enter 2nd poly...\n");
	do
	{
		creat_poly(&h2);
		printf("continue?\n");
		scanf(" %c",&ch);
	}while(ch=='y');
	print_poly(h2);
	
	printf("\n....................................\n");

	add_poly(h1,h2,&h3);
	print_poly(h3);
	printf("\n");
}



void creat_poly(POLY **ptr)
{
	int n,e;
	POLY *temp,*temp1;

	temp=malloc(sizeof(POLY));

	printf("Enter number...");
	scanf("%d",&temp->n);

	printf("Enter exponent...");
	scanf("%d",&temp->e);


	if(*ptr==0)
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;

		while(temp1->next)
			temp1=temp1->next;

		temp->next=temp1->next;
		temp1->next=temp;
	}
}

void print_poly(POLY *p)
{
	while(p)
	{
		if(p->next !=0)
		printf("%dx^%d+",p->n,p->e);
		else
		printf("%dx^%d",p->n,p->e);
		p=p->next;
	}
}

void add_poly(POLY *h1,POLY *h2,POLY **h3)
{

		POLY *temp,*temp1;
	while(h1 && h2)
	{

		temp=malloc(sizeof(POLY));

		if(h1->e == h2->e)
		{
			temp->n=h1->n+h2->n;
			temp->e=h1->e;
			h1=h1->next;
			h2=h2->next;
		}


		else if(h1->e > h2->e)
		{
		temp->n=h1->n;
		temp->e=h1->e;
		h1=h1->next;
		
		}

	
		else if(h2->e > h1->e)
		{
		temp->n=h2->n;
		temp->e=h2->e;
		h2=h2->next;
		
		}




		if(*h3==0)
		{
			temp->next=*h3;
			*h3=temp;
		}

		else
		{
			temp1=*h3;

			while(temp1->next)
				temp1=temp1->next;

			temp->next=temp1->next;
			temp1->next=temp;
		}


	}

if(h1)
{
temp->next=h1;
}
else
temp->next=h2;
}
