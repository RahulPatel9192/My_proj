//rev 'm' nu of nodes in linked list...
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	struct st *next;
}ST;
void add_ending (ST **);
void print (ST *);
int count (ST *);
void rev(ST *);
main()
{
	ST *hp=0;
	char ch;
	do
	{
		add_ending(&hp);
		printf("Do u want add another data.(Y/y)..\n");
		scanf(" %c",&ch);
	}while ((ch=='y')||(ch=='Y'));
	printf(".............................\n");
	print(hp);
	printf(".............................\n");
	rev(hp);
	print(hp);
}


void add_ending (ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));		//allocate memory

	printf("number..\n");			//scaning data
	scanf("%d",&temp->r);

	if(*ptr==0)				//established a link
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1->next)
			temp1=temp1->next;

		temp->next=temp1->next;
		temp1->next=temp;

	}



}


void print (ST *p) 
{
	while(p)
	{
		printf("%d\n",p->r);
		p=p->next;

	}


}

int count (ST *p)
{
	int c=0;
	while(p)
	{
		c++;
		p=p->next;
	}
	return c;
}

void rev (ST *ptr)
{
ST *temp,*temp1,*temp2;
ST v;
int i,j,k,m;
printf("nu of nodes u want rev\n");
scanf("%d",&m);
printf("\n");
temp=ptr;
for(k=0,j=m;k<j;k++,j--)
{
temp2=ptr;
for(i=0;i<m-1-k;i++)
temp2=temp2->next;

v.r=temp2->r;
temp2->r=temp->r;
temp->r=v.r;

temp=temp->next;


}



}


