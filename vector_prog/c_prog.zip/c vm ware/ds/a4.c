//swap kth node
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	struct st *next;
}ST;

void add_middle(ST **);
void print(ST *);
void swap(ST **);
int count(ST *);

main()
{
	int n;
	char ch;
	ST *hp=0;

	do
	{
		add_middle(&hp);
		printf("continue...?\n");
		scanf(" %c",&ch);
	}while(ch=='y');
	printf(".............................\n");
	print(hp);
	printf("...................\n");

	swap(&hp);
	print(hp);
}


void add_middle(ST **ptr)
{
	ST *temp,*temp1;

	temp=malloc(sizeof(ST));

	printf("enter nu..\n");
	scanf("%d",&temp->r);

	if(*ptr==0 || temp->r < (*ptr)->r)
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;

		while(temp1)
		{
			if(temp1->next==0)
			{
				temp->next=temp1->next;
				temp1->next=temp;
				break;
			}
			if(temp1->next->r > temp->r)
			{
				temp->next=temp1->next;
				temp1->next=temp;
				break;
			}

			temp1=temp1->next;
		}
	}

}
void print(ST *p)
{
	while(p)
	{
		printf("%d\n",p->r);
		p=p->next;
	}
}

int count(ST *ptr)
{
	int c=0;
	while(ptr)
	{
		c++;
		ptr=ptr->next;
	}

	return c;

}





void swap (ST **p)
{
int n;
printf("Enter nu..\n");
scanf("%d",&n);
printf("\n");
	int n1,c,i;
	ST *temp,**p1,*t,*temp1;
	c=count(*p);

	temp1=0;
	p1=malloc(sizeof(ST *)*c);
	temp=*p;
	for(i=0;i<c;i++)
	{
		p1[i]=temp;
		temp=temp->next;
	}

	n1=(c-n);

	t=p1[n-1];
	p1[n-1]=p1[n1];
	p1[n1]=t;


	for(i=c-1;i>=0;i--)
	{
		p1[i]->next=temp1;
		temp1=p1[i];


	}
*p=temp1;
}













