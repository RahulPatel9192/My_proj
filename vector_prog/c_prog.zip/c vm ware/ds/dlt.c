//delete linked list
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	char n[20];
	float m;
	struct st *next;
}ST;

void add_end (ST **);
void print (ST *);
void dlt (ST **);
main()
{
	char ch;
	ST *hp=0;
	ST *p;
	do
	{
		add_end(&hp);
		printf("do u want cont.(y/n).\n");
		scanf(" %c",&ch);
	}while(ch=='y' || ch=='Y');
	printf("..................................\n");
	print(hp);
	printf("...................................\n");
	dlt(&hp);
	print(hp);
}



void add_end(ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));

	printf("rollno name marks\n");
	scanf("%d %s %f",&temp->r,temp->n,&temp->m);

	if(*ptr==0)
	{
		temp->next=*ptr;
		*ptr=temp;
	}

	else
	{
		temp1=*ptr;
		while(temp1->next)
		{
			temp1=temp1->next;
		}

		temp->next=temp1->next;
		temp1->next=temp;

	}
}


void print(ST *p)
{
	while (p)
	{
		printf("%d %s %f\n",p->r,p->n,p->m);
		p=p->next;

	}


}


void dlt(ST **ptr)
{
	int num;
	ST *temp,*temp1;
	printf("Enter nu...\n");
	scanf("%d",&num);

	temp=*ptr;

	while(temp)
	{
		if(temp->r==num)
		{
			if(temp==*ptr)
			{
				*ptr=temp->next;
				free(temp);
				return;
			}
			else
			{
				temp1->next=temp->next;
				free(temp);
				return;
			}
		}
		temp1=temp;
		temp=temp->next;

	}


}











