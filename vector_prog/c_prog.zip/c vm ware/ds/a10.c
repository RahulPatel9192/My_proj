//rev data

#include<stdio.h>
#include<stdlib.h>
typedef struct st
{
	int r;
	struct st *next;
}ST;
void add_end(ST **);
void print(ST *);
int count(ST *);
void rev(ST *);
main()
{
	char ch;
	ST *hp=0;
	do
	{
		add_end(&hp);
		printf("continue\n");
		scanf(" %c",&ch);
	}while(ch=='y');
	printf("....................................\n");
	print(hp);
	printf("\n");
	printf("......................................\n");
	rev(hp);
	printf("After op\n");
	print(hp);
	printf("\n");
}

void add_end(ST **ptr)
{
	ST *temp,*temp1;
	int n;
	temp=malloc(sizeof(ST));

	printf("enter value\n");
	scanf("%d",&temp->r);

	if(*ptr==0)
	{
		temp->next=*ptr;
		*ptr=temp;
	}

	else
	{
		temp1=*ptr;

		while(temp1->next)
			temp1=temp1->next;

		temp->next=temp1->next;
		temp1->next=temp;
	}
//printf("%d",temp->r);
}

int count(ST *p)
{
	int c=0;
	while(p)
	{
		c++;
		p=p->next;
	}
	return c;

}


void print(ST *p)
{
	while(p)
	{
		printf("%d",p->r);
		p=p->next;
	}

}

void rev(ST *p)
{
	ST *temp,*temp1,*temp3;
	ST v;
	int c,n,i,j,k;
	temp=p;
	c=count(p);
printf("c=%d",c);
	for(k=0,j=c-1;k<j;k++,j--)
	{
		temp1=p;
		for(i=0;i<c-1-k;i++)
			temp1=temp1->next;

		v.r=temp->r;
		temp->r=temp1->r;
		temp1->r=v.r;

		temp=temp->next;
	}



}



