//dlt node at reverse side
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	struct st *next;
}ST;

void add_end(ST **);
void print(ST *);
void dlt(ST **);
int count (ST *);
main()
{
	char ch;
	ST *hp=0;
	do
	{
		add_end(&hp);
		printf("continue?\n");
		scanf(" %c",&ch);
	}while(ch=='y');

	printf(".................................\n");
	print(hp);
	printf(".....................................\n");
	dlt(&hp);
	print(hp);
}


void add_end(ST **ptr)
{
	ST *temp,*temp1;

	temp=malloc(sizeof(ST));

	printf("Enter nu..\n");
	scanf("%d",&temp->r);


	if(*ptr==0)
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;

		while(temp1->next)
			temp1=temp1->next;

		temp->next=temp1->next;
		temp1->next=temp;

	}

}

void print(ST *p)
{
	while(p)
	{
		printf("%d\n",p->r);
		p=p->next;
	}
}

int count(ST *p)
{
	int c=0;
	while(p)
	{
		c++;
		p=p->next;
	}
	return c;
}

void dlt (ST **ptr)
{
	int i,c,n,n1;
	ST *temp,*temp1,**p;
	ST *temp2=0;
	printf("Enter position at end side\n");
	scanf("%d",&n);
	printf("\n");

	c=count(*ptr);

	p=malloc(sizeof(ST *)*c);
	temp=*ptr;
	for(i=0;i<c;i++)
	{
		p[i]=temp;
		temp=temp->next;
	}

	n1=c-n;

	for(i=n1;i<c-1;i++)
	{
		p[i]=p[i+1];
	}

	for(i=c-2;i>=0;i--)
	{
		p[i]->next=temp2;
		temp2=p[i];
	}

	*ptr=temp2;

}



