#include<stdio.h>
#include<stdlib.h>

typedef struct dll
{
	struct dll *prev;
	int num;
	struct dll *next;
}DLL;

void add_begain(void);
void add_end(void);
void print(void);
DLL *hp;
main()
{
	char ch;
	do
	{
		add_end();
		printf("continue?..\n");
		scanf(" %c",&ch);
	}while(ch=='y');

	printf(".............................\n");
	print();

}

void add_begain(void)
{
	DLL *temp;
	temp=malloc(sizeof(DLL));

	printf("Enter nu..\n");
	scanf("%d",&temp->num);

	temp->next=0;
	temp->prev=0;

	if(hp==0)
	{
		hp=temp;
	}
	else
	{
		hp->prev=temp;
		temp->next=hp;
		hp=temp;
	}

}



void print(void)
{
	DLL *ptr;
	ptr=hp;
	while(ptr)
	{
		printf("%d\n",ptr->num);
		ptr=ptr->next;

	}

}

void add_end(void)
{
DLL *temp;
temp=malloc(sizeof(DLL));

printf("Enter nu..\n");
scanf("%d",&temp->num);


temp->next=0;
temp->prev=0;

if(hp==0)
{
hp=temp;
}
else
{
DLL *temp1;
temp1=hp;

while(temp1->next)
temp1=temp1->next;

temp->prev=temp1;
temp1->next=temp;
}


}
