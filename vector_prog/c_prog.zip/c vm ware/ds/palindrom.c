//linked list is palindrom or not...
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	struct st *next;
}ST;
void add_ending (ST **);
void print (ST *);
int count (ST *);
void pal(ST *);
main()
{
	ST *hp=0;
	char ch;
	do
	{
		add_ending(&hp);
		printf("Do u want add another data.(Y/y)..\n");
		scanf(" %c",&ch);
	}while ((ch=='y')||(ch=='Y'));
	printf(".............................\n");
	print(hp);
	printf(".............................\n");
	pal(hp);
	print(hp);
}


void add_ending (ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));		//allocate memory

	printf("number..\n");			//scaning data
	scanf("%d",&temp->r);

	if(*ptr==0)				//established a link
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1->next)
			temp1=temp1->next;

		temp->next=temp1->next;
		temp1->next=temp;

	}



}


void print (ST *p) 
{
	while(p)
	{
		printf("%d\n",p->r);
		p=p->next;

	}


}

int count (ST *p)
{
	int c=0;
	while(p)
	{
		c++;
		p=p->next;
	}
	return c;
}

void pal (ST *ptr)
{
ST *temp,*temp2;
ST v;
int i,j,k,m,c;
c=count(ptr);
printf("\n");
temp=ptr;
for(k=0,j=c-1;k<j;k++,j--)
{
temp2=ptr;
for(i=0;i<c-1-k;i++)
temp2=temp2->next;

if(temp->r!=temp2->r)
{
printf("not palindrom\n");
return;
}
temp=temp->next;


}
printf("palindrom\n");

}


