//dlt duplicate in unsorted linked list...
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	struct st *next;
}ST;
void add_ending (ST **);
void print (ST *);
int count (ST *);
void dlt(ST **);
main()
{
	ST *hp=0;
	char ch;
	do
	{
		add_ending(&hp);
		printf("Do u want add another data.(Y/y)..\n");
		scanf(" %c",&ch);
	}while ((ch=='y')||(ch=='Y'));
	printf(".............................\n");
	print(hp);
	printf(".............................\n");
	dlt(&hp);
	print(hp);
}


void add_ending (ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));		//allocate memory

	printf("number..\n");			//scaning data
	scanf("%d",&temp->r);

	if(*ptr==0)				//established a link
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1->next)
			temp1=temp1->next;

		temp->next=temp1->next;
		temp1->next=temp;

	}



}


void print (ST *p) 
{
	while(p)
	{
		printf("%d\n",p->r);
		p=p->next;

	}


}

int count (ST *p)
{
	int c=0;
	while(p)
	{
		c++;
		p=p->next;
	}
	return c;
}

void dlt (ST **ptr)
{
	ST **p,*temp;
	ST *temp1=0;
	int c,i,j,k;
	c=count(*ptr);
	p=malloc(sizeof(ST *)*c);
	temp=*ptr;
	for(i=0;i<c;i++)
	{
		p[i]=temp;
		temp=temp->next;
	}

	for(i=0;i<c;i++)
	{
		for(j=i+1;j<c;j++)
		{
			if(p[i]->r==p[j]->r)
			{
				for(k=j;k<c-1;k++)
					p[k]=p[k+1];
				c=c-1;
				j--;
			}
		}

	}
	
	for(i=c-1;i>=0;i--)
	{
		p[i]->next=temp1;
		temp1=p[i];


	}
	*ptr=temp1;


}


