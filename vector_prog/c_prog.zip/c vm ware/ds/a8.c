//dlt duplicate in sorted linked list...
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	struct st *next;
}ST;
void add_middle (ST **);
void print (ST *);
int count (ST *);
void dlt(ST *);
main()
{
	ST *hp=0;
	char ch;
	do
	{
		add_middle(&hp);
		printf("Do u want add another data.(Y/y)..\n");
		scanf(" %c",&ch);
	}while ((ch=='y')||(ch=='Y'));
	printf(".............................\n");
	print(hp);
	printf(".............................\n");
	dlt(hp);
	print(hp);
}

void add_middle (ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));		//allocate memory

	printf("no...\n");			//scaning data
	scanf("%d",&temp->r);

	if(*ptr==0 || temp->r < (*ptr)->r)				//established a link
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1)
		{
			if(temp1 -> next==0)
			{
				temp->next=temp1->next;
				temp1->next=temp;
				break;
			}
			if(temp1->next->r > temp->r)
			{
				temp->next=temp1->next;
				temp1->next=temp;
				break;
			}
			temp1=temp1->next;
		}


	}
}

void print (ST *p) 
{
	while(p)
	{
		printf("%d\n",p->r);
		p=p->next;

	}


}

int count (ST *p)
{
	int c=0;
	while(p)
	{
		c++;
		p=p->next;
	}
	return c;
}

void dlt (ST *ptr)
{

	ST *temp,*temp1,*temp2,*temp3;
	temp=ptr;

	while(temp)
	{
		if(temp->next !=0)
		if((temp->r) == (temp->next->r))
		{
			temp1=temp->next->next;
			temp2=temp->next;
			free(temp2);
			temp->next=temp1;
			continue;
		}
		temp=temp->next;

	}



}
