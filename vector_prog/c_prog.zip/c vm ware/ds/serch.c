#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	char n[20];
	float m;
	struct st *next;
}ST;

void add_end (ST **);
void print (ST *);
ST * serch (ST *,int);
main()
{
	char ch;
	int n;
	ST *hp=0;
	ST *p;
	do
	{
		add_end(&hp);
		printf("do u want cont.(y/n).\n");
		scanf(" %c",&ch);
	}while(ch=='y' || ch=='Y');
	printf("..................................\n");
	print(hp);
	printf("...................................\n");
	printf("Enter nu...");
	scanf("%d",&n);

	p=serch(hp,n);

	if(p==0)
	{
		printf("data not found\n");
	}
	else
	{
		printf("data found\n");
	}
}



void add_end(ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));

	printf("rollno name marks\n");
	scanf("%d %s %f",&temp->r,temp->n,&temp->m);

	if(*ptr==0)
	{
		temp->next=*ptr;
		*ptr=temp;
	}

	else
	{
		temp1=*ptr;
		while(temp1->next)
		{
			temp1=temp1->next;
		}

		temp->next=temp1->next;
		temp1->next=temp;

	}
}


void print(ST *p)
{
while (p)
{
printf("%d %s %f\n",p->r,p->n,p->m);
p=p->next;

}


}


ST * serch (ST *p,int n)
{

	while(p)
	{

		if(p->r == n)
			return p;

		p=p->next;
		return 0;
	}

}






