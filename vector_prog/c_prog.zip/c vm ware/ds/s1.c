//adding data at begains...
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	char n[20];
	float m;
	struct st *next;
}ST;
void add_begain (ST **);
void print (ST *);
int count (ST *);
main()
{
	ST *headptr=0;
	char ch;
	int n;
	do
	{
		add_begain(&headptr);
		printf("Do u want add another data.(Y/y)..\n");
		scanf(" %c",&ch);
	}while ((ch=='y')||(ch=='Y'));

	print(headptr);
	n=count(headptr);
	printf("%d nodes\n",n);
}

void add_begain (ST **ptr)
{
	ST *temp;
	temp=malloc(sizeof(ST));		//allocate memory

	printf("Roll no..\n");			//scaning data
	scanf("%d",&temp->r);
	printf("name..\n");
	scanf("%s",temp->n);
	printf("marks..\n");
	scanf("%f",&temp->m);

	temp->next=*ptr;			//established a link
	*ptr=temp;
}


void print (ST *p) 
{

	while(p)
	{
		printf("%d %s %f\n",p->r,p->n,p->m);
		p=p->next;		

	}

}
int count (ST *p)
{
int c=0;
while(p)
{
c++;
p=p->next;
}
return c;
}



