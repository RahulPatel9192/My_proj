//swap congicutive two nodes
/*i/p= a-b-c-d-e-f-g-h-i
 o/p=  b-a-d-c-f-e-h-g-i*/

#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	struct st *next;
}ST;

void add_end(ST **);
void print(ST *);
void swap(ST **);
int count (ST *);
main()
{
	char ch;
	ST *hp=0;
	do
	{
		add_end(&hp);
		printf("continue?\n");
		scanf(" %c",&ch);
	}while(ch=='y');

	printf(".................................\n");
	print(hp);
	printf(".....................................\n");
	swap(&hp);
	print(hp);
}


void add_end(ST **ptr)
{
	ST *temp,*temp1;

	temp=malloc(sizeof(ST));

	printf("Enter nu..\n");
	scanf("%d",&temp->r);


	if(*ptr==0)
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;

		while(temp1->next)
			temp1=temp1->next;

		temp->next=temp1->next;
		temp1->next=temp;

	}

}

void print(ST *p)
{
	while(p)
	{
		printf("%d\n",p->r);
		p=p->next;
	}
}

int count(ST *p)
{
	int c=0;
		while(p)
		{
			c++;
			p=p->next;
		}
	return c;
}

void swap(ST **ptr)
{
	int c,i;
	ST *temp,*temp1;
	ST **p;
	temp=*ptr;
	c=count(*ptr);
	ST *temp2=0;
	p=malloc(sizeof(ST *)*c);

	for(i=0;i<c;i++)
	{
		p[i]=temp;
		temp=temp->next;
	}

	for(i=0;i<c-1;i++)
	{
		temp1=p[i];
		p[i]=p[i+1];
		p[i+1]=temp1;
		i++;
	}

	for(i=c-1;i>=0;i--)
	{
		p[i]->next=temp2;
		temp2=p[i];
	}
	*ptr=temp2;
}


