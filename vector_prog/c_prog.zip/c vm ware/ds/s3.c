//adding data at middle...
#include<stdio.h>
#include<stdlib.h>

typedef struct st
{
	int r;
	char n[20];
	float m;
	struct st *next;
}ST;
void add_middle (ST **);
void print (ST *);
main()
{
	ST *headptr=0;
	char ch;
	do
	{
		add_middle(&headptr);
		printf("Do u want add another data.(Y/y)..\n");
		scanf(" %c",&ch);
	}while ((ch=='y')||(ch=='Y'));

	print(headptr);
}

void add_middle (ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));		//allocate memory

	printf("Roll no..\n");			//scaning data
	scanf("%d",&temp->r);
	printf("name..\n");
	scanf("%s",temp->n);
	printf("marks..\n");
	scanf("%f",&temp->m);

	if(*ptr==0 || temp->r < (*ptr)->r)				//established a link
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1)
		{
			if(temp1 -> next==0)
			{
				temp->next=temp1->next;
				temp1->next=temp;
				break;
			}
			if(temp1->next->r > temp->r)
			{
				temp->next=temp1->next;
				temp1->next=temp;
				break;
			}
			temp1=temp1->next;
		}


	}
}

void print (ST *p) 
{
	while(p)
	{
		printf("%d %s %f\n",p->r,p->n,p->m);
		p=p->next;

	}


}


