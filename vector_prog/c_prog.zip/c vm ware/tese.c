#include<stdio.h>
main()
{
unsigned char ch=180;
printf("%d\n",ch);





}
