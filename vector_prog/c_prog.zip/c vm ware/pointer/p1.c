#include<stdio.h>
main()
{
int *ip,i=10,j=20;

ip=&i;
printf("ip=%d *ip=%u\n",ip,*ip);



}
