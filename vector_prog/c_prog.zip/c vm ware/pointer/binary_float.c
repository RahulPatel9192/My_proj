//iwap to find binary format of float using int pointer

#include<stdio.h>
main()
{
int *ip,i,k;
float f=3.5;

ip=&f;

for(i=31;i>=0;i--)
{
k=*ip>>i&1;
printf("%d",k);
}

}
