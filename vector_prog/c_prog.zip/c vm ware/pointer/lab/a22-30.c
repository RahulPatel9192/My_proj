//22)
/*
#include <stdio.h>
        void main()
        {
            char *s = "hello";
            char *n = "cjn";
            char *p = s + n;
            printf("%c\t%c", *p, s[1]);
        }

 // 23)
 #include <stdio.h>
        void m(int *p)
        {
            int i = 0;
            for(i = 0;i < 5; i++)
            printf("%d\t", p[i]);
        }
        void main()
        {
            int a[5] = {6, 5, 3};
            m(&a);
        }


  // 24)
#include <stdio.h>
        void foo(int*);
        int main()
        {
            int i = 10,j=20,*p = &i;
            foo(p++);
	    foo(p);
        }
        void foo(int *p)
        {
            printf("%d\n", *p);
        }

  // 25)
#include <stdio.h>
        int main()
        {
            int i = 97, *p = &i;
            foo(&i);
            printf("%d ", *p);
        }
        void foo(int *p)
        {
            int j = 2;
            p = &j;
            printf("%d ", *p);
        }


//26)
  #include<stdio.h>
       int main()
       {
	const int ary[4] = {1,2,3,4};
	int *p = ary+3;
	*p = 5;
	ary[3] = 6;
	printf("%d",ary[3]);
     }

//27) 
 #include<stdio.h>
       int main()
     {
	char *p = "Hai friends",  *p1 = p;
	while(*p!='\0');
	++*p++;
	printf("%s  %s\n",p,p1);
     }


//28)
  #include<stdio.h>
       int main()
       {
	char *x = "VECTOR";
	printf("%s\n",x+3);
	printf("%d\n"+1,123456);
       }



//29)
  #include<stdio.h>
       int main()
       {
	char a[ ] = "abcdefgh";
	int *ptr = a;
	printf("%x  %x\n",ptr[0],ptr[1]);
       }
*/ 
 // 30)
   #include<stdio.h>
          #include<string.h>
        int main()
        {
            char str[] = "hello, world\n";
            char strc[] = "good morning\n";
char *s=str;
            strcpy(strc, s);
            printf("%s\n", strc);
            return 0;
        }

