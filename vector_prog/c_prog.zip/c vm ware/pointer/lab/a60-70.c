/*//60)
#include <stdio.h>
        int *f();
        int main()
        {
             int *p = f();
             printf("%d\n", *p);
        } 
        int *f()
        { 
             int *j = (int*)malloc(sizeof(int));
            *j = 10;
             return j;
        }

// 62)
  #include <stdio.h>
        void main()
        {
            char *a[10] = {"hi", "hello", "how"};
            int i = 0;
            for (i = 0;i < 10; i++)
            printf("%s  ", *(a[i]));
        }

 // 63)
 #include <stdio.h>
        void main()
        {
            char *a[10] = {"hi", "hello", "how"};
            int i = 0, j = 0;
            a[0] = "hey";
            for (i = 0;i < 10; i++)
            printf("%s  ", a[i]);
        }


// 64)
 #include <stdio.h>
        void main()
        {
            char *a[10] = {"hi", "hello", "how"};
            printf("%d\n", sizeof(a));
        }

//  65)
 #include <stdio.h>
        void main()
        {
            char *a[10] = {"hi", "hello", "how"};
            printf("%d\n", sizeof(a[1]));
        }


// 66)
 #include <stdio.h>
        int main()
        {
            char a[2][6] = {"hello", "hi"};
            printf("%s  ", *a + 1);
            return 0;
        }

//67)
  #include <stdio.h>
        int main()
        {
            char *a[2] = {"hello", "hi"};
            printf("%s\n", *(a + 1));
            return 0;
        }
*/
// 68)
 #include <stdio.h>
        int main(int argc, char *argv[])
        {
            while (argc--)
            printf("%s\n", argv[argc]);
            return 0;
        }
/*
 69) #include <stdio.h>
        int main(int argc, char *argv[])
        {
            while (*argv++ != NULL)
            printf("%s\n", *argv);
            return 0;
        }

 70) #include <stdio.h>
        int main(int argc, char *argv[])
        {
            while (*argv  !=  NULL)
            printf("%s\n", *(argv++));

           return 0;
        }
*/
