//40)
/*
#include<stdio.h> 
      main() 
      { 
	char a[20]; 
	char *p,*q; 
	p=&a[0]; 
	q=&a[10]; 
	printf("%d %d\n",q-p,&q-&p); 
      }

//41)
 #include<stdio.h> 
       main() 
       { 
               int a=0x12345678; 
	    void *ptr; 
	    ptr=&a; 
	    printf("0x%x\n",*(int *)&*&*(char*)ptr); 
       }

//42)
 #include<stdio.h> 
      main() 
      { 
	int a[5]={1,2,3,4,5}; 
	int *ptr=(int *)(&a+1); 
	printf("%d %d\n",*(a+1),*(ptr-1)); 
	printf("%d %d\n",*(a+1),*(ptr)); 
      }

// 43)
 #include <stdio.h>
         void main()
         {
            char *s= "hello";
            char *p = s;
            printf("%c\t%c", 1[p], s[1]);
         }


//44)
 #include<stdio.h>
       main()
       {
	char a[]="abcde";
	char *p=a;
	p++;
	p++;
	p[2]='z';
	printf("%s\n",p);
       }

//45)
      #include<stdio.h>
            main()
	 {
		char a[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                       int i, *p = a;
                       for(i=0;i<5;i++)
                       printf("%c\t",*p++);
	 }
         
//46)
     #include<stdio.h>
              main()
	  {
		char *ptr1 = "abcdef";
		ptr1 = ptr1+(strlen(ptr1)-1);
		printf("%c", --*ptr1--);
		printf("%c",--*--ptr1);
		printf("%c",--*(ptr1--));
		printf("%c",--*(--ptr1));
		printf("%c",*ptr1);
}
	
            
// 47)
	#include<stdio.h>
	int main()
	{
		char *str1 = "Hello";
		char *str2 = "Hai";
		char *str3;
		str3 = strcat(str1,str2);
		printf("%s  %s\n",str3,str1);
		return 0;
	}

 // 48)
	#include<stdio.h>
	int main()
	{
		char a[]="Hello";
		char *p="Hai";
		a="Hai";
		p="Hello";
		printf("%s  %s\n",a,p);
		return 0;
	}


 // 49) 
    #include<stdio.h>
	int main()
	{
		int i,n;
		char *x="Alice";
		n=strlen(x);
		*x=x[n];
		for(i=0;i<=n;i++)
		{
			printf("%s",x);
			x++;
		}
		printf("%s\n",x);
		return 0;
	}

50)    #include<stdio.h>
	char *str=”char *str=%c%s%c;main(){printf(str,34,str,34);}”;	
	int main()
	{
		printf(str,34,str,34);
		return 0;
	}
*/
