/*//70)
#include<stdio.h>
	int main(int sizeofargv, char *argv[])
	{
		while(sizeofargv)
		printf(“%s  ”,argv[--sizeofargv]);
		return 0;
	} //if i/p is   sample  friday tuesday sunday

//72)
	#include<stdio.h>
	int main()
	{
		char *str[]={"Progs","Do","Not","Die","They","Croak!"};
		printf("%d  %d",sizeof(str),strlen(str[0]));
		return 0;
	}

//73)
	#include<stdio.h>
	int main()
	{
		static char *s[]={"black","white","pink","violet"};
		char **ptr[]={s+3,s+2,s+1,s},***p;
		p = ptr;
		printf("%s\n",**p+1);
		return 0;
	}

	
//74) 
	#include<stdio.h>
	main()
	{
		char *m[]={"jan","feb","mar"};
		char d[][10] = {"sun","mon","tue"};
		printf("%s\t",m[1]);
		printf("%s\t",d[1]);
	}

//75)
	#include<stdio.h>
	void fun(char **);
	int main()
	{
		char *argv[]={"ab","cd","ef","gh"};
		fun(argv);
		return 0;
	}
	void fun(char **p)
	{
		char *t;
		t=(p+=sizeof(int))[-1];
		printf("%s\n",t);
	}


//76) 
  #include <stdio.h>
        void first()
        {
            printf("first");
        }
        void second()
        {
            first();
        }
        void third()
        {
            second();
        }
        void main()
        {
            void (*ptr)();
            ptr = third;
            ptr();
        }

//  77)
 #include <stdio.h>
        int add(int a, int b)
        {
            return a + b;
        }
        int main()
        {
            int (*fn_ptr)(int, int);
            fn_ptr = add;
            printf("The sum of two numbers is: %d\n", (int)fn_ptr(2, 3));
        }

//  78)
 #include <stdio.h>
        int mul(int a, int b, int c)
        {
            return a * b * c;
        }
        void main()
        {
            int (*function_pointer)(int, int, int);
            function_pointer  =  mul;
            printf("The product of three numbers is:%d",
            function_pointer(2, 3, 4));
        }

// 79)
      #include<stdio.h>
	int fun(int (*)());
	int main()
	{
		fun(main);
		printf("Hi\n");
		return 0;
	}
	int fun(int (*p)())
	{
		printf("Hello\n");
		return 0;
	}
*/	
//80)
    #include<stdio.h>
          int main()
          {
		char *p = "Hello World";
		printf(p);
	}

