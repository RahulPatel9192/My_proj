/*
//15)

#include<stdio.h>
       int main() 
       { 
	int a[]={10,20,30,40,50}; 
	char *p; 
	p=(char *)a; 
	printf("%d\n",*((int *)p+4)); 
       }
*/ 
/*
// 16)
 #include <stdio.h>
        int main()
        {
            double *ptr = (double *)100;

            ptr = ptr + 2;
            printf("%u\n", ptr);
        }
*/
/*
//   17) 

 #include <stdio.h>
          int main()
          {
              int i = 10;
            void *p = &i;
           // printf("%d\n", (int *)*p);
         printf("%d\n", *(int*)p);
            return 0;
        }
*/
/*
//18) 
  #include <stdio.h>
        int main()
        {
            int a[4] = {1, 2, 3, 4};
            void *p = &a[1];
            void *ptr = &a[2];
            int n = 1;
            n = ptr - p;
            printf("%d\n", n);
        }

*/
// 19)
 #include <stdio.h>
       int main()
        {
            int *p = (int *)2;
            int *q = (int *)3;
            printf("%d", p + q);
        }
/*
 20) Which of the following operand can be applied to pointers p and q?
       (Assuming initialization as int *a = (int *)2; int *b = (int *)3;)
	a) a + b
	b) a – b
	c) a * b
	d) a / b
  
      Ans: b)
*/
