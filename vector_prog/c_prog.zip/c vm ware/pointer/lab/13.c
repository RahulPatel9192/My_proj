#include <stdio.h>
        int main()
        {
           // int *p;
	    void *p;
            int a[4] = {1, 2, 3, 4};
            p = &a[3];
            int *ptr = &a[2];
//printf("%u %u",ptr,p);
//printf("\n");
//printf("%u %u",&a[2],&a[3]);
            int n = (int *)p - ptr;
            printf("%d\n", n);
        }

