//31)
/*
#include <stdio.h>
        int main()
        {
            char *str = "hello world";
            char strc[50] = "good morning india\n";
            strcpy(strc, str);
            printf("%s\n", strc);
            return 0;
        }


//  32)
 #include <stdio.h>
        int main()
        {
            char *str = "hello, world\n";
            str[5] = '.';
            printf("%s\n", str);
            return 0;
        }

// 33)
 #include <stdio.h>
        int main()
        {
            char str[] = "hello, world";
            str[5] = '.';
            printf("%s\n", str);
            return 0;
        }

 // 34)
 #include <stdio.h>
        int main()
        {
            char *str = "hello world";
            char strary[] = "hello world";
            printf("%d %d\n", sizeof(str), sizeof(strary));
            return 0;
        }

 //  35)
 #include <stdio.h>
        int main()
        {
            char *str = "hello world";
            char strary[] = "hello world";
            printf("%d %d\n", strlen(str), strlen(strary));
            return 0;
        }

// 36)
  #include<stdio.h>
       int main() 
       {
	int a = 5,b = 4,c = 9;
	*(a>b ? &a : &b) = (a+b)>c;
	printf("%d  %d\n",a,b);
       }

37)  Find the sizeof any datatype with out using sizeof operator. (Hint : Use pointers)

//38)
  #include<stdio.h>
        int main()
        {
	int i;
	double a = 5.2;
	char *ptr;
	ptr = (char *)&a;
	for(i=0;i<=7;i++)
	printf("%d\n",*ptr++);
	return 0;
        }

//39)  Correct the following program. 
          #include<stdio.h>
	int main()
	{
		void *p;  
                      int  **ptr;  
                      int a = 129;
		p = &a;  
                      ptr = &p;
		printf(" p = %d   p = %u  &p = %u\n", *p, p, &p);
           }
*/
//40)
 #include<stdio.h> 
      main() 
      { 
	char a[20]; 
	char *p,*q; 
	p=&a[0]; 
	q=&a[10]; 
	printf("%d %d\n",q-p,&q-&p); 
      }

