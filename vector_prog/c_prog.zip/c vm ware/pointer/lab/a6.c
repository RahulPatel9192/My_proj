#include <stdio.h>
        void main()
        {
            int x = 0;
            int *ptr = &5;
            printf("%p\n", ptr);
        }

