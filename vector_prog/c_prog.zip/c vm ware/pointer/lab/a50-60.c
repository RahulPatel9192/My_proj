/*//51)
#include <stdio.h>
        void f(char *k)
        {
            k++;
            k[2] = 'm';
            printf("%c\n", *k);
        }
        void main()
        {
            char s[] = "hello";
            f(s);
            printf("%s\n",s);
        }
*/
/*
// 52)
  #include<stdio.h>
        void t1(char *q);
        main()
        {
		char *p;
		p = "abcder";
		t1(p);
        }
        void t1(char *q)
        {
		if(*q!='r')
		{
			putchar(*q);
			t1(q++);
		}
        }
*/
	
//53)
 #include<stdio.h>
       int main()
{
       int i;
       float a=5.2;
       char *ptr;
       ptr=(char *)&a;
       for(i=0;i<=3;i++)
       printf("%d ",*ptr++);
       return 0;
       }
/*
// 54)
 #include <stdio.h>
        void foo( int[] );
        int main()
        {
            int ary[4] = {1, 2, 3, 4};
            foo(ary);
            printf("%d ", ary[0]);
        }
        void foo(int p[4])
        {
            int i = 10;
            p = &i;
            printf("%d ", p[0]);
        }


//  55)
 #include <stdio.h>
        void main()
        {
            int k = 5;
            int *p = &k;
            int **m  = &p;
             **m = 10;
            printf("%d%d%d\n", k, *p, **m);
        }

// 56)
 #include <stdio.h>
        int main()
        {
            int a = 1, b = 2, c = 3;
            int *ptr1 = &a, *ptr2 = &b, *ptr3 = &c;
            int **sptr = &ptr1; 
	    printf("%d  ",**sptr);
            *sptr = ptr2;
	    printf("%d  ",**sptr);
        }



// 57)
 #include <stdio.h>
        void main()
        {
            int a[3] = {1, 2, 3};
            int *p = a;
            int *r = &p;
            printf("%d\n", (**r));
        }

//58)
  #include <stdio.h>
        int main()
        {
            int i = 97, *p = &i;
            foo(&p);
            printf("%d ", *p);
            return 0;
        }
        void foo(int **p)
        {
            int j = 2;
            *p = &j;
            printf("%d ", **p);
        }

// 59)
 #include <stdio.h>
        void foo(int *const *p);
        int main()
        {
            int i = 11;
            int *p = &i;
            foo(&p);
            printf("%d ", *p);
        }
        void foo(int *const *p)
        {
            int j = 10;
            *p = &j;

            printf("%d ", **p);
        }

//60)
   #include <stdio.h>
        void foo(int const **p);
        int main()
        {
            int i = 10;
            int *p = &i;
            foo(&p);
            printf("%d ", *p);
        }
        void foo(int const **p)
        {
            int j = 11,k=9;
            *p = &j;
++p;
(*p)++;

            printf("%d ", **p);
        }
*/
