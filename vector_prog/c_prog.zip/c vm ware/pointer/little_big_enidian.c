//prove that we are working om littile or big eniding

#include<stdio.h>
main()
{
int i=1;
char *ch;

ch=&i;

*ch?printf("little enidian\n"):printf("big enidian\n");



}




