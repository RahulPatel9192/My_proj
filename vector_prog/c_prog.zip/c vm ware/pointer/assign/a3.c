#include<stdio.h>
main()
{
int a[10];
printf("%u %u",a+1,&a+1);
printf("\n");


}
