#include<stdio.h>
main()
{
char a[]="sun";
char *p="emmanuel";
a="emmaunel";
p="sun";
printf("\n %s %s\n",a,p);






}


