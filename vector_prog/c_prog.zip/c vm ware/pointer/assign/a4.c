#include<stdio.h>
main()
{
int arr[]={10,20,36,72,87,20};
int *j,*k;
j=&arr[4];
k=(arr+4);
if(j==k)
printf("two pointer points the same location\n");
else
printf("two pointer do not point the same location\n");


}
