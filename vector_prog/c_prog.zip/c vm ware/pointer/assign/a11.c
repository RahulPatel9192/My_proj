#include<stdio.h>
main()
{
int arr[]={12,13,14,15,16};
printf("\n %d %d %d\n",sizeof(arr),sizeof(*arr),sizeof(arr[0]));



}
