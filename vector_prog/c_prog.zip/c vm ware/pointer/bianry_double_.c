//print binary format of double using int or char pointer

#include<stdio.h>
main()
{
int i,j,*ip;
char *ch;
double d=3.5;
//////////////////////using ip pointer

ip=&d;
ip=ip+1;
for(i=0;i<2;i++)
{
for(j=7;j>=0;j--)
(*ip&1<<j)?printf("1"):printf("0");
ip=ip-1;

}
//////////////////using ch pointer

/*
ch=&d;
ch=ip+7;
for(i=0;i<8;i++)
{
for(j=7;j>=0;j--)
(*ch&1<<j)?printf("1"):printf("0");
ch=ch-1;

}*/
