// print bianry format of float using char pointer
#include<stdio.h>
main()
{
int i,j;
float f=3.5;
char *ch;

ch=&f;

ch=ch+3;
for(i=0;i<4;i++)
{
for(j=7;j>=0;j--)
if(*ch&1<<j)
printf("1");
else
printf("0");


ch=ch-1;
}



}
