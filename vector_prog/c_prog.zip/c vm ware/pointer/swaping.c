//swap two numbers

#include<stdio.h>
main()
{
int i=10,j=20,t;
int *k,*l;
t=i;
k=&j;
l=&t;
i=*k;
j=*l;
printf("i=%d j=%d\n",i,j);





}
