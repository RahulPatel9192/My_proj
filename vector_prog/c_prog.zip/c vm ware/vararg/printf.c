#include<stdio.h>
#include<stdarg.h>
void my_printf(char *,...);
main()
{
	int i=10;
	char ch='a';
	float f=23.5;
	printf("i=%d ch=%c f=%f\n",i,ch,f);

	my_printf("i=%d ch=%c f=%f\n",i,ch,f);

}

void my_printf(char *p,...)
{
	int i,r;
	char ch;
	float f;

	va_list v;
	va_start(v,p);
	for (i=0;p[i];i++)
	{
		if(p[i]=='%')
		{
			i++;
			if(p[i]=='d')
			{
				r=va_arg(v,int);
				printf("%d",r);

			}
			if(p[i]=='c')
			{
				r=va_arg(v,int);
				printf("%c",r);
			}
			if(p[i]=='f')
			{
				f=va_arg(v,double);
				printf("%f",f);
			}

		}		
			else
				printf("%c",p[i]);



		



	}
}
