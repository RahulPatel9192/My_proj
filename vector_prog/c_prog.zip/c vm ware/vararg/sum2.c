//puting last '\0' method


#include<stdio.h>
#include<stdarg.h>
int sum(char *,...);
main()
{
	int i=10,j=20,k=30,l=0;

	l=sum("hello",i,j,0);
	printf("l=%d\n",l);

	l=sum("hiee",i,j,k,0);
	printf("l=%d\n",l);

}

int sum(char *n,...)
{
	int num=0,ret;

	//1 step

	va_list v;
	va_start(v,n);
	for( ; ; )
	{
		ret=va_arg(v,int);
		if(ret==0)
			break;
		num=num+ret;
	}
	return num;

}
