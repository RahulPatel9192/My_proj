#include<stdio.h>
#include<stdarg.h>
int sum(int,...);
main()
{
int i=10,j=20,k=30,l=0;

l=sum(2,i,j);
printf("l=%d\n",l);

l=sum(3,i,j,k);
printf("l=%d\n",l);

}

int sum(int n,...)
{
int num=0,i;

//1 step

va_list v;
va_start(v,n);
for(i=0;i<n;i++)
num=num+va_arg(v,int);
return num;





}
