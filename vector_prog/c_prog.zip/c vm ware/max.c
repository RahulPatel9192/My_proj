#include <stdio.h>
main()
{
int i,j,k;
printf("enter the nu\n");
scanf("%d %d %d",&i,&j,&k);
i>j?i>k?printf("i is greater\n"):printf("k is greater\n"):j>k?printf("j is greater\n"):printf("k is greater\n");





}

