#include<stdio.h>
int sum(int);
main()
{
int n,s;
printf("enter nu...");
scanf("%d",&n);

s=sum(n);
printf("s=%d",s);
printf("\n");


}
int sum(int n)
{
int r;
if(n)
{
r=n%10;
n=n/10;
return(r+sum(n));

}
else
return 0;



}
