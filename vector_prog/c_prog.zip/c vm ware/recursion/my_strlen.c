#include<stdio.h>
int strlen(char *);
main()
{
char s[20];
int r;
printf("Enter the string...");
scanf("%s",s);

r=strlen(s);
printf("%d\n",r);


}
int strlen(char *s)
{
if(*s)
return (1+strlen(s+1));
else
return 0;


}
