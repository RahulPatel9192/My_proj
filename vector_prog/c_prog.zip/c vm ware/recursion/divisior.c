#include<stdio.h>
int divisior(int);
main()
{
	int n,s;
	printf("Enter nu...");
	scanf("%d",&n);
	s=divisior(n);
	printf("s=%d\n",s);

}
int divisior(int n)
{
	static c=1,s;
	if(c<n)
	{
		if(n%c==0)
		{

			s=s+c;
			printf("s=%d n=%d c=%d\n",s,n,c);

		//	c++;
		}
		c++;
		divisior(n);
	
	}


	else
		return s;
}



