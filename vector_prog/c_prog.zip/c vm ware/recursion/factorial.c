#include<stdio.h>
int fact(int);
main()
{
int num,res;
printf("Enter the num...");
scanf("%d",&num);
res=fact(num);
printf("%d\n",res);
}
int fact(int n)
{
if(n>1)
return n*fact(n-1);
else
return 1;

}





