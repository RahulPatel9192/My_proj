#include<stdio.h>
int rev(int);
void word(int);

main()
{
int n,s;
printf("Enter nu...");
scanf("%d",&n);
s=rev(n);
//printf("s=%d\n",s);
word(s);
printf("\n");

}
int rev(int n)
{
int r;
static s=0;
if(n)
{
r=n%10;
n=n/10;
s=s*10+r;
//printf("%d  ",s);
return(rev(n));
}
else 
return s;
}


void word(int s)
{
int r;
//static s=0;
if(s)
{
r=s%10;
s=s/10;
switch(r)
{
case 1:
printf("ONE");
break;

case 2:
printf("TWO");
break;

case 3:
printf("THREE");
break;

case 4:
printf("FOUR");
break;

case 5:
printf("FIVE");
break;

case 6:
printf("SIX");
break;

case 7:
printf("SEVEN");
break;

case 8:
printf("EIGHT");
break;

case 9:
printf("NINE");
break;

case 0:
printf("ZERO");
break;
}
printf(" ");
word(s);
}



}





