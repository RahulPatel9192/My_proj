#include<stdio.h>
void rev(int);
main()
{
int n;
printf("Enter the nu...");
scanf("%d",&n);

rev(n);
printf("\n");

}
void rev(int num)
{
static int i,j=31;
int m=0,n=0;

if(i<j)
  {

  m=num>>i&1;
  n=num>>j&1;
  if(m!=n)
  {
  num=num^(1<<i);
  num=num^(1<<j);
 }

i++;
j--;
rev(num);
}
else
for(j=31;j>=0;j--)
printf("%d",num>>j&1);
}
