#include<stdio.h>
void print(const char *);
main()
{
char a[20];
 printf("Enter the string...");
scanf("%s",a);

print(a);
printf("\n");

}

void print(const char *s)
{
int i;
if(*s)
{
//printf("%c",*s);
//print(s+1);        ////print string
print(s+1);
printf("%c",*s);     ///reverse print string
}


}

