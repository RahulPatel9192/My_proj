#include<stdio.h>
void strrev(char *,char *);
main()
{
	char s[20];
	int i;
	printf("Enter the string...");
	scanf("%s",s);
	for(i=0;s[i];i++);
	strrev(s,s+i-1);
	printf("%s\n",s);
}
void strrev(char *p,char *q)
{
	char temp;
	if(p<q)
	{
		temp=*p;
		*p=*q;
		*q=temp;
		strrev(p+1,q-1);
	}



}
