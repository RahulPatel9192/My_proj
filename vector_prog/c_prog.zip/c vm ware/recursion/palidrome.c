#include<stdio.h>
void palin(int,int);
main()
{
	int n,n1;
	printf("Enter nu...");
	scanf("%d",&n);
	n1=n;
	palin(n,n1);
	printf("\n");

}
void palin(int n,int n1)
{
	int r;
	static s=0;
	if(n)
	{
		r=n%10;
		n=n/10;
		s=s*10+r;
		//printf("%d  ",s);
		palin(n,n1);

	}
	else
	{
		if (n1==s)
			printf("palindrom\n");
		else
			printf("not palindrome\n");
	}
}
