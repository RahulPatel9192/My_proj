#include<stdio.h>
void big(int,int,int  *);
main()
{
int a[]={6,10,3,4,5},ele;
ele=sizeof(a)/sizeof(a[0]);
int temp;
temp=a[0];
big(temp,ele,a);

printf("\n");

}
void big(int temp,int ele,int *a)
{
static int i=1,j;
//ele=sizeof(a)/sizeof(a[0]);
//printf("e=%d\n",ele);
if(i<ele)
{
if(temp<a[i])
{
temp=a[i];

}
i++;

//printf("t=%d i=%d ele=%d\n",temp,i,ele);
big(temp,ele,a);
}
else
printf("big=%d",temp);


}
