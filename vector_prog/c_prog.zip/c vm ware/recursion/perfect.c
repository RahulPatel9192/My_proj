#include<stdio.h>
void perfect(int);
main()
{
int n;
printf("Entr nu...");
scanf("%d",&n);

perfect(n);
printf("\n");
}
void perfect(int n)
{
static c=1,s;
if(c<n)
{
if(n%c==0)
{
s=s+c;
}
c++;
//printf("s=%d c=%d\n",s,c);

perfect(n);

}
else
{
if(n==s)
printf("nu is perfect\n");
else
printf("nu is not perfect\n");

}


}
