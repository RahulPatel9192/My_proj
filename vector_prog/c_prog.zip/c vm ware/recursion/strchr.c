#include<stdio.h>
char *strchr(char *,char);
main()
{
char s[20],ch,*p;
printf("Enter the string...");
scanf("%s",s);
printf("char...");
scanf(" %c",&ch);
p=strchr(s,ch);
if(p)
printf("ch=%c\n",*p);
else
printf("not find\n");
}
char *strchr(char *s,char ch)
{
if(*s)
{
if(*s==ch)
return s;
else
return(strchr(s+1,ch));
}
else
return 0;

}
