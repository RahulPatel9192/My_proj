#include<stdio.h>
void strcpy(char *,char *);
main()
{
char s[10],d[10];

printf("Enter the string...");
scanf("%s",s);

strcpy(s,d);
printf("d=%s",d);

printf("\n");
}
void strcpy(char *p,char *q)
{
if(*p)
{
*q=*p;
strcpy(p+1,q+1);

}
else
*q='\0';

}
