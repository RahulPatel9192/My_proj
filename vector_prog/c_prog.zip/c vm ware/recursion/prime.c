#include<stdio.h>
void prime(int);
main()
{
int n;
printf("Enter value...");
scanf("%d",&n);

prime(n);
printf("\n");

}
void prime(int n)
{
int i,c=0;
if(n)
{
for(i=1;i<=n;i++)
{
if(n%i==0)
c++;

}
if(c==2)
printf("%d ",n);
n--;
prime(n);
}




}
