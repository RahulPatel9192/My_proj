
#include<stdio.h>
int rev(int);
main()
{
int n,s;
printf("enter nu...");
scanf("%d",&n);

s=rev(n);
printf("s=%d",s);
printf("\n");


}
int rev(int n)
{
int r;
static s=0;
if(n)
{
r=n%10;
n=n/10;
s=s*10+r;
//printf("%d  ",s);
return(rev(n));

}
else
return s;



}
