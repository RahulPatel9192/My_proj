#include<stdio.h>
#include<string.h>
void rev(int,char *);
main()
{
//int a[]={1,2,3,4,5};
char s[]="hello";
int ele,i;
//ele=sizeof(a)/sizeof(a[0]);
ele=strlen(s);
rev(ele,s);
/*{
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");
}
*/
printf("%s",s);
printf("\n");

}
void rev(int ele,char *a)
{
//int temp;
char temp;
static int j,i;

if(i<ele)
{
temp=a[i];
a[i]=a[ele-1];
a[ele-1]=temp;
i++;
ele--;
//printf("i=%d j=%d\n",i,ele);
rev(ele,a);
}



}
