#include<stdio.h>
void fibonci(int,int,int);
main()
{
	int n,f=0,s=1;
	printf("enter nu...");
	scanf("%d",&n);
	fibonaci(f,s,n);
}
void fibonaci(int f,int s,int n)
{
	static p=0;
	int q;
	if(n>0)
	{
		if(p<=1)
			q=p;

		else
		{
			q=f+s;
			f=s;
			s=q;

		}
		printf("%d ",q);
		p++;
		n--;

		fibonaci(f,s,n);
	}
}
