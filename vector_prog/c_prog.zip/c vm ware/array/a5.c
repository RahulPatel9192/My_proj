#include<stdio.h>
main()
{
int a[5],i,j,k;
int ele,temp;

ele=sizeof(a)/sizeof(a[0]);
printf("Enter the nu....");

for(i=0;i<ele;i++)
scanf("%d",&a[i]);

for(i=0;i<ele;i++)
printf("%d ",a[i]);

printf("\n");

for(i=0,j=ele-1;j>i;i++,j--)
{
temp=a[i];
a[i]=a[j];
a[j]=temp;


}
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");
}
