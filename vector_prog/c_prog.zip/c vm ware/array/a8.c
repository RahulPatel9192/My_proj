//dlt duplicate number

#include<stdio.h>
main()
{
	char a[10]={'a','a','c','d','b','b','l','p','l','c'};
	int i,j,k,ele;

	ele=sizeof(a)/sizeof(a[0]);

	for(i=0;i<ele;i++)
		printf("%c",a[i]);

	for(i=0;i<ele;i++)
	{
		for(j=i+1;j<ele-1;j++)

			if(a[i]==a[j])

			{
				for(k=i;k<ele;k++)
					a[k]=a[k+1];

			}


	}
	printf("\n");
	for(i=0;i<ele;i++)
		printf("%c",a[i]);
	printf("\n");
}
