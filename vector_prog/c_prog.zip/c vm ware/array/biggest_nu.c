#include<stdio.h>
main()
{
int a[5],i,j,temp,ele;
printf("Enter the value....\n");
ele=sizeof(a)/sizeof(a[0]);


for(i=0;i<ele;i++)
scanf("%d",&a[i]);

for(i=0;i<5;i++)
printf("%d ",a[i]);
printf("\n");
///////////////////////////////////
temp=a[0];
j=a[0];
for(i=1;i<ele;i++)
{
if(temp<a[i])
temp=a[i];
if(j>a[i])
j=a[i];

}
printf("biggest nu=%d\n",temp);
printf("smallest nu=%d\n",j);
printf("\n");





}
