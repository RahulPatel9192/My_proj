#include<stdio.h>
main()
{
int a[5],i,k;
int ele,j;

ele=sizeof(a)/sizeof(a[0]);
printf("Enter the array....");

for(i=0;i<ele;i++)
scanf("%d",&a[i]);

printf("enter the array pos=");
scanf("%d",&j);

for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");

//a[j]=" "; 
for(i=j;i<ele-1;i++)
a[i]=a[i+1];
//a[i]=0;
for(i=0;i<ele-1;i++)
printf("%d ",a[i]);
printf("\n");
}
