//even odd +ve -ve
#include<stdio.h>
main()
{
int a[5],e,o,p,n,ele,i,c,j,k;
printf("Enter the nu....\n");

ele=sizeof(a)/sizeof(a[0]);

for(i=0;i<ele;i++)
scanf("%d",&a[i]);
 
for(i=0;i<ele;i++)
{
printf("%d ",a[i]);

}
printf("\n");
//////////////////////////////////even- odd

for(j=0,e=0,o=0;j<ele;j++)
{
if(a[j]%2==0)
e++;
else
o++;
}

///////////////////////////////+ve --- -ve
for(k=0,n=0,p=0;k<ele;k++)
{
if(a[k]<0==0)
p++;
else
n++;


}
////////////////////////////////////
printf("even value=%d\n",e);
printf("odd value=%d\n",o);
printf("positive value=%d\n",p);
printf("negative value=%d\n",n);
printf("\n");



}
