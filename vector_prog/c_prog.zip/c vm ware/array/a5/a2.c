#include<stdio.h>
main()
{
char c[2]="A";
printf("\n%c",c[0]);
printf("\n%s",c);





}

