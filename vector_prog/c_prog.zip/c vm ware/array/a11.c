#include<stdio.h>
main()
{
	int a[]={6,3,1,6,5,1,2,6,4,5,1},n[5],r[5];
	int i,j,k,ele,c,ele1,m=0,l;

	ele=sizeof(a)/sizeof(a[0]);
	ele1=ele;

	for(i=0,m=0,l=0;i<ele1;i++)
	{
		for(j=i+1,c=1;j<ele1;j++)
		{


			if(a[i]==a[j])
			{
				c++;
				r[m++]=a[j];
				for(k=j;k<ele1;k++)
					a[k]=a[k+1];

				j--;
				ele1--;
			}

}
			if (c>1)		
				printf("%d is repeted %d times\n",a[i],c);


	}
for(i=0;i<ele1;i++)
printf("%d ",a[i]);
printf("\n");

printf("Repeat element\n");
for(i=0;i<m;i++)
printf("%d ",r[i]);
printf("\n");
}

