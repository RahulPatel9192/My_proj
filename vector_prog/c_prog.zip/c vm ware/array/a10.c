#include<stdio.h>
main()
{
	int a[5]={1,2,2,3,5},b[5];
	int ele,i,j,c;

	ele=sizeof(a)/sizeof(a[0]);

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);

	printf("\n");

	for(i=0;i<ele;i++)
	{
		for(j=0,c=0;j<ele;j++)
		{
			if(a[i]==a[j])
			{
				c++;
			}
		}
		if(c==1)
			printf("%d ",a[i]);

	}
printf("\n");



}

