#include<stdio.h>
main()
{
int a[5],i,ele,b,j,temp;

ele=sizeof(a)/sizeof(a[0]);
printf("Enter the array...");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);

for(i=0;i<ele;i++)
printf("%d ",a[i]);

printf("\n");

for(i=0,j=ele;i<ele;i++,j--)
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
for(i=0;i<ele;i++)
printf("%d",a[i]);
printf("\n");
}

