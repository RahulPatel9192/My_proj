#include<stdio.h>
main()
{
int s[50],n,i,j,k=0;

printf("Enter number...");
scanf(" %d",&n);

for(i=0,j=1;i<n;i++,j++)
{

if(j<=n)
{

s[i]=j*j;
k=s[i]+k;
}

}
printf("\ns=");
for(i=0;i<n;i++)
printf("%d ",s[i]);
printf("\nsum=%d\n",k);
printf("\n");


}
