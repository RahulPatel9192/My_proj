#include<stdio.h>
main()
{

	int a[10],i,j,ele,c=0;
	int n[10],k;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter the array...");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=0,k=0;i<ele;i++,k++)
	{
		for(j=1,c=0;j<=a[i];j++)
		{
			if(a[i]%j==0)
				c++;
		}

		if(c==2)
		{
			//for(k=0;k<ele;k++)
			printf("%d ",n[k]=a[i]);




			//printf("%d ",a[i]);
		}
	}
	printf("\n");
}
