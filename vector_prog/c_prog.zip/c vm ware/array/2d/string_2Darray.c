#include<stdio.h>
void print(char(*)[] ,int);
void print1(char **,int);
main()
{
char s[][10]={"abc","def","ghi"};
char *p[3]={"ABC","DEF","GHI"};
print(s,3);
printf("--------------------------------\n");
print1(p,3);

}
void print(char(*p)[10],int n)
{
int i;
for(i=0;i<n;i++)
printf("%s\n",p[i]);
}
void print1(char **p,int n)
{
int i;
for(i=0;i<n;i++)
printf("%s\n",p[i]);

}
