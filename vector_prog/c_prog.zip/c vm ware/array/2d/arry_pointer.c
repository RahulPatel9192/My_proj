#include<stdio.h>
main()
{
int a[10]={10,20,30,40,50,60,70,80,90,100};
int *p[5]={a,a+2,a+5,a+1,a+3};   //array of pointer

printf("*p[1]=%d\n",*p[1]);
printf("p[1][0]=%d\n",p[1][0]);
printf("*p[1]=%d\n",*p[1]);
printf("*p[3]=%d\n",*p[3]);
printf("*p[1][0]=%d\n",p[1][0]);
printf("**p=%d\n",**p);




}
