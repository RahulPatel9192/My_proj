#include<stdio.h>
main()
{
int a[5]={10,20,30,40,50};
int *ip;
int (*p)[3];     //pointer to an array
ip=a;
p=a;

printf("ip=%u ip+1=%u\n",ip,ip+1);
printf("p=%u p+1=%u\n",p,p+1);
printf("%d %d\n",sizeof(ip),sizeof(p));
printf("%d %d\n",sizeof(*ip),sizeof(*p));
printf("%d %d %d\n",(*p)[1],(*p)[2]);
printf("%u %u\n",ip,*ip);
printf("%u %u\n",p,*p);


}


