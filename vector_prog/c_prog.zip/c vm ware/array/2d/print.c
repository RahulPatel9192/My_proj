#include<stdio.h>
main()
{
int r,c,i,j;
int b[2][3]={10,20,30,40,50,60};

r=sizeof(b)/sizeof(b[0]);                     //find row of array
c=sizeof(b[0])/sizeof(b[0][0]);          //find coloum 

for(i=0;i<r;i++)         //print array
{
for(j=0;j<c;j++)
printf("%d ",b[i][j]);
printf("\n");
}





}
