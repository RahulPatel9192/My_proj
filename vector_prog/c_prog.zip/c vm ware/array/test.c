#include<stdio.h>
#include<string.h>
main()
{
int a[]={1,2,3,4,5};
int i;
for(i=0;i<5;i++)
printf("befor=%d \n",a[i]);

for(i=0;i<5;i++)
{
if(i>0)
{
a[i]=a[i+1];
}
}
for(i=0;i<5;i++)
printf("after=%d ",a[i]);
printf("%d\n",a[5]);
}
