#include<stdio.h>
main()
{
int a[10],i,ele,b,s;

ele=sizeof(a)/sizeof(a[0]);
printf("Enter the array...");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);

for(i=0;i<ele;i++)
printf("%d ",a[i]);

b=a[0];
s=a[0];
for(i=1;i<=ele;i++)
{
if(b<a[i])
b=a[i];
if(s>a[i])
s=a[i];

}
printf("big=%d small=%d\n",b,s);
printf("\n");




}
