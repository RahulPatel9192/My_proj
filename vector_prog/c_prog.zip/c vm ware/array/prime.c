#include<stdio.h>
main()
{
int a[5],i,j,c=0,p=0,ele,r;
printf("Enter the value....\n");
ele=sizeof(a)/sizeof(a[0]);


for(i=0;i<ele;i++)
scanf("%d",&a[i]);

for(i=0;i<5;i++)
printf("%d ",a[i]);
//////////////////////////////////
for(j=0;j<5;j++)
{
for(i=1,c=0;i<=a[j];i++)
{
r=a[j]%i;
if(r==0)
c++;
}
if(c==2)
p++;
}
printf("number=%d\n",p);

}
