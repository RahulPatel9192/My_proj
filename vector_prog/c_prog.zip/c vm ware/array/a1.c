#include<stdio.h>
main()
{
	int a[10],i,k=0,l=1;
	printf("Enter the value...\n");
	for(i=0;i<10;i++)

		scanf("%d",&a[i]);


	for(i=0;i<10;i++)

		printf("%d ",a[i]);

	for(i=0;i<10;i++)
	{
		if(a[i]%2==0)
			k=a[i]+k;
		else
			l=a[i]*l;



	}




	printf("addition of even  nu=%d\n",k);
	printf("mul of even nu=%d\n",l);



	printf("\n");

}
