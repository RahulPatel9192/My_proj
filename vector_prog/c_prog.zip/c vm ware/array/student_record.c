#include<stdio.h>
#include<string.h>
main()
{
	char n[5][10],temp[10];
	int r[5],tempr;
	float m[5],tempm;
	int i,c,v,j;
	printf("Enter name.....\n");
	for(i=0;i<5;i++)
		scanf("%s",n[i]);
	printf("---------------------------------\n");

	////////////////////////////////roll nu
	printf("Enter roll nu...\n");
	for(i=0;i<5;i++)
		scanf("%d",&r[i]);
	printf("\n");
	/////////////////////////////////////// marks

	printf("Enter marks ...\n");
	for(i=0;i<5;i++)
		scanf("%f",&m[i]);
	printf("\n");
	//////////////////////////////////////////////////

	printf("sorting a database\n1)according to name\n2)according to rollnu\n3)according to marks\n");

	scanf("%d",&c);
	switch(c)
	{
		case 1:

			for(i=0;i<5;i++)
			{
				for(j=i+1;j<5;j++)
				{
					v=strcmp(n[i],n[j]);

					if(v==1)
					{
						strcpy(temp,n[i]);
						strcpy(n[i],n[j]);
						strcpy(n[j],temp);

						tempm=m[i];
						m[i]=m[j];
						m[j]=tempm;

						tempr=r[i];
						r[i]=r[j];
						r[j]=tempr;

					}

				}		
			}
			break;


		case 2:
			for(i=0;i<5;i++)
			{
				for(j=i+1;j<5;j++)
				{

					if(r[i]>r[j])
					{
						strcpy(temp,n[i]);
						strcpy(n[i],n[j]);
						strcpy(n[j],temp);

						tempm=m[i];
						m[i]=m[j];
						m[j]=tempm;

						tempr=r[i];
						r[i]=r[j];
						r[j]=tempr;

					}
				}
			}
			break;

		case 3:


			for(i=0;i<5;i++)
			{
				for(j=i+1;j<5;j++)
				{

					if(m[i]>m[j])
					{
						strcpy(temp,n[i]);
						strcpy(n[i],n[j]);
						strcpy(n[j],temp);

						tempm=m[i];
						m[i]=m[j];
						m[j]=tempm;

						tempr=r[i];
						r[i]=r[j];
						r[j]=tempr;

					}
				}
			}
			break;

			default:
				printf("choose propar option...\n");
	}
	printf("Name	   Marks	rollnumber\n");
	for(i=0;i<5;i++)
		printf("%s   	   %f    	   %d\n",n[i],m[i],r[i]);
}
