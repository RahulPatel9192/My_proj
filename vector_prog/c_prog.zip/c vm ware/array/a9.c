#include<stdio.h>
main()
{
	int a[]={0,3,1,0,0,5,1,2,0,4,5};
	int i,j,k,ele,c=1,ele1;

	ele=sizeof(a)/sizeof(a[0]);
	ele1=ele;

	for(i=0;i<ele1;i++)
	{
		for(j=i+1,c=1;j<ele1;j++)
		{


			if(a[i]==a[j])
			{	c++;
			for(k=j;k<ele1;k++)
				a[k]=a[k+1];
				
				j--;
				ele1--;		

			}
		}

		if (c>1)
			printf("%d is repeted %d times\n",a[i],c);
	}


	printf("\n");

}

