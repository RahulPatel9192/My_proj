#include<stdio.h>
main()
{
	int a[5],i,j,temp,ele;
	printf("Enter the value....\n");
	ele=sizeof(a)/sizeof(a[0]);


	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	for(i=0;i<5;i++)
		printf("%d ",a[i]);
printf("\n");
	//////////////////////////////////
	for(i=0;i<ele-1;i++)
	{
		for(j=0;j<ele-1-i;j++)
		{
			if(a[j]>a[j+1])
			{
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;


			}


		}



	}

	for(i=0;i<5;i++)
		printf("%d ",a[i]);
printf("\n");
printf("last ele=%d\n",a[4]);
printf("\n");



}
