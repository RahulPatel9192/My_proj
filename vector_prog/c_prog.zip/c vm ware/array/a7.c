#include<stdio.h>
main()
{
	int a[6]={10,20,30};
	int i,ele,p,j,k;
	//char ch;
	ele=sizeof(a)/sizeof(a[0]);

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
	printf("Enter the pos=");
	scanf("%d",&p);
	printf("\n");
	printf("Enter int=");
	scanf("%d",&j);
//////////////////////////////////////////////////
	k=ele-1;
	for(i=k;k>p;k--)
		a[k]=a[k-1];

	a[p]=j;

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");






}
