#include<stdio.h>
double my_atof(char *);
main()
{
	double f;
	char s[10];

	printf("Enter the number...\n");
	scanf("%s",s);


	f=my_atof(s);

	printf("%lf\n",f);

}

double my_atof(char *s)
{
	int i,l,c=0, x=0,j,z=10;;
	double m,y=0,num;

	//////////////////////////x=23
	for(i=0;s[i];i++)
	{
		if(s[i]=='.')
			break;

		if(s[i]>'1' && s[i]<'9')
			x=x*10+s[i]-48;

	}

	//////////////////////////// y=75
	for(l=i+1,c=0;s[l];l++)
	{
		if(s[l]>'1' && s[l]<'9')
			y=y*10+s[l]-48;
		c++;
	}


	for(j=1,z=10;j<c;j++)
	{
		z=z*10;
	}
	m=y/z;

	num=x+m;
	return num;

}
