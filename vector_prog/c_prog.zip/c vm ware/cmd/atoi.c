#include<stdio.h>
int atoi(char *);
main()
{
char s[]="1234";
int i;
i=atoi(s);
printf("s=%s  i=%d\n",s,i);

}

int atoi(char *p)
{
int i;
int num=0;
for(i=0;p[i];i++)
num=num*10+p[i]-48;
return num;





}
