#include<stdio.h>

main(int argc,char **argv)
{
int i;
if(argc!=2)
{
printf("usage:./my_strln string\n");
return;
}
for(i=0;argv[1][i];i++);
printf("the length of %s=%d\n",argv[1],i);





}

