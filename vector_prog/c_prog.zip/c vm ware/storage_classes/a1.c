#include<stdio.h>
static int i=10;
//auto int i=10;
main()
{
auto int i=20;
printf("%d\n",i);


}

