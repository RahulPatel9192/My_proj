//conditional commpilateion

#include<stdio.h>
#define op 1
#if(op==1)
int sum(int i,int j)
{
return (i+j);
}
#elif(op==2)
int sub(int i,int j)
{
return (i-j);
}
#elif(op==3)
int mul(int i,int j)
{
return (i*j);
}
#elif(op==4)
int div(int i,int j)
{
return (i/j);
}
#endif
main()
{
int m=10,n=20,k;

#if(op==1)
{
k=sum(m,n);
printf("k=%d\n",k);
}

#elif(op==2)
{
k=sub(m,n);
printf("k=%d\n",k);
}

#elif(op==3)
{
k=mul(m,n);
printf("k=%d\n",k);
}
#elif(op==4)
{
k=div(m,n);
printf("k=%d\n",k);
}
#endif
}
