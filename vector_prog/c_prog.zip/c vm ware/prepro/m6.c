//predefiend macro

#include<stdio.h>
main()
{
printf("%s\n",__FILE__);	//it shows recent filename
printf("%s\n",__TIME__);	//it shows time when preproceesing is done
printf("%s\n",__DATE__);	//it shows date when preprocessing is done
printf("%d\n",__LINE__);	//give line nu @this statement is right

}
