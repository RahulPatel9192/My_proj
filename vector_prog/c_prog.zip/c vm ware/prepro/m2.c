#include<stdio.h>
#define swap(i,j,type) {type temp;\
			temp=i;\
			i=j;\
			j=temp;\
			}
main()
{
int m=10,n=20;
float f=3.5,f1=4.5;

printf("before m=%d n=%d\n",m,n);
swap(m,n,int)
printf("after m=%d n=%d\n",m,n);

printf("before f=%f f1=%f\n",f,f1);
swap(f,f1,float)
printf("after f=%f f1=%f\n",f,f1);
}
