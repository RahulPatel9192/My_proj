//finding biggest of two nu..

#include<stdio.h>
#define BIG(m,n) if(m>n)\
		printf(#m "is greater\n");\
		else\
		printf(#n "is greater\n");\

main()
{
int i=10,j=20;
BIG(i,j);
}
