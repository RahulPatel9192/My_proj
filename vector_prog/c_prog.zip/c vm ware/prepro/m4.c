//define a macro for set a bit or clear a bit or complimating a bit

#include<stdio.h>
#define set(n,pos) n|(1<<pos)
#define clear(n,pos) n&~(1<<pos)
#define comp(n,pos) n^(1<<pos) 
main()
{
int n=12,pos=3,m;
printf("set=%d\n",m=set(n,pos));
printf("clear=%d\n",m=clear(n,pos));
printf("comp=%d\n",m=comp(n,pos));


}
