#include<stdio.h>
#include<stdlib.h>
typedef struct tree
{
	struct tree *left;
	int n;
	struct tree *right;
}TREE;

void add_node(TREE **,int);
void preorder(TREE *);
void inorder(TREE *);
void postorder(TREE *);
main()
{
	TREE *hp=0;
	int n;
	char ch;
	do
	{
		printf("wnt to continue? y/n\n");
		scanf(" %c",&ch);
		if(ch=='y')
		{
			printf("Enter the nu\n");
			scanf("%d",&n);
			add_node(&hp,n);
		}
	}while(ch=='y');

	printf("preorder...");
	preorder(hp);
	printf("\n");
	printf("inorder...");
	inorder(hp);
	printf("\n");
	printf("postorder...");
	postorder(hp);
	printf("\n");

}

void add_node(TREE **ptr,int n)
{
	if(*ptr==0)
	{
		*ptr=malloc(sizeof(TREE));
		(*ptr)->n=n;
		(*ptr)->left=0;
		(*ptr)->right=0;
	}

	else if((*ptr)->n < n)
		add_node(&((*ptr)->right),n);

	else
		add_node(&((*ptr)->left),n);
}


void preorder(TREE *ptr)
{
	
	if(ptr)
	{
		printf("%d ",ptr->n);
		preorder(ptr->left);
		preorder(ptr->right);
	}

}

void inorder(TREE *ptr)
{

	if(ptr)
	{
		inorder(ptr->left);
		printf("%d ",ptr->n);
		inorder(ptr->right);


	}


}

void postorder(TREE *ptr)
{

	if(ptr)
	{
		postorder(ptr->left);
		postorder(ptr->right);
		printf("%d ",ptr->n);
	}
}
