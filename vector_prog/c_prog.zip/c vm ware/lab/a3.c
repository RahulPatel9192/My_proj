//using bitwise op check nu is +ve or -ve

#include<stdio.h>
main()
{
int i;
printf("enter the nu=\n");
scanf("%d",&i);
i=(i>>31)&1;
 i==0?printf("positive\n"):printf("negetive\n");



}
