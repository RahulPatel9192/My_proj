//divisibal by 8 or not using bitwise op

#include<stdio.h>
main()

{
int i;
printf("enter the nu=\n");
scanf("%d",&i);
i=i&7;
i==0?printf("divisibal by 8\n"):printf("not divisibal by 8\n");


}
