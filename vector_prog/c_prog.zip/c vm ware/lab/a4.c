//swping two numbers with use of bitwise op

#include<stdio.h>
main()
{
int i,j;
printf("enter two numbers=\n");
scanf("%d %d",&i,&j);
 j=i^j^(i=j);
printf("swaped nu=%d %d\n",i,j);




}
