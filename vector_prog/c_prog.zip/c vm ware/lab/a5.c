//wap to find the given nu is power of 2 or not

#include<stdio.h>
main()
{
int i;
printf("enter the nu=\n");
scanf("%d",&i);
i=i&(i-1);

i==0?printf("nu is power of 2\n"):printf("nu is not power of 2\n");






}
