#include<stdio.h>
main()
{
int i,pos;
printf("enter the number=\n");
scanf("%d",&i);
printf("enter the position=\n");
scanf("%d",&pos);
//i=i|(1<<pos); //set bit
//i=i&~(1<<pos); //clear bit
i=i^(1<<pos); //compliment or toggal bit
printf("required op=%d\n",i);



}
