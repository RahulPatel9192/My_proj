#include<stdio.h>
main()
{
int i,j;
printf("enter the nu=\n");
scanf("%d",&i);
i=i&1;

i==0?printf("nu is even\n"):printf("nu is odd");




}
