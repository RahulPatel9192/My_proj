//print string char by char

#include<stdio.h>
main()
{
char s[5],i;
printf("Enter the sting....");
scanf("%s",s);

for(i=0;s[i];i++)    ////'/0' not come loop will rotate
{
printf("%c",s[i]);

}
printf("\n");




}
