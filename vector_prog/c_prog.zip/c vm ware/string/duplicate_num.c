#include<stdio.h>
main()
{
char s[50];
int i,j,k;

printf("Enter the string...");
scanf("%s",s);

for(i=0;s[i];i++)
{
for(j=i+1;s[j];j++)
{
if(s[i]==s[j])
{
for(k=j;s[k];k++)
s[k]=s[k+1];
j--;

}

}

}
printf("\n");
printf("%s\n",s);



}
