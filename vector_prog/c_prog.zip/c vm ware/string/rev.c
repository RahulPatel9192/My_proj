//reverse print 

#include<stdio.h>
main()
{
char s[5],i,j,temp;

printf("Enter the string.....");
scanf("%s",s);

for(i=0;s[i];i++);

for(j=0,i=i-1;j<i;i--,j++)
{
temp=s[j];
s[j]=s[i];
s[i]=temp;
}

printf("%s",s);
printf("\n");


}
