// delete char

#include<stdio.h>
main()
{
	char s[10],i,j;
	char ch;
	printf("Enter the string...");
	scanf("%s",s);
	printf("Enter ch....");
	scanf(" %c",&ch);

	for(i=0;s[i];i++)
	{
		if(s[i]==ch)
		{
			for(j=i;s[j];j++)
				s[j]=s[j+1];
			i--;
		}
	}
	printf("befor=%s\n",s);





}

