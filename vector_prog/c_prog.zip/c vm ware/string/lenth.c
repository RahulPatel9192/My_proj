//find lenght of string using pointer
#include<stdio.h>
main()
{
char s[]="hello";
char *p;
int c=0,i;

p=&s; 
for(i=0 ;*p++;i++)

c++;

printf("%d",c);
printf("\n");






}
