#include<stdio.h>
main()
{
	int i,j,k,a,b;
	char s1[10],s2[10],s3[20];
	
	printf("Enter1:");
	scanf(" %s",s1);

	printf("Enter2:");
	scanf(" %s",s2);

	for(i=0;s1[i];i++);
	for(j=0;s2[j];j++);

	for(a=0,b=0,k=0;k<i+j;k++)
	{
		if(k%2==0 && s1[a])
		{
			s3[k]=s1[a];
			a++;
		}
		if(k%2!=0 && s2[b])
		{
			s3[k]=s2[b];
			b++;
		}
		if(s1[a]==0 && s2[b]!=0)
		{
			s3[k]=s2[b];
			b++;
		}
	}
	s3[k]='\0';

	printf("%s",s3);
}

