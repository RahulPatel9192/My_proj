#include<stdio.h>
#include<string.h>
main()
{
	char s[50],d[50];
	int i,j,c=0;

	printf("Enter the string...");
	scanf("%s",s);
	
	strcpy(d,s);

	for(i=0;s[i];i++)
	{
		for(j=0,c=0;d[j];j++)
		{
			if(s[i]==d[j])
			{
				c++;
				strcpy(d+j,d+j+1);
				j--;
			}
		}
		if(c>=2)
			printf("%c is repet %d\n",s[i],c);




	}
	printf("\n");
}




