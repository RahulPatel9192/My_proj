#include<stdio.h>
main()
{
	char s[50],d[50],s1[50],sp=' ',ch;
	int i,j,k=0,l;

	printf("Enter string...");
	scanf("%[^\n]",s);
	printf("\n");

	for(l=0;s[l];l++);
	for(i=0,j=l-1;j>i;i++,j--)
	{
		ch=s[i];
		s[i]=s[j];
		s[j]=ch;

	}
	s[l]='\0';
	//////////////////////
for(l=0;s[l];l++);

	for(i=0;i<l+1;i++)
	{


		if(s[i]==sp || s[i]=='\0')
		{

			d[k]=' ';
			k++;

			for(j=i-1;s[j]!=sp && j>=0;j--,k++)
			{
				d[k]=s[j];


			}
		}
	}
	d[k]='\0';

	printf("\n");
	printf("%s\n",d);




}
