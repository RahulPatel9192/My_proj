// check how many times a given char present in string

#include<stdio.h>
main()
{
char s[10],ch;
int i,c=0;
printf("Enter the string....");
scanf("%s",s);
printf("Enter the char=");
scanf(" %c",&ch);

for(i=0,c=0;s[i];i++)
{
if(s[i]==ch)
c++;
}
printf("%c is coming %d times in given string\n",ch,c);







}
