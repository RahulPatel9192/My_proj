//convrt given string into upercase

#include<stdio.h>
main()
{
char s[10];
int i;
printf("Enter the string...");
scanf("%s",s);
printf("Befor=%s\n",s);

for(i=0;s[i];i++)
{
if(s[i]>='a' && s[i]<='z')
s[i]=s[i]-32;                   //convert lower to upper case
}
printf("after=%s\n",s);










}
