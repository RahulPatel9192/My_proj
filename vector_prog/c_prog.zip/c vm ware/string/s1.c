#include<stdio.h>
main()
{
char s[10];
scanf("%s",&s);
//gets(s);
printf("%s",&s);
//puts(s);
printf("\n");





}
