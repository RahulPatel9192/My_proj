//cpy source string into destination string

#include<stdio.h>
main()
{
	char s[5],d[10];
	int i,j;
	printf("Enter the string...");
	scanf("%s",s);
	printf("%s",s);
	printf("\n");

	for(i=0;s[i];i++);

	for(j=0,i=i-1;i>=0;j++,i--)
		d[j]=s[i];
	d[j]='\0';

	printf("%s",d);




}
