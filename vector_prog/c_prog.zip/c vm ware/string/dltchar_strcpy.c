#include<stdio.h>
#include<string.h>
main()
{
int i;
char s[20],ch;
printf("Enter string...");
scanf("%s",s);
printf("Enter char...");
scanf(" %c",&ch);

printf("Before %s\n",s);
for(i=0;s[i];i++)
{
if(s[i]==ch)
{
strcpy(s+i,s+i+1);
i--;

}
}
printf("After %s\n",s);





}
