#include<stdio.h>
#include<string.h>
main()
{
char m[200],s[100],r[100],d[200],*p,*st,*e;
int i,j,k,s1;

printf("Enter main string...");
scanf("%[^\n]",m);
printf("\n");
printf("Enter word... ");
scanf("%s",s);
s1=strlen(s);
printf("\n");
printf("Replace word...");
scanf("%s",r);
printf("\n");
//////////////////////////////i
p=strstr(m,s);
for(i=0,j=0;m+i!=p;i++,j++)
	d[j]=m[i];
for(k=0;r[k];k++,j++)
	d[j]=r[k];
for(i=i+s1;m[i];i++,j++)
	d[j]=m[i];
d[j]='\0';
printf("d=%s\n",d);
}
