#include<stdio.h>
main()
{
	char s[50],d[50],ch=' ';
	int i,j,k,l;

	printf("Enter the string...");
	scanf("%[^\n]",s);
	k=0;
	for(l=0;s[l];l++);
	for(i=0;i<l+1;i++)
	{
		if(s[i]==ch || s[i]=='\0')
		{
			d[k]=' ';
			k++;
			for(j=i-1;s[j]!=ch && j>=0;j--,k++)
			{
				d[k]=s[j];
			}
		}
	}
	d[k]='\0';
	printf("%s",d);
	printf("\n");


}
