#include<stdio.h>
main()
{
char s[50],s1[50];
int i,j,k;
printf("Enter s...");
scanf("%s",s);
printf("Enter s1...");
scanf("%s",s1);




for(i=0;s[i];i++)
{
for(j=0;s1[j];j++)

if(s[i]==s1[j])
continue;



}

if(s[i])
printf("yes\n");
else
printf("no");


}


