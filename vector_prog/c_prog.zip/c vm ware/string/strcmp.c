//compare two string

#include<stdio.h>
main()
{
char s1[10],s2[10];
int i;

printf("Enter the string1....");
scanf("%s",s1);
printf("Enter the string2....");
scanf("%s",s2);

for(i=0;s1[i];i++)
{
if(s1[i]!=s2[i])
break;

}
if(s1[i]==s2[i])
printf("Equal\n");
else
printf("Not Equal\n");







}
