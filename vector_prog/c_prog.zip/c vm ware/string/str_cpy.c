//string cpy one line code without using strcpy
#include<stdio.h>
main()
{
char s[10],d[10];
//int i;
char *sp,*dp;
sp=&s;
dp=&d;
printf("Enter the source string...");
scanf("%s",s);
//printf("%s",s);

while(*dp++=*sp++);

printf("source=%s  destination=%s\n",s,d);
printf("\n");




}
