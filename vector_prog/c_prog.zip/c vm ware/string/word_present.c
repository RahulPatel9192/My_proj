// how many wprds are present in the string
#include<stdio.h>
main()
{
char s[50];
char ch=' ';
int c=0,i;
printf("Enter the line....");
scanf("%[^\n]",s);

for(i=0;s[i];i++)
if(s[i]==ch)
c++;

printf("\nThere are %d words in line\n",c+1);
printf("\n");




}
