//add the source string into destination string

#include<stdio.h>
main()
{
	char s[5],d[10],i,j;

	printf("Enter source string.....");
	scanf("%s",s);
	printf("Ente the destination string....");
	scanf("%s",d);

	printf("%s",s);
	printf("%d",d);


	for(i=0;d[i];i++);

	for(j=0;s[j];j++,i++)
	{
		d[i]=s[j];
	}
	d[i]='\0';
	printf("source=%s\n desti=%s\n",s,d);
	printf("\n");





}
