//merge two string

#include<stdio.h>
main()
{
	char s1[10],s2[10],s3[23];
	int i,j;
	printf("Enter the string1...");
	scanf("%s",s1);
	printf("Enter the string2...");
	scanf("%s",s2);




	i=0;
	j=0;
	while(s1[i] && s2[i])
	{
		s3[j]=s1[i];
		j++;
		s3[j]=s2[i];
		j++;
		i++;
	}

	if(s1[i]=='\0')
	{
		for(;s2[i];)
		{
			s3[j]=s2[i];
			i++;
			j++;
		}
	}
	else
	{
		for(;s1[i];)
		{
			s3[j]=s1[i];
			i++;
			j++;
		}
	}
	s3[j]='\0';

	printf("%s",s3);
	printf("\n");






}
