#include<stdio.h>
main()
{
char s[10];
int i,j,k,c=0;

printf("Entter the sring...");
scanf("%s",s);
for(i=0;s[i];i++);

for(j=0,k=i-1;k>j;j++,k--)
if(s[j]!=s[k])
break;

if(k<=j)
printf("palidrome\n");
else
printf("not plidrome\n");
printf("\n");




}
