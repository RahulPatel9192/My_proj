#include<stdio.h>
main()
{
char s[50];
int l=0,u=0,S=0,d=0,i;

printf("Enter string...");
scanf("%[^\n]",s);

for(i=0;s[i];i++)
{
if(s[i]>='a' && s[i]<='z')
l++;
else if(s[i]>='A' && s[i]<='Z')
u++;
else if(s[i]>=48 && s[i]<=57 && s[i]!=' ')
d++;
else
S++;

}
printf("in string\nlowercase=%d\nuppercase=%d\ndigit=%d\nspl char=%d\n",l,u,d,S);
printf("\n");
}
