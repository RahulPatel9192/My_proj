#include<stdio.h>
#include<string.h>
main()
{
	int i,j,k,m,n;
	char s[100],s1[100],ch=' ',t;

	printf("Enter the string...");
	scanf("%[^\n]",s);


	printf("Enter the string2...");
	scanf(" %[^\n]",s1);
	//for(n=0;s1[n];n++);
	///////////////// remove space s s1 string
	/*	for(i=0;s[i];i++)
		{
		if(s[i]==ch)
		{
		strcpy(s+i,s+i+1);
		i--;
		}
		}

		for(m=0;s[m];m++);
		printf("s=%s\n",s);


		for(i=0;s1[i];i++)
		{
		if(s1[i]==ch)
		{
		strcpy(s1+i,s1+i+1);
		i--;
		}
		}

		for(n=0;s1[n];n++);
		printf("s1=%s\n",s1);
	 */
	/////////////////////////////////////////////////////
	for(i=0,j=0;s[i];i++)
	{
		if((s[i]>='a' && s[i]<='z') || (s[i]>='A' && s[i]<='Z'))
			;
		else
		{
			strcpy(s+i,s+i+1);

			i--;
		}
	}
	for(m=0;s[m];m++);
	printf("s=%s m=%d\n",s,m);


	for(i=0,j=0;s1[i];i++)
	{
		if((s1[i]>='a' && s1[i]<='z') || (s1[i]>='A' && s1[i]<='Z'))
			;
		else
		{
			strcpy(s1+i,s1+i+1);
			i--;
//printf("i=%d\n",i);
		}
	}
	for(n=0;s1[n];n++);
	printf("s1=%s n=%d\n",s1,n);
	//////////////////////////////// sorting
	for(i=0;i<m-1;i++)
	{
		for(j=0;j<m-1-i;j++)
		{
			if(s[j]>s[j+1])
			{
				t=s[j];
				s[j]=s[j+1];
				s[j+1]=t;

			}
		}


	}
	//printf("ss=%s\n",s);


	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(s1[j]>s1[j+1])
			{
				t=s1[j];
				s1[j]=s1[j+1];
				s1[j+1]=t;

			}
		}
	}
	if(strcmp(s,s1))
		printf("not anagram\n");
	else
		printf("anagram\n");

}
