//string functions

#include<stdio.h>
#include<string.h>
main()
{
char s1[10],s2[10];
int s;
char ch,*p;
printf("Enter string s1...");
scanf("%s",s1);
printf("Enter string s2...");
scanf("%s",s2);
//printf("Enter char...");
//scanf(" %c",&ch);

//s=strlen(s1);
//strcpy(s2,s1);
//strncpy(s2,s1,3);
//p=strchr(s1,ch);
//p=strrchr(s1,ch);
//strcat(s2,s1);
//strncat(s2,s1,3);
//p=strstr(s1,s2);

printf("%s",p);
printf("\n");
}
