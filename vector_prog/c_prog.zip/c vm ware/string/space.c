#include<stdio.h>
main()
{
char s[50];
char ch=' ';
int i,c,j,k;

printf("Enter line...");
scanf("%[^\n]",s);

for(i=0;s[i];i++)
{
if(s[i]==ch && s[i+1]==ch)
{
for(j=i;s[j];j++)
s[j]=s[j+1];
i--;
}

}
printf("%s",s);
printf("\n");
}


