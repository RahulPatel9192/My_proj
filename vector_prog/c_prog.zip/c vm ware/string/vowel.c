//find vowel

#include<stdio.h>
main()
{
char s[10];
char v[6]={'a','e','i','o','u'};
int i,j;
printf("Enter the string...");
scanf("%s",s);

for(i=0;s[i];i++)
{
for(j=0;v[j];j++)
if(s[i]==v[j])
printf("%c ",s[i]);

}
printf("\n");



}
