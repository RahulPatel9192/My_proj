//array of pointer...

#include<stdio.h>
int sum(int,int);
int sub(int,int);
int mul(int,int);
int dive(int,int);
main()
{
int m=10,n=20,i;
int (*p[4])(int,int);

p[0]=sum;
p[1]=sub;
p[2]=mul;
p[3]=dive;


for(i=0;i<4;i++)
printf("%d\n",(*p[i])(m,n));
}

int sum (int m,int n)
{
return m+n;
}

int sub (int m,int n)
{
return m-n;
}

int mul (int m,int n)
{
return m*n;
}

int dive (int m,int n)
{
return m/n;
}

