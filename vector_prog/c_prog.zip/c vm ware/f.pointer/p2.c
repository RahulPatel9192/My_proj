#include<stdio.h>
int sum(int,int);
int call(int(*)(int,int),int,int);
main()
{

int i=10,j=20,k;
int(*p)(int,int);
k=call(sum,i,j);
printf("k=%d\n",k);

}

int call(int(*p)(int,int),int m,int n)
{
return((*p)(m,n));
}

int sum(int m,int n)
{

return m+n;

}
