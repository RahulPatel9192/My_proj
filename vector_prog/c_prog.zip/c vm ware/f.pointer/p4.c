
//calculator using array of pointe/fun pointer ...

#include<stdio.h>
int sum(int,int);
int sub(int,int);
int mul(int,int);
int dive(int,int);
//int (*p[4])(int,int);
main()
{
int m=10,n=20,i,op;
int (*p[4])(int,int);

p[0]=sum;
p[1]=sub;
p[2]=mul;
p[3]=dive;


printf("1)sum\n2)sub\n3)mul\n4)dive\n");
printf("Enter op...\n");
scanf("%d",&op);
printf("----------------------------------------------\n");
i=(*p[op-1])(m,n);
printf("result=%d\n",i);
}

int sum (int m,int n)
{
return m+n;
}

int sub (int m,int n)
{
return m-n;
}

int mul (int m,int n)
{
return m*n;
}

int dive (int m,int n)
{
return m/n;
}

