#include<stdio.h>
int sum(int,int);
int sub(int,int);
int mul(int,int);
int dive(int,int);
main()
{
int i=10,j=20,k;
int (*p)(int,int);

p=sum;
k=sum(i,j);
printf("k=%d\n",k);

k=(*p)(i,j);                    //k=p(i,j);

printf("k=%d\n",k);

}

int sum (int m,int n)
{
return m+n;
}

int sub (int m,int n)
{
return m-n;
}

int mul (int m,int n)
{
return m*n;
}

int dive (int m,int n)
{
return m/n;
}
