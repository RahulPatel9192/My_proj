/* mutable element-it's a keyword used for strcuture memory of the constant variable and that can be modified runtime*/
#include<iostream>
using namespace std;

struct st
{
int x;
mutable int y;
};

main()
{
const struct st var={10,20};

//var.x=11; //invalid
var.y=22; //valid

cout <<"x-"<<var.x<<endl;
cout <<"y-"<<var.y<<endl;

}
