#include<iostream>
using namespace std;

void test()
{
	try
	{
		throw "exception1";
	}
	catch(const char *p)
	{
		cout<<"test function catch block"<<endl;
		cout<<p<<endl;
		throw p; //retrhrow exception
	}
}

int main()
{
	try
	{
		test();
	}
	catch(const char *p)
	{
		cout<<"main function catch"<<endl;
		cout<<p<<endl;

	}

}
