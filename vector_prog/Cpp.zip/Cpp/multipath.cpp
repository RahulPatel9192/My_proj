#include<iostream>
using namespace std;

class A
{
public:
int a;
A():a(10){}
A(int x):a(x){}
~A(){}
};

class B:public A
{
public:
int b;
B():A(11),b(20){}
~B(){}
};

class C:public A
{
public:
int c;
C():A(12),c(30){}
~C(){}
};

class D:protected B,private C
{
int d;
public:
D():B(),C(),d(40){}
~D(){}
void print()
{
//cout<<"a-"<<a<<endl; //invalid
cout<<"B::a-"<<B::a<<endl;
cout<<"C::a"<<C::a<<endl;
cout<<"b-"<<b<<endl;
cout<<"c-"<<c<<endl;
cout<<"d-"<<d<<endl;
}

};

int main()
{
D obj;
cout<<"sizeof obj:"<<sizeof(obj)<<endl;
obj.print();

}
