//addition of structure members
#include<iostream>
using namespace std;
class A
{
	private:
		int x,y;
	public:
		void setdata(int a,int b)
		{
			x=a,y=b;
		}/*
		    void add(A &ob1,A &ob2)
		    {
		    x=ob1.x+ob2.x;
		    y=ob1.y+ob2.y;
		    }
		  */
		A add(A &op)
		{
			A temp;
			temp.x=x+op.x;
			temp.y=y+op.y;
			return temp;
		}
		void print()
		{
			cout<<"x-"<<x<<" y-"<<y<<endl;

		}
};

main()
{
	A obj1,obj2,obj3;

	obj1.setdata(10,20);
	obj2.setdata(11,22);
	//obj3.add(obj1,obj2);  //obj3=obj1+obj2;//invalid
	obj3=obj1.add(obj2);
	obj1.print();
	obj2.print();
	obj3.print();

}
