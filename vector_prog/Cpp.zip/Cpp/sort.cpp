#include<iostream>
using namespace std;

template <class t>
class A
{
	t a[5];
	public:
	void setdata()
	{
		cout<<"enter array element"<<endl;
		int i;
		for(i=0;i<5;i++)
			cin>>a[i];
		cout<<"---------------------\n";
	}
	void print()
	{
		int i;
		for(i=0;i<5;i++)
			cout<<a[i]<<endl;
		cout<<"---------------------\n";

	}
	void sort()
	{
		t temp;
		int i,j;
		for(i=0;i<5;i++)
		{
			for(j=i+1;j<5;j++)
			{
				if(a[i]< a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
	}
};

int main()
{
	A <int>iobj;
	A <char>cobj;
	A <float>fobj;
	cout<<"integer array"<<endl;
	iobj.setdata();
	iobj.sort();
	iobj.print();
	cout<<endl<<endl;

	cout<<"char array"<<endl;
	cobj.setdata();
	cobj.sort();
	cobj.print();
	cout<<endl<<endl;

	cout<<"float array"<<endl;
	fobj.setdata();
	fobj.sort();
	fobj.print();
	cout<<endl<<endl;
}




