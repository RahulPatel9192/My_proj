#include<iostream>
using namespace std;

class si
{
	private:
		int p;
		float r,n,s;
	public:
		void setdata(int x,float y,float z)
		{
			p=x;
			r=z;
			n=y;
		}

		float simple()
		{
			s=(p*r*n)/100;
		}
		void print()
		{
			cout<<"simple interest-"<<s<<endl;
		}
};

main()
{
	si obj;
	int a;
	float b,c,ans;
	cout<<"enter amount"<<endl;
	cin>>a;
	cout<<"enter interest"<<endl;
	cin>>b;
	cout<<"enter year"<<endl;
	cin>>c;

	obj.setdata(a,b,c);
	obj.simple();
	obj.print();
}
