#include<iostream>
using namespace std;

class B;
class A
{
	private:
		int x,y;
	public:
		void setdata(int a,int b)
		{
			x=a,y=b;
		}
		void print()
		{
			cout<<"x-"<<x<<"y-"<<y<<endl;
		}

		friend A add(A &ob1, B &ob2);

};

class B
{
	private:
		int a,b;
	public:
		void setdata(int x,int y)
		{
			a=x,b=y;
		}
		void print()
		{
			cout<<"a-"<<a<<"b-"<<b<<endl;
		}
		friend A add(A &ob1,B &ob2);
};

A add(A &ob1,B &ob2)
{
	A temp;
	temp.x=ob1.x+ob2.a;
	temp.y=ob1.y+ob2.b;
	return temp;
}

main()
{
	A obj1,sum;
	B obj2;

	obj1.setdata(10,20);
	obj2.setdata(11,22);

	sum=add(obj1,obj2);
	sum.print();
}
