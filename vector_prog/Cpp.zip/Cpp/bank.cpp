#include<iostream>
#include<cstring>
using namespace std;

class Bank
{
	protected:
		int acc_id;
		char acc_name[20];
		float balance;
		float interest;

	public:
		virtual void calculate_interest()=0;
		virtual void print_data()=0;
};

class Savings:public Bank
{
	public:
		Savings(int id,const char *n,float bal)
		{
			acc_id=id;
			strcpy(acc_name,n);
			balance=bal;
		}
		void calculate_interest()
		{
			cout<<"for savings"<<endl;
			interest=balance*1*0.04;
		}
		void print_data()
		{
			cout<<"saving print--"<<endl;
			cout<<"acc_id--"<<acc_id<<endl;
			cout<<"acc_name--"<<acc_name<<endl;
			cout<<"balance--"<<balance<<endl;
			cout<<"interest--"<<interest<<endl;
		}
};

class Current:public Bank
{
	public:
		Current(int id,const char *n,float bal)
		{
			acc_id=id;
			strcpy(acc_name,n);
			balance=bal;
		}
		void calculate_interest()
		{
			cout<<"for Current"<<endl;
			interest=balance*1*0.02;
		}
		void print_data()
		{
			cout<<"saving print--"<<endl;
			cout<<"acc_id--"<<acc_id<<endl;
			cout<<"acc_name--"<<acc_name<<endl;
			cout<<"balance--"<<balance<<endl;
			cout<<"interest--"<<interest<<endl;
		}
};

class Fixed:public Bank
{

	public:
		Fixed(int id,const char *n,float bal)
		{
			acc_id=id;
			strcpy(acc_name,n);
			balance=bal;
		}
		void calculate_interest()
		{
			cout<<"for Fixed"<<endl;
			interest=balance*1*0.08;
		}
		void print_data()
		{
			cout<<"saving print--"<<endl;
			cout<<"acc_id--"<<acc_id<<endl;
			cout<<"acc_name--"<<acc_name<<endl;
			cout<<"balance--"<<balance<<endl;
			cout<<"interest--"<<interest<<endl;
		}
};

main()
{
	Bank *bptr;
	Savings s(1234,"ramesh",50000);
	Current c(3456,"suresh",50000);
	Fixed f(5678,"naresh",50000);

	cout<<"size of s"<<sizeof(s)<<endl;
	cout<<"size of c"<<sizeof(c)<<endl;
	cout<<"size of f"<<sizeof(f)<<endl;
cout<<endl<<endl;
	bptr=&s;
	bptr->calculate_interest();
	bptr->print_data();
cout<<endl<<endl;
	bptr=&c;
	bptr->calculate_interest();
	bptr->print_data();
cout<<endl<<endl;

	bptr=&f;
	bptr->calculate_interest();
	bptr->print_data();
cout<<endl<<endl;
}
