#include<iostream>

using namespace std;

class B;

class A
{
	int x;
//	friend class B
	
	public:
	friend class B;
	A(int a):x(a){};
	
	void print(B &ob);
};

class B
{
	int y;
	//friend class A;
	
	public:
	friend class A;
	B(int a):y(a){};
	
	void print(A &ob)
	{
	cout<<"A data"<<endl<<"x="<<ob.x<<endl;
	}
};

void A::print(B &ob)
	{
	
	cout<<"B data"<<endl<<"y="<<ob.y<<endl;
	};
main()
{

	A obj1(10);
	B obj2(20);

	obj1.print(obj2);
	obj2.print(obj1);

}
