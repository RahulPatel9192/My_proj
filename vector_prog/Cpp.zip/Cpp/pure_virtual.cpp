#include<iostream>
using namespace std;

class A    //abstract class
{
public:
virtual void fun1()
{
cout<<"class-A fun1 function"<<endl;
}
virtual void fun2()=0; //pure virtual function
};

class B:public A
{
public:
void fun2() //override function
{
cout<<"class-B fun2 function"<<endl;
}

};
class C:public A
{
public:
void fun1() //override function
{
cout<<"class-C fun1 function"<<endl;
}
};

int main()
{
A *bptr;
//A a; //invalid, coz we can't create of the object of the class who having pure virtual function
B b;



bptr=&b;
bptr->fun1();
bptr->fun2();






}
