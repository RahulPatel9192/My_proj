/* constructor will call base to derived class and destructor call derived to base class*/

#include<iostream>
using namespace std;

class A
{
	public:
		int x,y;
		A():x(10),y(20)
	{
		cout<<"constructor-A"<<endl;
	}
		~A()
		{
			cout<<"Destructor-A"<<endl;
		}
};

class B: public A
{
	int a,b;
	public:
	//B():a(30),b(40),x(5),y(5) //invalid
	B():A(),a(30),b(40)
	{
		cout<<"constructor-B"<<endl;
		x=5,y=15; //assignmaent valid
	}
	~B()
	{
		cout<<"Destructor-B"<<endl;
	}
	void print()
	{
		cout<<"x-"<<x<<" y-"<<y<<endl;
		cout<<"a-"<<a<<" b-"<<b<<endl;

	}
};

int main()
{
	B obj;
	obj.print();

}

