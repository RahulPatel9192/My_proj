#include<iostream>
using namespace std;
class A
{
	private:
		int x,y;
		friend class B;
};

class B
{
	public:
		void setdata(A &ob)
		{
			ob.x=10;
			ob.y=20;
		}
		void print(A &ob)
		{
			cout<<"x-"<<ob.x<<"y-"<<ob.y<<endl;
		}
};

main()
{
	A obj;
	B b;
	b.setdata(obj);
	b.print(obj);

}
