//type conversiton basic to class
#include<iostream>
using namespace std;
class A
{
	int x,y;
	public:
	A(){}
	A(int a)
	{
		cout<<"parameterized construtor"<<endl;
		x=a,y=a;
	}
	void print()
	{
		cout<<"x-"<<x<<" y-"<<y<<endl;
	}
	~A(){}
};

main()
{
	int x=10;
	A obj;
	obj=x;
	/* 
	   A obj1=x; A obj1(x); A::A(&obj1,x);
	   obj=obj1;(obj1 creat internally)
	   A::~A(&obj1);
	 */
	obj.print();
}
