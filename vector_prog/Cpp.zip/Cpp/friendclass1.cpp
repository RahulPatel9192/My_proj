//give permission particulare function member of the class
#include<iostream>
using namespace std;
class A;
class B
{
	public:
		void setdata(A &ob);
		void print(A &ob);
};
class A
{
	private:
		int x,y;
		friend void B::setdata(A &);
	public:
		void print()
		{
			cout <<"x-"<<x<<"y-"<<y<<endl;
		}

};
void B::setdata(A &ob)
{
	ob.x=10;
	ob.y=20;
}
/*
   void B::print(A &ob)
   {
//cout<<"x-"<<x<<"y-"<<y<<endl; //inalid no permission for print function
}
 */
main()
{
	A obj;
	B b;
	b.setdata(obj);
	//b.print(obj);
	obj.print();
}

