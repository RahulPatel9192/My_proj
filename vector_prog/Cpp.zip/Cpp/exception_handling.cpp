#include<iostream>
using namespace std;

int main()
{
	int x,y,z;
	cout<<"enter the x value\n";
	cin>>x;
label:cout<<"enter the y value\n";
      cin>>y;

      try
      {
	      if(y==0)
		      throw "divided by zero";
	      else
		      z=x/y;
      }
      catch(const char *p)
      {
	      cout<<p<<endl;
	      goto label;
      }
      cout<<"z-"<<z<<endl;
}
