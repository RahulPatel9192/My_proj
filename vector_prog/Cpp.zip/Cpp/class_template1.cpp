#include<iostream>
using namespace std;

template<typename t1,typename t2>
class A
{
	t1 x;
	t2 y;
	public:
	void setdata(t1,t2);
	void print();
};

	template<class t1,class t2>
void A<t1,t2>::setdata(t1 a,t2 b)
{
	x=a,y=b;

}

	template<class t1,class t2>
void A<t1,t2>::print()
{
	cout<<"x-"<<x<<" "<<"y-"<<y<<endl;
}
main()
{
	A <int,int>ii_obj;
	A <int,char>ic_obj;
	A <int,float>if_obj;
	A <char,float>cf_obj;

	ii_obj.setdata(1,2);
	ic_obj.setdata(1,'a');
	if_obj.setdata(1,22.4);
	cf_obj.setdata('b',2.72);

	ii_obj.print();
	ic_obj.print();
	if_obj.print();
	cf_obj.print();


}
