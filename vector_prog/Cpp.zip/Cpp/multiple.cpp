#include<iostream>
using namespace std;

class A
{
protected:
int x;
public:
A():x(10){}
A(int a):x(a){}
~A(){}

void print()
{
cout<<"x-"<<x<<endl;
}
};

class B
{
public:
int y;
public:
B():y(20){}
B(int a):y(a){}
~B(){}

void print()
{
cout<<"y-"<<y<<endl;

}
};

class C
{
private:
int z;
public:
C():z(30){}
C(int a):z(a){}
~C(){}

void print()
{
cout<<"z-"<<z<<endl;
}
};

class D:protected A,public B,private C
{
public:
int m;
D():m(40){}

~D(){}
void print()
{
cout<<"x-"<<x<<endl;
cout<<"y-"<<y<<endl;
//cout<<"z-"<<z<<endl;
cout<<"m-"<<m<<endl;
C::print();
}
};

int main()
{
D obj;
obj.print();


}


