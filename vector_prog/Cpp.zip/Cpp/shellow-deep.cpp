//shallow copy deepcopy

#include<iostream>
#include<cstring>
using namespace std;

class A
{
	char *str;
	public:
	
	 A(const char *p)
	 {
	//cout<<"parameterised constructor"<<endl;
	str=new char[strlen(p)+1];
	strcpy(str,p);
	 }
	 

//deep copy
	A (A &ob)
	{
		//cout<<"explicit copy constructor"<<endl;
		str=new char[strlen(ob.str)+1];
		strcpy(str,ob.str);
	}

	void modify()
	{
		cout<<"modify fun"<<endl;
		str[0]='s';
	}
	void print()
	{
		cout<<"print fun"<<endl;
		cout<<"str-"<<str<<endl;
	}

};

int main()
{
	A obj1("vector");
	A obj2=obj1; //A obj2(obj1);
	obj1.modify();

	obj1.print();
	obj2.print();
}
