#include<iostream>
using namespace std;

class student
{
	public:
		int roll;
		char n[20];
	public:
		 void read()
		{
			cout<<"enter student name"<<endl;
			cin>>n;
			cout<<"enter roll no"<<endl;
			cin>>roll;
		}
		 void display()
		{	
			read();
			cout<<"name-"<<n<<" "<<"roll no-"<<roll<<endl;
		}

};

class internal:virtual public student
{
	public:
		int sub1,sub2;
	public:
		void read()
		{		
			student::display();
			cout<<"enter sub marks"<<endl;
			cin>>sub1>>sub2;

		}
		void display()
		{	
			read();
			cout<<"sub1 marks internal"<<sub1<<endl;
			cout<<"sub2 marks internal"<<sub2<<endl;

		}
};

class external:virtual public student
{
	public:
		int sub1,sub2;
	public:
		void read()
		{
			
			cout<<"enter sub marks"<<endl;
			cin>>sub1>>sub2;

		}
		void display()
		{
			read();
			cout<<"sub1 marks external"<<sub1<<endl;
			cout<<"sub2 marks external"<<sub2<<endl;

		}
};

class result:public internal,public external
{
	public:
		int total1,total2;
	public:
		void total_marks()
		{    
			internal::display();
                        external::display();   
			total1=internal::sub1+external::sub1;
			total2=internal::sub2+external::sub2;
			cout<<"total marks sub1"<<total1<<endl;
			cout<<"total marks sub2"<<total2<<endl;

		}



};

int main()
{
	result r;
        r.total_marks();
}


