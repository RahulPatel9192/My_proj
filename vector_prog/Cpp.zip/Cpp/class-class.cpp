#include<iostream>
using namespace std;

class A
{
	int x,y;
	public:
	A():x(10),y(20){}
	int get_x()
	{
		return x;
	}
	int get_y()
	{
		return y;
	}

	void print()
	{
		cout<<"x-"<<x<<" "<<"y-"<<y<<endl; 
	}
	~A(){}
	//friend class B
};

class B
{
	int a,b;
	public:
	B(){}
	B(A &ob)
	{
		a=ob.get_x();
		b=ob.get_y();
	}
	void print()
	{
		cout<<"a-"<<a<<" "<<"b-"<<b<<endl;
	}
	~B(){}
};

int main()
{
	A obj1;
	B obj2;
	obj2.print();
	obj2=obj1;
	obj2.print();

}
