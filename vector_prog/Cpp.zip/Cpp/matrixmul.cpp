#include<iostream>

using namespace std;

main()
{
	int sum=0;
	int a[3][3]={
		{1,2,3},
		{4,5,6},
		{7,8,9}	
	};
	int b[3][3]={
		{1,2,3},
		{4,5,6},
		{7,8,9}	
	};

	for(int i=0;i<3;i++)
	{
	for(int j=0;j<3;j++)
			cout<<a[i][j]<<" ";
	cout<<endl;
        }
cout<<"----------------------------"<<endl;
	for(int i=0;i<3;i++)
	{
	for(int j=0;j<3;j++)
			cout<<b[i][j]<<" ";
	cout<<endl;
        }
cout<<"---------------------------"<<endl;
	int c[3][3];
	for(int i=0;i<3;i++)
		for(int j=0;j<3;j++)
		{
			sum=0;
			for(int k=0;k<3;k++)
				sum+=a[i][k]*b[k][j];	
			c[i][j]=sum;
		}

	for(int i=0;i<3;i++)
	{
	for(int j=0;j<3;j++)
			cout<<c[i][j]<<" ";
	cout<<endl;
}
}
