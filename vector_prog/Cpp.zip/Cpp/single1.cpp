//how to define parameterised constructor in inheritance

#include<iostream>
using namespace std;

class A
{
	public:
		int x,y;
		A():x(10),y(20)
	{
		cout<<"constructor-A"<<endl;
	}
A(int m,int n):x(m),y(n)
{
cout<<"parameterised constructor-A"<<endl;
}
		~A()
		{
			cout<<"Destructor-A"<<endl;
		}
};

class B: public A
{
	int a,b;
	public:
	//B():a(30),b(40),x(5),y(5) //invalid
	B():A(),a(30),b(40)
	{
		cout<<"constructor-B"<<endl;
		x=5,y=15; //assignmaent valid
	}
B(int m,int n,int o,int p):A(m,n),a(o),b(p)
{
cout<<"parameterised constructor-B"<<endl;
}
	~B()
	{
		cout<<"Destructor-B"<<endl;
	}
	void print()
	{
		cout<<"x-"<<x<<" y-"<<y<<endl;
		cout<<"a-"<<a<<" b-"<<b<<endl;

	}
};

int main()
{
	B obj(11,22,33,44);
	obj.print();

}

