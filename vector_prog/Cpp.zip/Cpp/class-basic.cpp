#include<iostream>
using namespace std;

class A
{
	int x,y;
	public:
	A():x(10),y(20){}
	void print()
	{
		cout<<"x-"<<x<<"y-"<<y<<" "<<endl;
	}
	operator int()
	{
		cout<<"type conversion function"<<endl;
		int temp;
		temp=x+y;
		return temp;
	}
	~A(){}
};

int main()
{
	int sum;
	A obj;
	sum=obj;
	obj.print();
	cout<<"sum="<<sum<<endl;

}
