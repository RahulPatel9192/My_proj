#include<iostream>
using namespace std;

void test(int op)
{
	if(op==1)
		throw 10;
	if(op==2)
		throw 'A';
	if(op==3)
		throw 4.5;

	throw "exception";

}
int main()
{
	int op;
	cout<<"enter option 1)int 2)char 3)double"<<endl;
	cin>>op;
	try
	{
		test(op);
	}
	catch(int x)
	{
		cout<<"catch(int)"<<endl;
		cout<<"x-"<<x<<endl;
	}
	catch(char ch)
	{
		cout<<"catch(char)"<<endl;
		cout<<"ch-"<<ch<<endl;
	}
	catch(double d)
	{
		cout<<"catch(double)"<<endl;
		cout<<"d-"<<d<<endl;
	}
	catch(...)
	{
		cout<<"exception"<<endl;
	}

}
