#include<iostream>
using namespace std;

template <class type>
class A
{
	type x,y;
	public:
	void setdata(type a,type b)
	{
		cout<<"setdata"<<endl;
		x=a,y=b;
	}
	void print()
	{
		cout<<"x-"<<x<<"y-"<<y<<endl;

	}
};
int main()
{
	A <int>int_obj;  
	A <char>ch_obj;
	A <float>float_obj;

	int_obj.setdata(10,20);
	ch_obj.setdata('A','B');
	float_obj.setdata(22.7,4.5);

	int_obj.print();
	ch_obj.print();
	float_obj.print();
}
