#include<iostream>
using namespace std;
/*
class a
{
int x,y;
public:
void setdata(int a,int b)
{
x=a,y=b; 
}
void print()
{
cout<<"x-"<<x<<" y-"<<y<<endl;
}

};
*/

class a
{
int x,y;
public:
void setdata(int a,int b);
void print();
};

void a::setdata(int a,int b)
{
cout<<"setdata member fun"<<endl;
x=a,y=b;
}

void a::print()
{
cout<<"print member fun"<<endl;
cout<<"x-"<<x<<" y-"<<y<<endl;
}
main()
{
a obj1,obj2;
obj1.setdata(10,20);
obj1.print();
obj2.setdata(11,22);
obj2.print();


}
