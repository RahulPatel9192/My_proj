#include<iostream>
using namespace std;
class A
{
	int x,y;
	public:
	A(){}
	A(int a,int b):x(a),y(b){}
	A operator-();
	void print();
};

A A::operator-()
{
	cout<<"uanry-operator function"<<endl;
	A temp_obj;
	temp_obj.x=-x;
	temp_obj.y=-y;
	return temp_obj;
}
void A::print()
{
	cout<<"x-"<<x<<"y-"<<y<<endl;
}
main()
{
	A obj1(10,20),obj2;
	obj2=-obj1; //obj2=obj1.operator-();
	obj2.print();
}

