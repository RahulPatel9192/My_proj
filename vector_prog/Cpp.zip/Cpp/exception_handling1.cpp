#include<iostream>
using namespace std;

int div(int a,int b)
{
	cout<<"div function"<<endl;
	if(b==0)
		throw "divide by zero exception";
	else
		return a/b;

}
int main()
{
	int x,y,z;
	cout<<"enter the x value"<<endl;
	cin>>x;
label: cout<<"enter the y value"<<endl;
       cin>>y;

       try
       {
	       z=div(x,y);
       }
       catch(const char *p)
       {
	       cout<<p<<endl;
	       goto label;
       }
       cout<<"z-"<<z<<endl;

}
