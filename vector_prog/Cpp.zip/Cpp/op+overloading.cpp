#include<iostream>
using namespace std;
class A
{
int x,y;
public:
A(int a,int b):x(a),y(b){}
A(){}
A operator+(A &ob)
{
cout<<"operator funtion"<<endl;
A temp_obj;
temp_obj.x=x+ob.x;
temp_obj.y=y+ob.y;
return temp_obj;
}
void print()
{
cout<<"x-"<<x<<"y-"<<y<<endl;
}
};


main()
{
A obj1(10,20),obj2(11,22),sum;
sum=obj1+obj2; //obj1.operator+(obj2);
sum.print();
}
