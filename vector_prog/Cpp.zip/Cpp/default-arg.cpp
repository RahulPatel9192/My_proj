#include<iostream>
using namespace std;

int sum(int a,int b=0,int c=0,int d=0)
{
return a+b+c+d;
}

main()
{
int x=10,y=20,z=30,a=40;

cout<<sum(x)<<endl;
cout<<sum(x,y)<<endl;
cout<<sum(x,y,z)<<endl;
cout<<sum(x,y,z,a)<<endl;
}
