//swap two int,float,char
#include<iostream>
using namespace std;

void swap(int &a,int &b)
{
	int c;
	c=a;
	a=b;
	b=c;
}
void swap(float &a,float &b)
{
	float c;
	c=a;
	a=b;
	b=c;
}
void swap(char &a,char &b)
{
	char c;
	c=a;
	a=b;
	b=c;
}

main()
{
	int x=10,y=20;
	float f1=23.5,f2=27.2;
	char c1='a',c2='b';
	swap(x,y);
	cout<<"x-"<<x<<" y-"<<y<<endl;

	swap(f1,f2);
	cout<<"f1-"<<f1<<" f2-"<<f2<<endl;

	swap(c1,c2);
	cout<<"c1-"<<c1<<" c2-"<<c2<<endl;
}
