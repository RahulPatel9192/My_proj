#include<iostream>
using namespace std;

namespace first
{
int x=10,y=20;

void test()		//declare fun in namespace
{
cout<<"first namespace fun-"<<endl;
}
}

namespace second
{
int x=11,y=22;

void test()
{
cout<<"second namespace fun-"<<endl;
}
}
main()
{
//cout <<"x-"<<x<<endl;//invalid
cout <<"first::x-"<<first::x<<endl; //1st method
cout <<"second::x-"<<second::x<<endl; //1st method
			
using first::x;		//3rd method
using second::y;

cout<<"x-"<<x<<"y-"<<y<<endl;

{
using namespace first;  //2nd method
cout<<"x-"<<x<<endl;
test();
}

{
using namespace second;  //2nd method
cout<<"x-"<<x<<endl;
test();
}


}
