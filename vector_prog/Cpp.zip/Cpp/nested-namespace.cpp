#include<iostream>
using namespace std;

namespace first
{
int x=10;

  namespace second
{
int y=20;

}

}

main()
{
////////////////////////////////////
// 1st method using scope resolution
cout <<"x-"<<first::x<<endl;
cout<<"y-"<<first::second::y<<endl;
////////////////////////////////////
//2nd method  directive method
{
using namespace first;
using namespace first::second;
cout <<"x-"<<first::x<<endl;
cout<<"y-"<<first::second::y<<endl;

}
//////////////////////////////////
// 3rd method declaration method
{
using first::x;
using first::second::y;
cout <<"x-"<<first::x<<endl;
cout<<"y-"<<first::second::y<<endl;


}

}
