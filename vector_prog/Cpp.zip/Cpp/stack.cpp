#include<iostream>
using namespace std;

static int i=-1;

template<class t>
class stack
{
	t a[5];
	public:
	void push()
	{	
		if(i>=5)
		{
			cout<<"stack overflow"<<endl;
			cout<<endl;
		}
		else
		{
			i++;
			cout<<"push"<<endl;
			cin>>a[i];
		}


	}
	void pop()
	{		
		if(i<0)
			cout<<"stack is empty"<<endl;
		else
		{
			i--;
			cout<<"pop"<<endl;
		}
	}
	void display()
	{	int j;
		cout<<"Display"<<endl;
		for(j=0;j<=i;j++)
			cout<<a[j]<<endl;


	}

};

int main()
{
	stack <int>obj;
	int op;
	while(1)
	{
		cout<<"1) push"<<endl<<"2) pop"<<endl<<"3) Display"<<endl;
		cin>>op;


		switch(op)
		{
			case 1: obj.push(); break;
			case 2: obj.pop(); break;
			case 3: obj.display(); break;
			default:{ cout<<"invalid option"<<endl; break;}

		}
	}
}
