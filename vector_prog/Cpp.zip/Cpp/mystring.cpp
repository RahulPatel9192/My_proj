#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
class mystring 
{
	private:
		char *str;
	public:
		mystring()
		{
			str=0;
		}
		mystring(const char *p)
		{
			str=new char[strlen(p)+1];
			strcpy(str,p);
		}
		/*mystring(const char *p)
		  {
		  str=new char[strlen(p)+1];
		  strcpy(str,p);
		  }*/
		void operator=(const char*p)
		{
			str=new char[strlen(p)+1];
			strcpy(str,p);
		}
		mystring(mystring &obj)
		{
			str=new char[strlen(obj.str)+1];
			strcpy(str,obj.str);
		}
		friend istream& operator>>(istream &,mystring &);
		friend ostream& operator<<(ostream &,mystring&);
		friend mystring& operator+(mystring ,mystring);
		friend int operator ==(mystring &,mystring&);
		friend int operator >=(mystring &,mystring&);
		friend int operator <=(mystring &,mystring&);
		friend int operator !=(mystring &,mystring&);

};
istream& operator>>(istream &in,mystring &obj)
{
 

	FILE *fp;
	fp=fopen("data","w");
	char ch;
	int size=0,i=0;
	while((ch=getchar())!=EOF)
	{
		fputc(ch,fp);
	}
	fclose(fp);

	////////////////////////////
	fp=fopen("data","a");
	size=ftell(fp)+1;
	rewind(fp);
	fclose(fp);
	obj.str=new char[size];
	fp=fopen("data","r");
	while((ch=fgetc(fp))!=EOF)
	{
		obj.str[i++]=ch;
	}
	//	fgets(obj.str,size,fp);
	fclose(fp);
	in>>obj.str;
	return in;

}
/////////////////////
ostream& operator<<(ostream &out,mystring& obj)
{
	out<<obj.str;
	return out;
}
/////////////////////
mystring& operator+(mystring obj1,mystring obj2)
{

	static mystring temp;
	temp.str=new char[strlen(obj1.str)+strlen(obj2.str)+1];
	int i,j;

	for(i=0;obj1.str[i];i++)
		temp.str[i]=obj1.str[i];
	//temp.str[i]='\0';
	for(j=0;obj2.str[j];j++)
		temp.str[i+j]=obj2.str[j];
	temp.str[i+j]='\0';
	//temp.str=strcat(obj1.str,obj2.str);
	return temp;
}
///////////////////////////////
int operator ==(mystring &obj1,mystring&obj2)
{
	int i;
	for(i=0;obj1.str[i];i++)
	{
		if(obj1.str[i]!=obj2.str[i])
			break;
	}
	if(obj1.str[i]==obj2.str[i])
		return 1;
	else
		return 0;
}
int operator >=(mystring &obj1,mystring&obj2)
{
	int i;
	for(i=0;obj1.str[i];i++)
	{
		if(obj1.str[i]!=obj2.str[i])
			break;
	}
	if(obj1.str[i]>=obj2.str[i])
		return 1;
	else
		return 0;
}
int operator <=(mystring &obj1,mystring&obj2)
{
	int i;
	for(i=0;obj1.str[i];i++)
	{
		if(obj1.str[i]!=obj2.str[i])
			break;
	}
	if(obj1.str[i]<=obj2.str[i])
		return 1;
	else
		return 0;
}
int operator !=(mystring &obj1,mystring&obj2)
{
	int i;
	for(i=0;obj1.str[i];i++)
	{
		if(obj1.str[i]!=obj2.str[i])
			break;
	}
	if(obj1.str[i]!=obj2.str[i])
		return 1;
	else
		return 0;
}

main()
{

	mystring str,str1("kishore"),str2,str3;
	mystring str4=str1;//str4(str1);
	cout<<"Enter the string..\n";
	cin>>str1;//operator>>(cin,str1);
	cout<<"\nString1="<<str1<<endl;//operator<<(cout,str1);
	///////////////////////////////////////////////////
	str1="vector";//str1.operator=("vector");
	cout<<"\nString(Assignment)="<<str1<<endl;//operator<<(cout,str1);
	/////////////////////////////////////////////
	str1="hi";
	str2="hello";
	str3="bye";
	str4=str1+str2+str3;//operator+(str1,str2);
	cout<<"\nString(Concanetated)="<<str4<<endl;//operator<<(cout,str1);
	cout<<"\nString(Copy constructor)="<<str4<<endl;//operator<<(cout,str1);
	///////////////////////////////////////
	int r=str1==str2;//operator==(str1,str2);
	cout<<"r="<<r<<endl;
	str1="hi";
	str2="HI";
	r=str1>=str2;//operator>=(str1,str2);
	cout<<"r="<<r<<endl;
	str1="Hi";
	str2="hI";
	r=str1<=str2;//operator<=(str1,str2);
	cout<<"r="<<r<<endl;
	str1="Hi";
	str2="hI";
	r=str1!=str2;//operator<=(str1,str2);
	cout<<"r="<<r<<endl;
	//	mystring str5="Ramm";//str5("Ramm");
	//	cout<<"\nString="<<str5<<endl;

}

