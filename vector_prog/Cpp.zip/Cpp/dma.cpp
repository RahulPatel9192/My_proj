#include<iostream>
using namespace std;
main()
{
	int *p,i,r,j,k=0,c,**q;
	/*
	   p=new int; //p=new int(100);
	 *p=100;
	 cout<<"p-"<<p<<endl;
	 cout<<"*p-"<<*p<<endl;
	 delete p;
	 */
	/*
	//for array
	p=new int[5];
	for(i=0;i<5;i++)
	p[i]=i+10;

	for(i=0;i<5;i++)
	cout<<"p["<<i<<"]"<<p[i]<<endl;

	delete []p;
	 */
	cout<<"enter rows and cols"<<endl;
	cin>>r>>c;
	q=new int*[r];

	for(i=0;i<r;i++)
		q[i]=new int[c];

	cout<<"q-"<<q<<endl;

	for(i=0;i<r;i++)
		for(j=0;j<c;j++)
			q[i][j]=k++;

	for(i=0;i<r;i++)
		for(j=0;j<c;j++)
			cout<<"q["<<i<<"]["<<j<<"]"<<q[i][j]<<endl;

	for(i=0;i<r;i++)
		delete []q[i];
	delete []q;
}
