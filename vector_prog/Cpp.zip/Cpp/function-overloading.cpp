#include<iostream>
using namespace std;
int sum(int a,int b)
{
	return a+b;
}

int sum(int a,int b,int c)
{
	return a+b+c;
}

float sum(float a,int b)
{
	return a+b;
}

main()
{
	int x=10,y=20,z=30;
	float f1=23.5;

	cout<<"sum1-"<<sum(x,y)<<endl;
	cout<<"sum2-"<<sum(x,y,z)<<endl;
	cout<<"sum3-"<<sum(f1,y)<<endl;
}
