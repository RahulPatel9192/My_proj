#include<iostream>
using namespace std;

class Time
{
	int hr,min;
	public:
	Time(){}
	Time(int x)
	{
		hr=x/60;
		min=x%60;
	}
	void print()
	{
		cout<<"hr:"<<hr<<" min"<<min<<endl;
	}
};

main()
{
	int duration=135;
	Time T;
	T=duration;
	T.print();
}
