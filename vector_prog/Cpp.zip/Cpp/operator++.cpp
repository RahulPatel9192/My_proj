#include<iostream>
using namespace std;

class A
{
	int x,y;
	public:
	A(){}
	A(int a,int b):x(a),y(b){}
	A operator++();
	A operator++(int); //we write(int)so comile understand this is post increment
	void print();
};

A A::operator++()
{
	cout<<"unary++(pre)operator"<<endl;
	A temp_obj;
	temp_obj.x=++x;
	temp_obj.y=++y;
	return temp_obj;
}

A A::operator++(int)
{
	A temp_obj;
	temp_obj.x=x++;
	temp_obj.y=y++;
	return temp_obj;

}

main()
{
	A obj1(10,20),obj2,obj3;
	obj2=obj1++;
	obj3=++obj1;

}
