#include<iostream>
using namespace std;

class B
{
	int a,b;
	public:
	B(){}

	int& get_a()
	{
		return a;
	}
	int& get_b()
	{
		return b;
	}
	void print()
	{
		cout<<"a-"<<a<<" "<<"b-"<<b<<endl;
	}
	~B(){}
};

class A
{
	int x,y;
	public:
	A():x(10),y(20){}
	operator B()
	{
		B temp;
		temp.get_a()=x;
		temp.get_b()=y;
		return temp;
	}
	void print()
	{
		cout<<"x-"<<x<<" "<<"y-"<<y<<endl;
	}
	~A(){}
};

main()
{
	A obj1;
	B obj2;
	obj2=obj1;
	obj1.print();
	obj2.print();

}
