// excertion << overloaded sunction
#include<iostream>
using namespace std;

class A
{
	int x,y;
	public:
	A(int a,int b):x(a),y(b){}

	void print()
	{
		cout<<"x-"<<x<<"y-"<<y<<endl;
	}
	friend ostream &operator<<(ostream &out,A &ob);
};

ostream &operator<<(ostream &out,A &ob)
{
	out<<"operaotr << function"<<endl;
	out<<"x-"<<ob.x<<"y-"<<ob.y<<endl;

	return out;
}

main()
{
	A obj1(10,20),obj2(11,22),obj3(12,24),obj4(5,6);

	cout<<obj1<<obj2<<obj3<<obj4<<endl;
	/* explanation
	   operator<<(cout,obj1)<<obj2<<obj3<<obj4;
	   out<<obj2<<oj3<<obj4;
	   operator<<(out,obj2)<<obj3<<obj4;
	   out<<obj3<<obj4;
	   operator<<(out,obj3)<<obj4;
	   out<<obj4;
	   operator<<(out,obj4);


	   }
