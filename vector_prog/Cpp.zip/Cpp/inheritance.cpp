//basic examle of inheritance
#include<iostream>
using namespace std;

class A
{
	public:
		int x,y;
		void test_fun()
		{
			cout<<"test-fun"<<endl;
		}
};

class B:public A
{
	public:
		int z;
		void setdata()
		{
			cout<<"setdata function"<<endl;
			x=10,y=20,z=30;
		}

		void print()
		{
			cout<<"x-"<<x<<" "<<"y-"<<y<<" "<<"z-"<<z<<endl;
		//	setdata();
		//	test_fun();

		}
};

int main()
{
	A a;
	B b;
	cout<<"sizeof a-"<<sizeof(a)<<endl;
	cout<<"sizeof b-"<<sizeof(b)<<endl;

	b.setdata();
	b.print();
	b.test_fun();
}
