#include<iostream>

using namespace std;

class A;
class B;
class C;

class A
{
	int a[5];
	public:
	A()
	{
		for(int i=0;i<5;i++)
			a[i]=i;
	}
	friend void add(A &,B &,C &);
};

class B
{
	int b[5];
	public:
	B()
	{
		for(int i=0;i<5;i++)
			b[i]=i;
	}
	friend void add(A &,B &,C &);
};

class C
{
	int c[5];
	public:
	friend void add(A &,B &,C &);
	void print(void)
	{	
		for(int i=0;i<5;i++)
			cout<<"c["<<i<<"]="<<c[i]<<endl;
	};

};

void add(A &ob1,B &ob2,C &ob3)
{
	for(int i=0;i<5;i++)
	{
		ob3.c[i]=ob1.a[i]+ob2.b[i];
	}
};


main()
{
	A obj1;
	B obj2;
	C obj3;

	add(obj1,obj2,obj3);

	obj3.print();
}
