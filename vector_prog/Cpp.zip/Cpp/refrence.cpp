#include<iostream>
using namespace std;
main()
{
int x=10,i,a[5]={10,20,30,40,50};
int (&b)[5]=a; //int &r[5]=a invalid
int &r=x;

cout<<"x-"<<x<<"&x-"<<(unsigned)&x<<endl;
cout<<"r-"<<x<<"&r-"<<(unsigned)&r<<endl;

for(i=0;i<5;i++)
cout<<"r["<<i<<"]="<<&r[i]<<endl;

cout<<"a-"<<a<<"r-"<<r<<endl;
cout<<"a+1-"<<a+1<<"r+1-"<<r+1<<endl;
cout<<"&a+1-"<<&a+1<<"&r+1-"<<&r+1<<endl;


}
