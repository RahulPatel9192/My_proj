#include<iostream>
#include<fstream>
using namespace std;
int main()
{
char ch;
ifstream fin("file.txt");
ofstream fout("data.txt");

while(!fin.eof())
{
//fin>>ch;	//space is not consider
//fout<<ch;
fin.get(ch);
//fout.put(ch);
if(((ch>='a')&&(ch<='z'))||((ch>='A')&&(ch<='Z')))
{
ch=ch^32;
}
fout.put(ch);
}
fin.close();
fout.close();
}
