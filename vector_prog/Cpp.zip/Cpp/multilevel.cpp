#include<iostream>
using namespace std;

class A
{
int x;
public:
A():x(10){}
A(int a):x(a){}
void print()
{
cout<<"print-A "<<endl;
cout<<"x-"<<x<<endl;
}
};

class B:public A
{
protected:
int y;
public:
B():y(20){}
B(int a,int b):A(a),y(b){}
~B(){}
void print()
{
cout<<"print-B"<<endl;
//cout<<"x-"<<x<<endl; //invlaid coz class-A has a rivate member
cout<<"y-"<<y<<endl;
A::print();
}
};

class c:private B
{
int z;
public:
c():z(30){}
c(int a,int b,int c):B(a,b),z(c){}
~c(){}
void print()
{
cout<<"y-"<<y<<endl;
cout<<"z-"<<z<<endl;
B::print();

}

};


int main()
{
c obj;
obj.print();

c obj1(11,22,33);
obj1.print();
}
