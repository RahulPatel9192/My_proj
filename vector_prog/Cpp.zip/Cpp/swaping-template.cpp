#include<iostream>
using namespace std;

	template <class T1,class T2>
void swap(T1 &a,T2 &b)
{
	T1 temp;
	temp=a;
	a=b;
	b=temp;

}
main()
{
	int x=10,y=20;
	char ch1='A',ch2='B';
	float f1=22.7,f2=4.5;

	swap(x,y);
	swap(ch1,ch2);
	swap(f1,f2);

	cout<<"x-"<<x<<" "<<"y-"<<y<<endl;
	cout<<"ch1-"<<ch1<<" "<<"ch2-"<<ch2<<endl;
	cout<<"f1-"<<f1<<" "<<"f2-"<<f2<<endl;

}
