#include<reg51.h>
#include"uart.h"
main()
{
unsigned char temp;
	uart_init();
	while(1)
	{
	//loopback prog
		temp=uart_rx();
		uart_tx(temp);
	}

} 