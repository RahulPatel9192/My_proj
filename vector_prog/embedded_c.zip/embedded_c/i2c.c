#include<reg51.h>
#include"delay.h"
#include"lcd8bit.h"
#include"i2c.h"
#include"i2c_device.h"

main()
{
unsigned char s[]="BATMAN",buf[10],i,j;
	lcd_init();
for(i=0;s[i];i++)
	i2c_device_write(0xa0,0x00+i,s[i]);
	

for(i=0,j=0;s[i];i++)	
buf[j++]=i2c_device_read(0xa0,0x00+i);

	lcd_string(buf);
	while(1);

}