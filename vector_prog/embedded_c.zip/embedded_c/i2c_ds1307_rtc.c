//i2c implimantation using DS1307(RTC)

#include<reg51.h>
#include"delay.h"
#include"i2c.h"
#include"i2c_device.h"
#include"lcd8bit.h"


main()
{
unsigned char temp,temp1;
	lcd_init();
	//set rtc time
	
//	i2c_device_write(0xd0,0x00,0x00); //set sec
//	i2c_device_write(0xd0,0x01,0x15); //set min
	//i2c_device_write(0xd0,0x02,0x40); //set hr
//	i2c_device_write(0xd0,0x04,0x16); //set date
//	i2c_device_write(0xd0,0x05,0x03); //set month
//	i2c_device_write(0xd0,0x06,0x16); //set year
	
	while(1)
	{
	//read rtc
	temp=i2c_device_read(0xd0,0x02); //read hr;
		temp=temp|(1<<6);
		temp1=temp&0x1f;
		
		/*lcd_data(temp-48);
		lcd_data('-');*/
			//i2c_device_write(0xd0,0x02,temp);
	
		lcd_cmd(0x80);
	lcd_data(temp1/16+48);
	lcd_data(temp1%16+48);
	lcd_data(':');
	
	temp=i2c_device_read(0xd0,0x01); //read min;
	lcd_data(temp/16+48);
	lcd_data(temp%16+48);
	lcd_data(':');
		
	temp=i2c_device_read(0xd0,0x00); //read sec;
	lcd_data(temp/16+48);
	lcd_data(temp%16+48);
	
	temp=i2c_device_read(0xd0,0x02); //AM PM
		temp=(temp>>5)&0x01;
		if(temp==1)
		lcd_string("PM");
		else if(temp==0)
			lcd_string("AM");
	
	//read date

	temp=i2c_device_read(0xd0,0x04); //read date
	lcd_cmd(0xc0);
	lcd_data(temp/16+48);
	lcd_data(temp%16+48);	
	lcd_data('-');
	
	temp=i2c_device_read(0xd0,0x05); //read month;
	lcd_data(temp/16+48);
	lcd_data(temp%16+48);
	lcd_data('-');
	
	temp=i2c_device_read(0xd0,0x06); //read year;
	lcd_data(temp/16+48);
	lcd_data(temp%16+48);
		
	
	}
}