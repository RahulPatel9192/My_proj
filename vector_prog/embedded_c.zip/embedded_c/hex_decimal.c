#include<reg51.h>
//#include"lcd8bit.h"
#include"uart.h"

void hex(int num)
{
unsigned char x;
	x=num/16;
	x<10?uart_tx(x+48):uart_tx(x+55);
	x=num%16;
		x<10?uart_tx(x+48):uart_tx(x+55);

}
main()
{
unsigned char temp;
	uart_init();
	temp=uart_rx();
	uart_tx(temp);
	hex(temp);
	


}