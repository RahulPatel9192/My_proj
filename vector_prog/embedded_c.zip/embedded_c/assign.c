#include<reg51.h>
//#include"delay.h"
unsigned int t;
unsigned char c;
sbit sw=P2^7;
void delay(unsigned int dly)
{
unsigned char i;
	for( ;dly>0;dly--)
	{
	for(i=250;i>0;i--);
		for(i=247;i>0;i--);
		if(sw==0)
		{
		c++;
			while(sw==0);
			return;
		}
			
		
	}
	
	}
void change()
{
if(c==1)
	t=1000;
else if(c==2)
	t=500;
else if(c==3)
{
t=100;
	c=0;
}


}
	
	
void main()	
{
unsigned char i,b;
P1=0x00;
	t=2000;
	c=0;
	while(1)
	{
		P1=0x00;
		b=0x01;
	for(i=0;i<8;i++)
		{
		P1=P1^b;
			b=b<<1;
			delay(t);
			change();
			P1=0x00;
		}
	}
}