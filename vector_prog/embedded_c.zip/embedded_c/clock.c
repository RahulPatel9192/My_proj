#include<reg51.h>
#include"delay.h"
#include"lcd8bit.h"
main()
{
int sec,min=0,hr=0;
	lcd_init();
	while(1)
	{
		for(hr=0;hr<24;hr++)
		{
			if(hr<12)
			{
				lcd_cmd(0x80+8);
				lcd_string("AM");
			}
			else
			{
				lcd_cmd(0x80+8);
				lcd_string("PM");
			
			
			}
			for(min=0;min<60;min++)
			{
	       for(sec=0;sec<60;sec++)
		       {
			lcd_cmd(0x80);
			lcd_data(hr/10 +48);
			lcd_data(hr%10 +48);
			lcd_data(':');			
			//lcd_cmd(0x80+3);
			lcd_data(min/10 +48);
			lcd_data(min%10 +48);
			lcd_data(':');
		  //lcd_cmd(0x80+6);
			lcd_data(sec/10 +48);
			lcd_data(sec%10 +48);
			delay(1);
		
		}
	}
}
		}
	}
		
		
	

