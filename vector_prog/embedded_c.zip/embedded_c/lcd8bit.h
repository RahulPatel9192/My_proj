
sfr lcd=0xB0;
sbit rs=P2^3;
sbit rw=P2^4;
sbit en=P2^5;
unsigned int cnt=0;

void lcd_cmd(unsigned char cmd)
{
lcd=cmd;
	rs=0;
	rw=0;
	en=1;
	delay(2);
	en=0;
}

void lcd_data(unsigned char _data)
{
lcd=_data;
	rs=1;
	rw=0;
	en=1;
	delay(2);
	en=0;
}

void lcd_init()
{
lcd_cmd(0x01);
lcd_cmd(0x02);
lcd_cmd(0x06);
lcd_cmd(0x08);
lcd_cmd(0x38);
lcd_cmd(0x0C);
lcd_cmd(0x80);
}

void lcd_string(char *s)
{
while(*s)
{
	lcd_data(*s++);
	
}
}

void lcd_integer(int num)
{
char buf[10],i=0;
	if(num==0)
{
	lcd_data('0');
	return;
}
if(num<0)
{
	lcd_data('-');
	num=-num;
}
while(num)
{
buf[i++]=(num%10)+48;
	num=num/10;
}
for(--i;i>=0;i--)
lcd_data(buf[i]);

}

code unsigned char cgram_lut[]=
{
/*swastik*/ 0x17,0x14,0x14,0x1f,0x05,0x05,0x1d,0x00,
/*battery*/	0x0e,0x1f,0x11,0x11,0x11,0x11,0x1f,0x00,
/*battery*/	0x0e,0x1f,0x11,0x11,0x1f,0x1f,0x1f,0x00,
/*heart*/	  0x0b,0x15,0x11,0x11,0x11,0x0a,0x06,0x00	
};

void build_cgram()
{
char i;
	lcd_cmd(0x40); //adrress countr point to cgram
	for(i=0;i<32;i++)
	lcd_data(cgram_lut[i]);
	
	lcd_cmd(0x80); //adrress countr point to ddram

}