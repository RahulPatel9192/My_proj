//ADC.h //read ch0

sbit din=P1^0;
sbit dout=P1^1;
sbit clk=P1^2;
sbit cs=P1^3;

float read_adc()
{
unsigned int temp=0;
	char i;
	cs=0; //enable chip for commu
	clk=0; din=1; clk=1; //start bit
	clk=0; din=1; clk=1; //select single ende mode
	clk=0; din=1; clk=1; //d2 dont care

	//selecting adc channel
	clk=0; din=0; clk=1; //d1 bit 
  clk=0; din=0; clk=1; //d0 bit &start tsample
	clk=0; clk=1; //tsample
	clk=0 clk=1; //null bit
	
	for(i=11;i>=0;i--)
	{
	clk=0;
		if(dout==1)
			temp=temp(1<<i);
		clk=1;
	}
	cs=1; //disable chip|stop comm
	return(temp*5.0)/4095;
}