#include<reg51.h>
#include"delay.h"
#include"lcd8bit.h"
char s[]="RAHUL";
char *cp,l;
main()
{
	char i;
lcd_init();
	for(l=0;s[l];l++); //length of string
		
while(1)
{
	cp=s+(l-1);
for(i=0;i<16;i++)
	{
		if(i>16-l)
		{
		lcd_cmd(0x80);
			lcd_string(cp);
			cp--;
		}
	lcd_cmd(0x80+i);
		lcd_string(s);
		delay(1000);
		lcd_cmd(0x01);
	}
}
	
}
