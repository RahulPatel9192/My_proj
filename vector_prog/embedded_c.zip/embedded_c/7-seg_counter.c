#include<reg51.h>
#include"delay.h"
sfr seg=0xa0;
sbit s1=P3^0;
sbit s2=P3^1;
sbit sw1=P1^0;
sbit sw2=P1^1;

code unsigned char seg_lut[]=
{
/*0*/0x40,
/*1*/0x79,
/*2*/0x24,
/*3*/0x30,
/*4*/0x19,
/*5*/0x12,
/*6*/0x02,
/*7*/0x78,
/*8*/0x00,
/*9*/0x10,	
};

void disp_2_digits(int num)
{
seg=seg_lut[num/10];
	s1=0;
	delay(2);
	s1=1;
	
	seg=seg_lut[num%10];
	s2=0;
	delay(2);
	s2=1;
	

}
main()
{
int num=0,dly;
	
while(1)
{	
	if(num<60)
	{
	disp_2_digits(num);	
	if(sw1==0)
	{
		while(sw1==0);
		num++;
	disp_2_digits(num);
	}
	}
	
	if(sw2==0)
	{
	while(num!=0)
	{
		for(dly=250;dly>0;dly--)
	disp_2_digits(num);
		
		num--;
	}
	
	}
}
}