#include<reg51.h>
#include"delay.h"
#include"lcd8bit.h"
#include"keypad.h"
main()
{
unsigned int a[3]={0,0,0},t,i=0;
unsigned char s,e;
lcd_init();
while(1)
{
	
s=keyscn();
	if(s!='+' && s!='-' && s!='*' && s!='/' && s!='=')
	{
	a[i]=a[i]*10+(s-48);	
		//lcd_cmd(0x80);
		//lcd_cmd(0x01);
		lcd_integer(a[i]);
	}
	
	else if(s=='=')
	{
		lcd_data(s);
	
		switch(e)
		{
			case '+':
						t=a[0]+a[1];
			break;
			case '-':
						t=a[0]-a[1];
			break;
			case '*':
						t=a[0]*a[1];
						break;			
			case '/':
						t=a[0]/a[1];
						break;			
		
		}
	lcd_integer(t);
	
	}
else if(s=='+' || s=='-' || s=='*' || s=='/' )		
	{
		e=s;
		lcd_data(s);
		i++;
	}



}

}