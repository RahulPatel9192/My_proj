#include<reg51.h>
#include"delay.h"
#include"keypad.h"
#include"lcd8bit.h"
main()
{
unsigned char temp;
unsigned int a[3],t,i;
unsigned char s,b,c;

	lcd_init();
	while(1)
{
	  i=0;
		s=keyscn();
		
		for(;i<1;i++)
		{
	  a[0]=s-48;		
		lcd_data(s);
		}
		
		c=keyscn();
		lcd_data(c);
    s=keyscn();
		for(;i<2;i++)
		{
		a[1]=s-48;
			lcd_data(s);
		}
			b=keyscn();
		lcd_data(b);
		if(b=='=')
		{
		s=c;
		switch(s)
		{
			case '+':
						t=a[0]+a[1];
			break;
			case '-':
						t=a[0]-a[1];
			break;
			case '*':
						t=a[0]*a[1];
						break;			
			case '/':
						t=a[0]/a[1];
						break;			
		
		}
	}
		

		
	
		lcd_integer(t);
		temp=keyscn();
   if(temp=='@')
		{
			lcd_cmd(0x01);
			lcd_cmd(0x80);
			temp=' ';
			lcd_data(temp);
		}
}
	}