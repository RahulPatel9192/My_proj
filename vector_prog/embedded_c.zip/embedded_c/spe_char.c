#include<reg51.h>
#include"delay.h"
#include"lcd8bit.h"
main()
{
lcd_init();
	build_cgram();
	lcd_data(0); //read cgram page-0 & display
	lcd_data(1);
	lcd_data(2);
	lcd_data(3);
	while(1);
}