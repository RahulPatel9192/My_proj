#include<reg51.h>
#include"delay.h"
void main()
{
unsigned char i,b,c;
P2=0x0f;
	while(1)
	{
		P2=0x0f;
		b=0x01;
		c=0x80;
	for(i=0;i<8;i++)
		{
		P2=P2^b;
			P2=P2^c;
			b=b<<1;
			c=c>>1;
			delay(1000);
			P2=0x0f;
		
		}
		/*P2=0x0f;
	for(i=0;i<4;i++)
		{
		P2=P2^b;
			P2=P2^c;
			b=b<<1;
			c=c>>1;
			delay(1000);
			P2=0x0f;
		
		}*/
	
	}

}