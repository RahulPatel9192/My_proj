#include<reg51.h>
#include"delay.h"
sbit sw=P2^0;
main()
{
unsigned char c=0;
	P1=0xff;
	do
	{
	if(sw==0) //sw is pressed
	{
	delay(100); //avoid keybouncing
		c++; 
		P1=~c;
		while(sw==0); //waiting for switch release
	}
  }while(c<20);
	while(1);
	


}