//password protection

#include<reg51.h>
#include"uart.h"
int main()
{

	unsigned char a[4];
	unsigned int i,temp;
	unsigned char s[]="abc";

	uart_init();

	uart_string("Enter password: ");

	for(i=0;i<3;i++)
	{
	a[i]=uart_rx();
  uart_tx('*');
	}

	temp=uart_rx();
	uart_string("\r\n");

	if(temp==13)
	{
	for(i=0;i<3;i++)
	{
	if(a[i]!=s[i])
		break;
  }
	
	if(s[i]==a[i])
	uart_string("password is correct..\r\n");
  else
  uart_string("password is incorrect..\r\n");		
}

}