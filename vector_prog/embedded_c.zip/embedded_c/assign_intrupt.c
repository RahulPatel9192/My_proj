#include<reg51.h>
#include"uart.h"
unsigned char s[]="vector",*a=s;

void EX0_INTR(void) interrupt 0
{
  uart_tx(*a++);
}

main()
{
unsigned char i=0;
	EX0=EA=1;
	IT0=1;
uart_init();
	
	while(1)
	{
		for(i=0;i<8;i++)
	P1=(1<<i);
	}

}