//display boss,cold,soda,help
#include<reg51.h>
#include"delay.h"
sfr seg=0xA0;
sbit s1=P3^0;
sbit s2=P3^1;
sbit s3=P3^2;
sbit s4=P3^3;

code unsigned char seg_lut[4][4]=
{/*b*/0x83,/*0*/0xc0,/*0*/0xc0,/*s*/0x92,
	/*c*/0xc6,/*0*/0xc0,/*l*/0xc7,/*d*/0xa1,
	/*s*/0x92,/*0*/0xc0,/*d*/0xa1,/*a*/0x88,
	/*h*/0x8b,/*e*/0xc84,/*l*/0xc7,/*p*/0x8c

};
main()
{
	
	while(1)
	{
	int i=0,dly,j;
		for(j=0;j<4;j++)
		{			
		for(dly=250;dly>0;dly--)
			{
			seg=seg_lut[j][i];
			//delay(1000);
			s1=0;
			delay(2);
			s1=1;
i++;
			//for(dly=250;dly>0;dly--)
			seg=seg_lut[j][i];
			//delay(1000);
			s2=0;
			delay(2);
			s2=1;
i++;
			//for(dly=250;dly>0;dly--)
			seg=seg_lut[j][i];
			//delay(1000);
			s3=0;
			delay(2);
			s3=1;
i++;		
	    //for(dly=250;dly>0;dly--)
			seg=seg_lut[j][i];
			//delay(1000);	
			s4=0;
			delay(2);
			s4=1;
		i=0;
	}
		//delay(1000);
		}
		
}
	}
