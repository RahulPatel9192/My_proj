sbit r0=P1^7;
sbit r1=P1^6;
sbit r2=P1^5;
sbit r3=P1^4;

sbit c0=P1^3;
sbit c1=P1^2;
sbit c2=P1^1;
sbit c3=P1^0;

code unsigned char keypad_lut[4][4]={'7','8','9','/','4','5','6','*','1','2','3','-','@','0','=','+'};

bit colscn()
{
return((c0&c1&c2&c3));
}

unsigned char keyscn()
{
unsigned char row,col;
	//intial status of rows & cols
	r0=r1=r2=r3=0;
	c0=c1=c2=c3=1;
	
	while((colscn()==1)); //waiting for key press
	r0=0;
	r1=1;
	r2=1;
	r3=1;
	if(colscn()==0)
	{
	row=0;
		goto colcheck;
	}
	
	r0=1;
	r1=0;
	r2=1;
	r3=1;
	
	if(colscn()==0)
	{
	row=1;
		goto colcheck;
	}
	
	r0=1;
	r1=1;
	r2=0;
	r3=1;
	
	if(colscn()==0)
	{
	row=2;
		goto colcheck;
	}
	
	r0=1;
	r1=1;
	r2=1;
	r3=0;
	
	if(colscn()==0)
	{
	row=3;
		goto colcheck;
	}
	
	colcheck:
		if(c0==0)
			col=0;
		else if(c1==0)
			col=1;
		else if(c2==0)
			col=2;
		else if(c3==0)
			col=3;
	
		
		//delay(100); //avoid key bouncing
		while((c0&c1&c2&c3)==0);		//waiting for key release
		
		return(keypad_lut[row][col]);
		
		
}