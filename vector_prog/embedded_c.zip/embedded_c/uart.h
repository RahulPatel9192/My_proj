//uart.h
void uart_init()
{
TMOD=0x20; //timer1 mode 2
SCON=0x50; //REN=1,universal scom mode
TH1=253; //0xFD/-3//for 9600bps
TR1=1; //start timer

}

void uart_tx(unsigned char _data)
{
SBUF=_data;
while(TI==0);
TI=0;
}

unsigned char uart_rx()
{
while(RI==0);
	RI=0;
	return SBUF; 

}

void uart_string(char *s)
{
while(*s)
	uart_tx(*s++);

}