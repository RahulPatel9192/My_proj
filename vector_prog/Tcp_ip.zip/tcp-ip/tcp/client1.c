//tcp client
#include"header.h"
main(int argc,char **argv)
{
char a[500],b[200];
struct sockaddr_in v,v1;
int sfd,len,nsfd,i;

sfd=socket(AF_INET,SOCK_STREAM,0);

if(sfd<0)
{
perror("socket");
return;
}
perror("socket");
printf("sfd=%d\n",sfd);
////////////////////////////////////////////////
v.sin_family=AF_INET;
v.sin_port=htons(atoi(argv[1]));
v.sin_addr.s_addr=inet_addr("127.0.0.1");

len=sizeof(v);

if(connect(sfd,(struct sockaddr *)&v,len)<0)
{
perror("connect");
return;
}
perror("connect");
//////////////////////////////////////////////

printf("enter the cmd..\n");
scanf("%[^\n]",a);
write(sfd,a,strlen(a)+1);

read(sfd,a,sizeof(a));
printf("%s\n",a);

}
