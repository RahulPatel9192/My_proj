//tcp client
#include"header.h"
main()
{
char a[20],b[20];
struct sockaddr_in v,v1;
int sfd,len,nsfd,i;

sfd=socket(AF_INET,SOCK_STREAM,0);

if(sfd<0)
{
perror("socket");
return;
}
perror("socket");
printf("sfd=%d\n",sfd);
////////////////////////////////////////////////
v.sin_family=AF_INET;
v.sin_port=htons(2000);
v.sin_addr.s_addr=inet_addr("127.0.0.1");

len=sizeof(v);

if(connect(sfd,(struct sockaddr *)&v,len)<0)
{
perror("connect");
return;
}
perror("connect");
//////////////////////////////////////////////
/*while(1)
{
if(fork())
{
printf("enter the data...\n");
scanf("%s",a);
write(sfd,a,strlen(a)+1);
}
else
{
//printf("read the data...\n");
if((read(sfd,b,sizeof(b))==0))
break;
printf("data=%s\n",b);
}
}*/
printf("enter string..\n");
scanf("%s",a);
write(sfd,a,strlen(a)+1);

read(sfd,b,sizeof(b));
printf("%s\n",b);
}
