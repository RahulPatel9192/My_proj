//tcp server
#include"header.h"
main()
{
	char a[20],b[20];
	struct sockaddr_in v,v1;
	int sfd,len,nsfd,i;

	sfd=socket(AF_INET,SOCK_STREAM,0);

	if(sfd<0)
	{
		perror("socket");
		return;
	}
	perror("socket");
	printf("sfd=%d\n",sfd);
	////////////////////////////////////////////////
	v.sin_family=AF_INET;
	v.sin_port=htons(2000);
	v.sin_addr.s_addr=inet_addr("0.0.0.0");

	len=sizeof(v);

	if(bind(sfd,(struct sockaddr *)&v,len)<0)
	{
		perror("bind");
		return;
	}
	perror("bind");
	//////////////////////////////////////////////

	if(listen(sfd,5)<0)
	{
		perror("listen");
		return;
	}
	perror("listen");
	///////////////////////////////////////////////


	printf("before....\n");
	nsfd=accept(sfd,(struct sockaddr *)&v,&len);

	perror("accept");
/*	while(1)
	{
		if(fork()==0)
		{
			//printf("After...\n");
			if((read(nsfd,a,sizeof(a))==0))
				break;
			printf("data=%s\n",a);
		}
		else
		{
			scanf("%s",b);
			write(nsfd,b,sizeof(b));
		}
	}*/
read(nsfd,a,sizeof(a));
for(i=0;a[i];i++)
{
if(a[i]>='a' && a[i]<='z')
a[i]=a[i]-32;
else if(a[i]>='A' && a[i]<='Z')
a[i]=a[i]+32;
}
write(nsfd,a,strlen(a)+1);



}
