//udp client
#include"header.h"
main()
{
char a[20],b[20];
struct sockaddr_in v,v1;
int sfd,len,nsfd,i;

sfd=socket(AF_INET,SOCK_DGRAM,0);

if(sfd<0)
{
perror("socket");
return;
}
perror("socket");
printf("sfd=%d\n",sfd);
////////////////////////////////////////////////
v.sin_family=AF_INET;
v.sin_port=htons(2000);
v.sin_addr.s_addr=inet_addr("0.0.0.0");

len=sizeof(v);
//////////////////////////////////////////////
printf("Enter the data...\n");
while(1)
{
if(fork())
{
scanf("%s",a);
sendto(sfd,a,strlen(a)+1,0,(struct sockaddr *)&v,len);
}
else
{
recvfrom(sfd,b,sizeof(b),0,(struct sockaddr *)&v1,&len);
printf("%s\n",b);
}
}
}
