//udp server
#include"header.h"
main()
{
char a[20],b[20];
struct sockaddr_in v,v1;
int sfd,len,nsfd,i;

sfd=socket(AF_INET,SOCK_DGRAM,0);

if(sfd<0)
{
perror("socket");
return;
}
perror("socket");
printf("sfd=%d\n",sfd);
////////////////////////////////////////////////
v.sin_family=AF_INET;
v.sin_port=htons(2000);
v.sin_addr.s_addr=inet_addr("0.0.0.0");

len=sizeof(v);

if(bind(sfd,(struct sockaddr *)&v,len)<0)
{
perror("bind");
return;
}
perror("bind");
///////////////////////////////////////////////
printf("before....\n");
while(1)
{
if(fork==0)
{
recvfrom(sfd,a,sizeof(a),0,(struct sockaddr *)&v1,&len);
//printf("after data=%s from %s\n",a,inet_ntoa(v1.sin_addr.s_addr));
printf("%s\n",a);
}
else
{
scanf("%s",b);
sendto(sfd,b,strlen(b)+1,0,(struct sockaddr *)&v,len);
}
}
}
